/**
 * search.js
 * Handles the search box and renders results returned by SearchEngine
 * (via /api/search) - unchanged.
 *
 * Also drives a live "type-ahead" suggestions dropdown under the search
 * box. Course-name prefixes are answered by the backend Trie (/api/suggest);
 * when no name matches, the existing keyword/fuzzy dropdown logic is used.
 *
 * (older note:) This is pure display filtering over the SAME course data already
 * used elsewhere (Api.getAllCourses(), the same call explore.js makes) -
 * no separate/duplicate course list and no new algorithm. Clicking a
 * suggestion opens that course using the existing course.html?id= page.
 */
(function () {
  const form = document.getElementById("search-form");
  const input = document.getElementById("search-input");
  const resultsEl = document.getElementById("results");
  const resultsLabel = document.getElementById("results-label");
  const suggestionsEl = document.getElementById("category-suggestions");

  // Full course list is fetched once and cached; every keystroke then just
  // filters/ranks this in-memory list, so suggestions feel instant and no
  // extra network round-trip happens per character typed.
  let allCourses = [];
  Api.getAllCourses()
    .then((list) => { allCourses = list || []; })
    .catch(() => { allCourses = []; });

  function hideSuggestions() {
    suggestionsEl.style.display = "none";
    suggestionsEl.innerHTML = "";
  }

  /**
   * Edit Distance (Levenshtein) via dynamic programming - the same
   * fuzzy-matching algorithm SearchEngine.java uses server-side for the
   * typo-tolerant fallback on Search, mirrored here in JS so the live
   * dropdown can also tolerate typos without a round-trip per keystroke.
   */
  function editDistance(a, b) {
    const n = a.length, m = b.length;
    const dp = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
    for (let i = 0; i <= n; i++) dp[i][0] = i;
    for (let j = 0; j <= m; j++) dp[0][j] = j;
    for (let i = 1; i <= n; i++) {
      for (let j = 1; j <= m; j++) {
        dp[i][j] = a[i - 1] === b[j - 1]
          ? dp[i - 1][j - 1]
          : 1 + Math.min(dp[i - 1][j - 1], dp[i - 1][j], dp[i][j - 1]);
      }
    }
    return dp[n][m];
  }

  function similarityPercent(a, b) {
    const maxLen = Math.max(a.length, b.length);
    if (maxLen === 0) return 100;
    return Math.max(0, (1 - editDistance(a, b) / maxLen) * 100);
  }

  // Below this similarity %, a fuzzy match is too weak to be useful.
  const FUZZY_THRESHOLD = 60;
  // Fuzzy matching only kicks in once there's enough signal in the typed
  // text - a 1-2 character "typo" isn't a meaningful concept.
  const FUZZY_MIN_LENGTH = 3;

  function splitWords(text) {
    return text.toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
  }

  /**
   * Typo-tolerant fallback: compares the typed text against every word in
   * a course's name/category/keywords and returns the closest one, if it's
   * close enough. Used only when the exact/substring pass above found
   * nothing, so a good exact match is never displaced by a fuzzy guess.
   */
  function fuzzyMatchCourse(course, typedLower) {
    const fields = [
      { text: course.name, weight: 1 },
      { text: course.category, weight: 1 },
      ...[...(course.requiredSkills || []), ...(course.interestTags || []), ...(course.careerPaths || [])]
        .map((kw) => ({ text: kw, weight: 0.9 })),
    ];

    let best = 0;
    let bestWord = null;
    for (const field of fields) {
      for (const word of splitWords(field.text)) {
        if (Math.abs(word.length - typedLower.length) > 3) continue; // clearly not a typo of this word
        const sim = similarityPercent(typedLower, word) * field.weight;
        if (sim > best) {
          best = sim;
          bestWord = word;
        }
      }
    }

    if (best < FUZZY_THRESHOLD) return null;
    return { course, score: 20 + (best / 100) * 15, matchedKeyword: bestWord, fuzzy: true };
  }

  /**
   * Scores how well a course matches the typed text against name, category
   * and "relevant keywords" (required skills, interest tags, career paths).
   * A match at the start of a word in the course NAME/CATEGORY ranks
   * highest (e.g. "w" -> "Web Development"), a keyword match ranks next
   * (e.g. "j" -> "Java" in required skills), and a plain substring match
   * anywhere ranks lowest. Returns null when nothing matches at all, so
   * unrelated courses never show up.
   */
  function matchCourse(course, typedLower) {
    const nameLower = course.name.toLowerCase();
    const categoryLower = course.category.toLowerCase();
    const keywordFields = [
      ...(course.requiredSkills || []),
      ...(course.interestTags || []),
      ...(course.careerPaths || []),
    ];

    function fieldScore(text, weightPrefix, weightSubstring) {
      if (!text.includes(typedLower)) return 0;
      const escaped = typedLower.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const isWordStart = new RegExp(`(^|[^a-z0-9])${escaped}`).test(text);
      return isWordStart ? weightPrefix : weightSubstring;
    }

    const nameScore = fieldScore(nameLower, 100, 50);
    const categoryScore = fieldScore(categoryLower, 90, 45);

    let bestKeywordScore = 0;
    let bestKeyword = null;
    for (const kw of keywordFields) {
      const score = fieldScore(kw.toLowerCase(), 80, 40);
      if (score > bestKeywordScore) {
        bestKeywordScore = score;
        bestKeyword = kw;
      }
    }

    const best = Math.max(nameScore, categoryScore, bestKeywordScore);

    if (best === 0) {
      // Nothing matched exactly - try a typo-tolerant fuzzy match instead.
      return typedLower.length >= FUZZY_MIN_LENGTH ? fuzzyMatchCourse(course, typedLower) : null;
    }

    // Only surface the matched keyword when the name/category didn't
    // already match - it's what explains an otherwise "hidden" match.
    const matchedKeyword = nameScore === 0 && categoryScore === 0 ? bestKeyword : null;

    return { course, score: best, matchedKeyword };
  }

  function getMatches(typed) {
    const typedLower = typed.toLowerCase();
    const scored = [];
    for (const course of allCourses) {
      const m = matchCourse(course, typedLower);
      if (m) scored.push(m);
    }
    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, 8);
  }

  function highlight(text, typed) {
    const idx = text.toLowerCase().indexOf(typed.toLowerCase());
    if (idx === -1) return Components.escapeHtml(text);
    const before = Components.escapeHtml(text.slice(0, idx));
    const match = Components.escapeHtml(text.slice(idx, idx + typed.length));
    const after = Components.escapeHtml(text.slice(idx + typed.length));
    return `${before}<strong>${match}</strong>${after}`;
  }

  function renderSuggestions(matches, typed) {
    if (matches.length === 0) {
      suggestionsEl.innerHTML = `<div class="suggestion-empty">No courses found</div>`;
      suggestionsEl.style.display = "block";
      return;
    }

    suggestionsEl.innerHTML = matches
      .map(({ course, matchedKeyword, fuzzy }) => {
        const nameMatches = !fuzzy && course.name.toLowerCase().includes(typed.toLowerCase());
        const categoryMatches = !fuzzy && course.category.toLowerCase().includes(typed.toLowerCase());

        const nameHtml = nameMatches ? highlight(course.name, typed) : Components.escapeHtml(course.name);
        const categoryHtml = categoryMatches
          ? highlight(course.category, typed)
          : Components.escapeHtml(course.category);

        // If the match came from a keyword (skill/interest/career) rather
        // than the name or category, show that keyword so it's clear why
        // this course was suggested. Fuzzy matches get an "≈" marker so a
        // typo-tolerant guess never looks identical to an exact match.
        let keywordNote = "";
        if (fuzzy && matchedKeyword) {
          keywordNote = `<span class="suggestion-meta fuzzy">Did you mean "${Components.escapeHtml(matchedKeyword)}"?</span>`;
        } else if (!nameMatches && !categoryMatches && matchedKeyword) {
          keywordNote = `<span class="suggestion-meta">Matches: ${highlight(matchedKeyword, typed)}</span>`;
        }

        return `<div class="suggestion-item" data-course-id="${course.id}">
          <span class="suggestion-label">
            ${nameHtml}
            ${keywordNote}
          </span>
          <span class="suggestion-tag">${categoryHtml}</span>
        </div>`;
      })
      .join("");
    suggestionsEl.style.display = "block";
  }

  // Latest request counter: ignores slow responses that arrive out of order.
  let suggestSeq = 0;

  input.addEventListener("input", async () => {
    const typed = input.value.trim();

    if (typed.length === 0) {
      suggestSeq++;
      hideSuggestions();
      return;
    }

    const mySeq = ++suggestSeq;
    let trieMatches = [];
    try {
      // Course-name prefix autocomplete served by the backend Trie.
      trieMatches = await Api.suggest(typed);
    } catch (err) {
      trieMatches = [];
    }
    if (mySeq !== suggestSeq) return; // a newer keystroke superseded this one

    if (trieMatches && trieMatches.length > 0) {
      renderSuggestions(trieMatches.map((course) => ({ course, matchedKeyword: null })), typed);
      return;
    }

    // No course name starts with the text: fall back to the existing
    // keyword / typo-tolerant dropdown matching (unchanged).
    renderSuggestions(getMatches(typed), typed);
  });

  suggestionsEl.addEventListener("click", (e) => {
    const item = e.target.closest(".suggestion-item");
    if (!item) return;
    const courseId = item.getAttribute("data-course-id");
    if (!courseId) return;
    // Open the course using the existing course detail page/functionality.
    window.location.href = `course.html?id=${courseId}`;
  });

  // Hide the dropdown when clicking anywhere outside the search bar.
  document.addEventListener("click", (e) => {
    if (!form.contains(e.target)) hideSuggestions();
  });

  // Keep keyboard-only users out of a dead end: Escape closes suggestions.
  input.addEventListener("keydown", (e) => {
    if (e.key === "Escape") hideSuggestions();
  });

  async function runSearch(query) {
    hideSuggestions();
    resultsLabel.style.display = "block";
    resultsLabel.textContent = `Results for "${query}"`;
    resultsEl.innerHTML = Components.loadingState("Searching...");

    try {
      const results = await Api.search(query);

      if (!results || results.length === 0) {
        resultsEl.innerHTML = Components.emptyState(
          "No matching or similar courses found",
          "Try a different keyword, or check for typos."
        );
        return;
      }

      resultsEl.innerHTML = results
        .map((r, i) => Components.searchResultCard(r, i + 1))
        .join("");
    } catch (err) {
      resultsEl.innerHTML = Components.errorState();
    }
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const query = input.value.trim();
    if (!query) {
      resultsLabel.style.display = "block";
      resultsLabel.textContent = "";
      resultsEl.innerHTML = Components.emptyState("Enter a search term", "Type a course name, category or skill to search for.");
      return;
    }
    runSearch(query);
  });

  // Support ?q= in the URL so results can be linked to directly.
  const params = new URLSearchParams(window.location.search);
  const initialQuery = params.get("q");
  if (initialQuery) {
    input.value = initialQuery;
    runSearch(initialQuery);
  }
})();
