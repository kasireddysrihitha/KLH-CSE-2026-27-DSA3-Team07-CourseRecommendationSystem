/**
 * api.js
 * Thin wrapper around the backend JSON endpoints exposed by WebServer.java.
 * Every function here just calls fetch() and returns parsed JSON - all the
 * actual recommendation/search logic lives in the Java backend.
 */
const Api = {
  async getStatus() {
    const res = await fetch("/api/status");
    return res.json();
  },

  async getAllCourses() {
    const res = await fetch("/api/courses");
    return res.json();
  },

  async getCourse(id) {
    const res = await fetch(`/api/course?id=${encodeURIComponent(id)}`);
    if (!res.ok) return null;
    return res.json();
  },

  async search(query) {
    const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
    return res.json();
  },

  // Trie prefix autocomplete on course names (backend: /api/suggest)
  async suggest(prefix) {
    const res = await fetch(`/api/suggest?q=${encodeURIComponent(prefix)}`);
    if (!res.ok) return [];
    return res.json();
  },

  async getCategories() {
    const res = await fetch("/api/categories");
    return res.json();
  },

  async recommend({ interests, skills, qualifications, careerGoals }) {
    const params = new URLSearchParams({
      interests: interests || "",
      skills: skills || "",
      qualifications: qualifications || "",
      careerGoals: careerGoals || "",
    });
    const res = await fetch(`/api/recommend?${params.toString()}`);
    return res.json();
  },

  // Prerequisite graph (backend: /api/graph, /api/path, /api/unlocks)
  async getGraph() {
    const res = await fetch("/api/graph");
    return res.json();
  },

  async getPath(target, known, perSemester) {
    const params = new URLSearchParams({ target, known: known || "", perSemester: perSemester || 2 });
    const res = await fetch(`/api/path?${params.toString()}`);
    return res.json();
  },

  async getUnlocks(id) {
    const res = await fetch(`/api/unlocks?id=${encodeURIComponent(id)}`);
    if (!res.ok) return null;
    return res.json();
  },

  async compare(id1, id2) {
    const res = await fetch(`/api/compare?id1=${encodeURIComponent(id1)}&id2=${encodeURIComponent(id2)}`);
    if (!res.ok) return null;
    return res.json();
  },
};
