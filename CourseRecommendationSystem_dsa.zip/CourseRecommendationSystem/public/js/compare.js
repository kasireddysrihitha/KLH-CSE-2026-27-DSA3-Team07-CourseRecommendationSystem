/**
 * compare.js
 * Populates the two course dropdowns from /api/courses, then fetches
 * /api/compare?id1=&id2= and renders a side-by-side table. No comparison
 * logic here - the two courses are simply placed next to each other.
 */
(function () {
  const select1 = document.getElementById("course-1");
  const select2 = document.getElementById("course-2");
  const compareBtn = document.getElementById("compare-btn");
  const resultsEl = document.getElementById("results");

  function row(label, v1, v2) {
    return `<tr><th>${label}</th><td>${v1}</td><td>${v2}</td></tr>`;
  }

  function joinOrNone(list) {
    return list.length ? Components.escapeHtml(list.join(", ")) : "None";
  }

  function renderComparison(course1, course2) {
    resultsEl.innerHTML = `
      <table class="compare-table">
        <tbody>
          ${row("Name", Components.escapeHtml(course1.name), Components.escapeHtml(course2.name))}
          ${row("Category", Components.escapeHtml(course1.category), Components.escapeHtml(course2.category))}
          ${row("Description", Components.escapeHtml(course1.description), Components.escapeHtml(course2.description))}
          ${row("Prerequisites", joinOrNone(course1.prerequisites), joinOrNone(course2.prerequisites))}
          ${row("Required skills", joinOrNone(course1.requiredSkills), joinOrNone(course2.requiredSkills))}
          ${row("Career paths", joinOrNone(course1.careerPaths), joinOrNone(course2.careerPaths))}
        </tbody>
      </table>
    `;
  }

  async function populateSelects() {
    const courses = await Api.getAllCourses();
    const options = courses
      .map((c) => `<option value="${c.id}">${Components.escapeHtml(c.name)}</option>`)
      .join("");
    select1.innerHTML = `<option value="">Select a course</option>${options}`;
    select2.innerHTML = `<option value="">Select a course</option>${options}`;

    // Support preselecting course 1 via ?id1= (linked from Course Details "Compare this course").
    const params = new URLSearchParams(window.location.search);
    const id1 = params.get("id1");
    if (id1) select1.value = id1;
  }

  async function handleCompare() {
    const id1 = select1.value;
    const id2 = select2.value;

    if (!id1 || !id2) {
      resultsEl.innerHTML = Components.emptyState("Pick two courses", "Select a course in both dropdowns to compare them.");
      return;
    }
    if (id1 === id2) {
      resultsEl.innerHTML = Components.emptyState("Pick two different courses", "Choose two distinct courses to compare.");
      return;
    }

    resultsEl.innerHTML = Components.loadingState("Comparing...");
    try {
      const data = await Api.compare(id1, id2);
      if (!data) {
        resultsEl.innerHTML = Components.emptyState("Comparison unavailable", "One or both course IDs are invalid.");
        return;
      }
      renderComparison(data.course1, data.course2);
    } catch (err) {
      resultsEl.innerHTML = Components.errorState();
    }
  }

  compareBtn.addEventListener("click", handleCompare);

  populateSelects();
})();
