/**
 * components.js
 * Small, reusable functions that turn API data into HTML strings.
 * Kept separate from page scripts so each page file stays focused on
 * "what happens on this page" rather than markup details.
 */
const Components = {
  escapeHtml(str) {
    if (str == null) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  },

  tagRow(items) {
    if (!items || items.length === 0) return "";
    return `<div class="tag-row">${items
      .map((t) => `<span class="tag">${this.escapeHtml(t)}</span>`)
      .join("")}</div>`;
  },

  /** Course card used on Explore and Compare-picker style listings. */
  courseCard(course) {
    return `
      <div class="card course-card">
        <div class="top-row">
          <h3>${this.escapeHtml(course.name)}</h3>
          <span class="badge">${this.escapeHtml(course.category)}</span>
        </div>
        <p class="desc">${this.escapeHtml(course.description)}</p>
        ${this.tagRow(course.requiredSkills.slice(0, 4))}
        <div class="card-actions">
          <a class="btn btn-secondary" href="course.html?id=${course.id}">View details</a>
        </div>
      </div>
    `;
  },

  /** Recommendation card: course + score + eligibility, used on Recommend page. */
  recommendationCard(scoredCourse, rank) {
    const c = scoredCourse.course;
    const eligibleBadge = scoredCourse.eligible
      ? `<span class="badge badge-good">Eligible</span>`
      : `<span class="badge badge-warn">Missing prerequisites</span>`;

    const missing =
      !scoredCourse.eligible && scoredCourse.missingPrerequisites.length
        ? `<p class="desc" style="margin-top:-4px;">Needs: ${this.escapeHtml(
            scoredCourse.missingPrerequisites.join(", ")
          )}</p>`
        : "";

    return `
      <div class="card course-card">
        <div class="top-row">
          <h3>${rank}. ${this.escapeHtml(c.name)}</h3>
          <span class="score-pill">${scoredCourse.score.toFixed(1)}<span style="font-weight:400;color:var(--ink-soft)">/100</span></span>
        </div>
        <div class="tag-row">
          <span class="badge">${this.escapeHtml(c.category)}</span>
          ${eligibleBadge}
        </div>
        <p class="desc">${this.escapeHtml(c.description)}</p>
        ${missing}
        ${this.tagRow(c.careerPaths.slice(0, 3))}
        <div class="card-actions">
          <a class="btn btn-secondary" href="course.html?id=${c.id}">View details</a>
        </div>
      </div>
    `;
  },

  /** Search result card: course + similarity confidence, used on Search page. */
  searchResultCard(result, rank) {
    const c = result.course;
    return `
      <div class="card course-card">
        <div class="top-row">
          <h3>${rank}. ${this.escapeHtml(c.name)}</h3>
          <span class="score-pill">${result.confidence.toFixed(0)}%<span style="font-weight:400;color:var(--ink-soft)"> match</span></span>
        </div>
        <span class="badge">${this.escapeHtml(c.category)}</span>
        <p class="desc">${this.escapeHtml(c.description)}</p>
        <div class="card-actions">
          <a class="btn btn-secondary" href="course.html?id=${c.id}">View details</a>
        </div>
      </div>
    `;
  },

  emptyState(title, message) {
    return `
      <div class="state-box">
        <strong>${this.escapeHtml(title)}</strong>
        <span>${this.escapeHtml(message)}</span>
      </div>
    `;
  },

  loadingState(message) {
    return `<div class="state-box">${this.escapeHtml(message || "Loading...")}</div>`;
  },

  errorState(message) {
    return `
      <div class="state-box">
        <strong>Something went wrong</strong>
        <span>${this.escapeHtml(
          message || "Could not reach the server. Make sure WebServer is running."
        )}</span>
      </div>
    `;
  },
};
