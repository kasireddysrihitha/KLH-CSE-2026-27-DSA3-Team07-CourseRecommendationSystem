/**
 * recommend.js
 * Handles the student profile form and renders the ranked recommendations
 * returned by RecommendationEngine (via /api/recommend). No scoring or
 * ranking logic here - only form handling and rendering.
 */
(function () {
  const form = document.getElementById("recommend-form");
  const resultsEl = document.getElementById("results");
  const resultsLabel = document.getElementById("results-label");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const interests = document.getElementById("interests").value;
    const skills = document.getElementById("skills").value;
    const qualifications = document.getElementById("qualifications").value;
    const careerGoals = document.getElementById("careerGoals").value;

    if (!interests.trim() && !skills.trim() && !qualifications.trim() && !careerGoals.trim()) {
      resultsLabel.style.display = "block";
      resultsEl.innerHTML = Components.emptyState(
        "Tell us a bit about yourself",
        "Fill in at least one field (interests, skills, qualifications or career goals) to get recommendations."
      );
      return;
    }

    resultsLabel.style.display = "block";
    resultsLabel.textContent = "Top recommended courses";
    resultsEl.innerHTML = Components.loadingState("Matching courses against your profile...");

    try {
      const results = await Api.recommend({ interests, skills, qualifications, careerGoals });

      if (!results || results.length === 0) {
        resultsEl.innerHTML = Components.emptyState(
          "No matching courses found",
          "Try adding more interests, skills or career goals."
        );
        return;
      }

      resultsEl.innerHTML = results
        .map((sc, i) => Components.recommendationCard(sc, i + 1))
        .join("");
    } catch (err) {
      resultsEl.innerHTML = Components.errorState();
    }
  });
})();
