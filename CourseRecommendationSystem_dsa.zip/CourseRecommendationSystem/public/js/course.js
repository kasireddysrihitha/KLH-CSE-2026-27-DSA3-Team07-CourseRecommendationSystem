/**
 * course.js
 * Reads ?id= from the URL, fetches that course from /api/course, and
 * renders a full detail layout. Pure rendering - all data comes from
 * CourseDatabase via the API.
 */
(function () {
  const container = document.getElementById("detail-container");

  function block(title, content) {
    return `<div class="detail-block"><h3>${title}</h3>${content}</div>`;
  }

  function render(course) {
    document.title = `${course.name} - Course Recommendation System`;

    const prereqs = course.prerequisites.length
      ? Components.tagRow(course.prerequisites)
      : `<p class="desc">None</p>`;

    container.innerHTML = `
      <div class="page-header">
        <span class="badge">${Components.escapeHtml(course.category)}</span>
        <h1 class="mt-24">${Components.escapeHtml(course.name)}</h1>
      </div>
      <div class="detail-grid">
        <div>
          ${block("Description", `<p class="desc">${Components.escapeHtml(course.description)}</p>`)}
          ${block("Prerequisites", prereqs)}
          ${block("Required skills", Components.tagRow(course.requiredSkills))}
          ${block("Career paths", Components.tagRow(course.careerPaths))}
          ${block("Interest tags", Components.tagRow(course.interestTags))}
        </div>
        <div>
        <div class="card">
          <div class="section-label">Quick actions</div>
          <a class="btn btn-primary btn-block" href="compare.html?id1=${course.id}">Compare this course</a>
          <div class="mt-24"></div>
          <a class="btn btn-secondary btn-block" href="explore.html">Back to all courses</a>
        </div>
        </div>
      </div>
      <div class="detail-block mt-32">
        <h3>What this course unlocks</h3>
        <div id="unlocks-box">${Components.loadingState("Loading...")}</div>
      </div>
      <div class="card mt-24">
        <div class="section-label">Learning path to this course</div>
        <div class="form-grid" style="grid-template-columns: 2fr 1fr auto; align-items:end;">
          <div class="field">
            <label for="path-known">What you already know (comma separated)</label>
            <input type="text" id="path-known" placeholder="e.g. Basic Programming, Statistics" autocomplete="off">
          </div>
          <div class="field">
            <label for="path-per">Courses per semester</label>
            <select id="path-per"><option>1</option><option selected>2</option><option>3</option><option>4</option></select>
          </div>
          <button class="btn btn-primary" id="path-btn" type="button">Build path</button>
        </div>
        <div id="path-box" class="mt-24"></div>
      </div>
    `;
    loadUnlocks(course.id);
    document.getElementById("path-btn").addEventListener("click", () => loadPath(course.id));
    loadPath(course.id);
  }

  async function loadUnlocks(id) {
    const box = document.getElementById("unlocks-box");
    try {
      const data = await Api.getUnlocks(id);
      if (!data || !data.unlocks.length) {
        box.innerHTML = `<p class="desc">Nothing in the catalog lists this course as a prerequisite.</p>`;
        return;
      }
      box.innerHTML = Components.tagRow(data.unlocks.map((u) => (u.distance > 1 ? u.name + " (later)" : u.name)));
    } catch (e) { box.innerHTML = Components.errorState(); }
  }

  async function loadPath(id) {
    const box = document.getElementById("path-box");
    box.innerHTML = Components.loadingState("Building path...");
    try {
      const known = document.getElementById("path-known").value;
      const per = document.getElementById("path-per").value;
      const r = await Api.getPath(id, known, per);
      box.innerHTML = renderPath(r);
    } catch (e) { box.innerHTML = Components.errorState(); }
  }

  function renderPath(r) {
    const E = Components.escapeHtml;
    if (r.status === "ALREADY_KNOWN") return `<p class="desc">You already know this course - nothing to learn.</p>`;
    if (r.status === "BLOCKED_BY_CYCLE")
      return `<p class="desc">A circular prerequisite in the dataset blocks this path: ${E(r.blocked.join(", "))}.</p>`;
    if (r.status !== "OK") return `<p class="desc">Course not found.</p>`;
    const by = {};
    r.steps.forEach((s) => { (by[s.semester] = by[s.semester] || []).push(s); });
    let html = `<p class="desc">${r.semesters} semester(s) at ${r.perSemester} per semester (minimum possible: ${r.minSemesters}).</p>`;
    Object.keys(by).sort((a, b) => a - b).forEach((sem) => {
      const label = sem === "0" ? "Learn first (foundations)" : `Semester ${sem}`;
      html += `<div class="detail-block"><h3>${label}</h3><div class="tag-row">` +
        by[sem].map((s) => `<span class="tag" title="Requires: ${E(s.requires.join(", ") || "nothing")}">${E(s.name)}</span>`).join("") +
        `</div></div>`;
    });
    if (r.alreadyKnown.length) html += `<p class="desc">Skipped (already known): ${E(r.alreadyKnown.join(", "))}</p>`;
    return html;
  }

  async function init() {
    const params = new URLSearchParams(window.location.search);
    const id = params.get("id");

    if (!id) {
      container.innerHTML = Components.emptyState("No course selected", "Pick a course from Explore or Search.");
      return;
    }

    try {
      const course = await Api.getCourse(id);
      if (!course) {
        container.innerHTML = Components.emptyState("Course not found", `No course with ID ${Components.escapeHtml(id)}.`);
        return;
      }
      render(course);
    } catch (err) {
      container.innerHTML = Components.errorState();
    }
  }

  init();
})();
