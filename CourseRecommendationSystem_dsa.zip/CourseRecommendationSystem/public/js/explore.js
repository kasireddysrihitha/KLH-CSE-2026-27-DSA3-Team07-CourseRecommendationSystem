/**
 * explore.js
 * Loads the full course list from /api/courses (CourseDatabase, unchanged)
 * and applies a simple client-side text/category filter over the already
 * fetched list. This is display-only filtering, not a search algorithm -
 * the real keyword/fuzzy search lives in SearchEngine and is used on the
 * Search page instead.
 */
(function () {
  const resultsEl = document.getElementById("results");
  const textInput = document.getElementById("filter-text");
  const categorySelect = document.getElementById("filter-category");

  let allCourses = [];

  function populateCategories(courses) {
    const categories = [...new Set(courses.map((c) => c.category))].sort();
    categorySelect.innerHTML =
      `<option value="">All categories</option>` +
      categories.map((cat) => `<option value="${Components.escapeHtml(cat)}">${Components.escapeHtml(cat)}</option>`).join("");
  }

  function render() {
    const text = textInput.value.trim().toLowerCase();
    const category = categorySelect.value;

    const filtered = allCourses.filter((c) => {
      const matchesCategory = !category || c.category === category;
      const haystack = `${c.name} ${c.category} ${c.description} ${c.requiredSkills.join(" ")}`.toLowerCase();
      const matchesText = !text || haystack.includes(text);
      return matchesCategory && matchesText;
    });

    if (filtered.length === 0) {
      resultsEl.innerHTML = Components.emptyState("No courses match", "Try a different keyword or category.");
      return;
    }

    resultsEl.innerHTML = filtered.map((c) => Components.courseCard(c)).join("");
  }

  async function init() {
    resultsEl.innerHTML = Components.loadingState("Loading courses...");
    try {
      allCourses = await Api.getAllCourses();
      populateCategories(allCourses);
      render();
    } catch (err) {
      resultsEl.innerHTML = Components.errorState();
    }
  }

  textInput.addEventListener("input", render);
  categorySelect.addEventListener("change", render);

  init();
})();
