# GRAPH_DESIGN.md — Phase 3: Course Prerequisite Graph

## 0. What the dataset actually contains (why this model)

`data/courses.txt` has a `prerequisites` field per course. Inspecting all 14 courses:

* Only **one** prerequisite names another course: *Deep Learning with Neural Networks* needs
  *Machine Learning Fundamentals* (plus *Linear Algebra*).
* The rest are **foundation topics that are not courses** in the catalog: `Basic Programming`,
  `Statistics`, `Networking Basics`, `Linear Algebra`.
* Two courses (Computer Networking, UI/UX Design) have no prerequisites at all.

So the real structure is "foundation topics → courses → more advanced courses". A graph that only
contained courses would have a single edge, which is why foundation topics are modelled as vertices
too. Network flow / bipartite matching was considered and **rejected**: nothing in the data has
capacities or a competing-assignment structure, so a flow model would be invented, not real.

## 1. Problem being modelled
"In what order must a student learn things to reach a target course, given what they already know,
and how many semesters does that take?" This is the classic prerequisite-ordering problem, a
dependency graph over the course catalog.

## 2. Vertices
One vertex per **course** (type `course`) and one per **distinct prerequisite name that is not a
course** (type `foundation`). Names are matched case-insensitively after trimming.

## 3. Edges
Directed edge `P → C` when `P` is listed in the prerequisites of course `C`
("P must be learned before C"). Self-references and duplicates are ignored (with a warning).

## 4. Directed / undirected
**Directed.** (Undirected view is used only to count weakly connected components.)

## 5. Weighted / unweighted
**Unweighted** (every edge = one "must come before" relation).

## 6. Real data used
Built at startup from `CourseDatabase.getAllCourses()` (i.e. `data/courses.txt` through
`FileHandler`): course names + `getPrerequisites()`. Nothing is hard-coded. For the shipped
dataset: 18 vertices (14 courses + 4 foundations), 16 edges, 3 weakly connected components (the
large cluster plus the two prerequisite-free courses Computer Networking and UI/UX Design), no cycle.
Live numbers: `/api/graph`.

## 7. Algorithms (all hand-written, arrays + manual queues; no Collections algorithms)
1. **Kahn's topological sort** (BFS on in-degrees) — global learning order and **cycle detection**
   (vertices never reaching in-degree 0 are in/after a cycle).
2. **Longest-path DP over the topological order** — `level[v] = 1 + max(level[u])`; gives each
   vertex's depth, and the length of the longest chain (the minimum number of "stages").
   Vertices that Kahn cannot process (on or downstream of a cycle) always get `level = -1`
   (Phase 4 fix: previously a cycle vertex that also had a normal outside prerequisite kept a
   non-negative level, so a path into such a cycle was wrongly reported as `OK`).
3. **Reverse peeling** (Kahn on out-degrees) — isolates the cyclic core when a cycle exists.
4. **Reverse BFS from a target** — collects exactly the prerequisites needed, stopping at things
   the student already knows.
5. **Semester scheduling (layered Kahn with a per-semester cap)** — takes the needed sub-graph and
   assigns courses to semesters 1..k with at most `cap` courses each, never before their prerequisites.
   This is a greedy plan (ready courses are taken in vertex order): it is always valid, but with a
   cap it is not guaranteed to use the fewest possible semesters; `minSemesters` (longest chain)
   is the lower bound.
6. **Forward BFS** — "what does this course unlock", with distance.
7. **BFS on the undirected view** — weakly connected components (finds disconnected courses).

## 8. Why appropriate
Prerequisites form a partial order; a topological order is exactly a valid study order, and the
algorithm doubles as a data-integrity check (a dataset typo that creates A↔B is reported instead of
looping forever or silently giving a wrong plan).

## 9. Input
* Graph: the loaded course list.
* Learning path: `target` course id, optional `known` list (skills/qualifications/courses the
  student has; matched exactly or with the existing Edit-Distance similarity ≥ 65%, the same rule
  the eligibility check uses), optional `perSemester` cap (default 2, clamped to 1..6).

## 10. Output
* Overview: vertices, edges, topological order, level per vertex, components, cycle info, warnings.
* Learning path: ordered steps (foundations first, then courses by semester), skipped-known items,
  semesters needed, minimum semesters with no cap, status (`OK`, `ALREADY_KNOWN`, `BLOCKED_BY_CYCLE`).
* Unlocks: all courses reachable from a course with BFS distance.

## 11. Time complexity
V vertices, E edges. Build: O(V·E) worst case in this simple version (linear name lookup and
duplicate-edge scan; fine for a catalog, and easy to explain). Kahn + level DP: O(V+E). Reverse
BFS, forward BFS, components: O(V+E). Scheduling: O(R·V) for R semesters, i.e. O(V²) worst case (a pure chain); fine for catalog sizes. Known-matching: O(V·K·L²) (K known items, L name length) via Edit Distance.

## 12. Space complexity
O(V + E) for adjacency lists, in-degree and level arrays.

## 13. Integration
* `CourseGraph.java` (new) built once in `WebServer` from the existing `CourseDatabase`.
* New GET endpoints in the existing style: `/api/graph`, `/api/path?target=&known=&perSemester=`,
  `/api/unlocks?id=`; `/api/status` gains `graphNodes`/`graphEdges`.
* Course details page gets two sections: "What this unlocks" and "Learning path to this course".
* Phase 1 (FileHandler/data file) and Phase 2 (Trie) untouched; Edit Distance is reused, not copied.
