import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * CourseTrie.java
 * ---------------------------------------------------------
 * Responsibility (single, focused):
 *   - Prefix tree (Trie) over course names for fast, case-insensitive
 *     prefix search / autocomplete.
 *
 * Structure:
 *   - TrieNode = one character position. It has up to 128 child links
 *     (one per ASCII character, so children are visited in alphabetical order),
 *     and a list of the courses whose key ENDS at this node (end-of-word info).
 *   - The path from the root to a node spells a prefix. Every course whose
 *     name starts with that prefix lives somewhere in that node's subtree.
 *   - Robustness (Phase 4): every end-of-word entry also remembers its full lower-cased key,
 *     and results are confirmed against it. So (a) all non-ASCII characters may share one child
 *     slot without ever producing a wrong match, and (b) the path is capped at MAX_DEPTH
 *     characters, which bounds recursion depth and memory for absurdly long names.
 *
 * Complexity (m = length of the key/prefix, k = number of matches, N = total characters stored):
 *   - insert        : O(m)
 *   - prefix lookup : O(m) to reach the prefix node + O(size of its subtree) to collect results
 *   - space         : O(N) nodes worst case (shared prefixes are stored once)
 *   - Scanning every course name instead costs O(courses * m) for EVERY keystroke.
 */
public class CourseTrie {

    private static final int ALPHABET = 128; // ASCII; any other character shares slot 127
    private static final int MAX_DEPTH = 64;  // longest root-to-node path; longer keys are verified against the stored key

    /** One node of the Trie. */
    private static class TrieNode {
        final TrieNode[] children = new TrieNode[ALPHABET];
        // Non-empty only where a key ends (end-of-word marker). A list because
        // two courses may share the same name.
        final List<CourseDatabase.Course> endingHere = new ArrayList<>();
        // Full lower-cased key of each entry in endingHere (same index) - used to confirm a prefix match.
        final List<String> endingKeys = new ArrayList<>();
    }

    private final TrieNode root = new TrieNode();
    private int nodeCount = 1;
    private int keyCount = 0;

    private static int slot(char c) {
        return c < ALPHABET ? c : ALPHABET - 1;
    }

    /** Inserts a key (lower-cased) and links the course to the node where the key ends. O(m). */
    public void insert(String key, CourseDatabase.Course course) {
        if (key == null || course == null) return;
        String k = key.trim().toLowerCase(Locale.ROOT);
        if (k.isEmpty()) return;

        TrieNode cur = root;
        int depth = Math.min(k.length(), MAX_DEPTH);
        for (int i = 0; i < depth; i++) {
            int idx = slot(k.charAt(i));
            if (cur.children[idx] == null) {
                cur.children[idx] = new TrieNode();
                nodeCount++;
            }
            cur = cur.children[idx];
        }
        // Skip the exact same course being added twice with the same key.
        for (int i = 0; i < cur.endingHere.size(); i++) {
            if (cur.endingHere.get(i).getId() == course.getId() && cur.endingKeys.get(i).equals(k)) return;
        }
        cur.endingHere.add(course);
        cur.endingKeys.add(k);
        keyCount++;
    }

    /**
     * Returns the courses having a key that starts with prefix (case-insensitive),
     * in alphabetical key order, without duplicate courses. Empty prefix -> empty list.
     */
    public List<CourseDatabase.Course> startsWith(String prefix) {
        List<CourseDatabase.Course> out = new ArrayList<>();
        if (prefix == null) return out;
        String p = prefix.trim().toLowerCase(Locale.ROOT);
        if (p.isEmpty()) return out;

        // 1) Walk down the prefix (at most MAX_DEPTH characters): O(m).
        TrieNode cur = root;
        int depth = Math.min(p.length(), MAX_DEPTH);
        for (int i = 0; i < depth; i++) {
            cur = cur.children[slot(p.charAt(i))];
            if (cur == null) return out; // no key has this prefix
        }
        // 2) Collect everything in the subtree (depth-first = alphabetical), keeping only real prefix matches.
        collect(cur, p, out);
        return out;
    }

    private void collect(TrieNode node, String prefix, List<CourseDatabase.Course> out) {
        for (int i = 0; i < node.endingHere.size(); i++) {
            CourseDatabase.Course c = node.endingHere.get(i);
            if (node.endingKeys.get(i).startsWith(prefix) && !containsId(out, c.getId())) out.add(c);
        }
        for (int i = 0; i < ALPHABET; i++) {
            if (node.children[i] != null) collect(node.children[i], prefix, out);
        }
    }

    private static boolean containsId(List<CourseDatabase.Course> list, int id) {
        for (CourseDatabase.Course c : list) if (c.getId() == id) return true;
        return false;
    }

    public int getNodeCount() { return nodeCount; }
    public int getKeyCount() { return keyCount; }
}
