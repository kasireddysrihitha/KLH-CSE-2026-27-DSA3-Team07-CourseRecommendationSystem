import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * FileHandler.java
 * ---------------------------------------------------------
 * Responsibility (single, focused):
 *   - Read the external course dataset file (data/courses.txt)
 *   - Parse every line into a CourseDatabase.Course object
 *   - Validate each record; skip bad ones and report why
 *
 * File format (one course per line, 8 fields separated by '|'):
 *   id|name|category|description|prerequisites|requiredSkills|careerPaths|interestTags
 * List fields use ';' between items. Only prerequisites may be empty.
 * Blank lines and lines starting with '#' are ignored.
 *
 * This class never throws for bad data or a bad file - it always returns a
 * LoadResult holding the valid courses plus human-readable messages.
 */
public class FileHandler {

    private static final int FIELD_COUNT = 8;

    /** Outcome of one load attempt: valid courses + warnings + a fatal error (if any). */
    public static class LoadResult {
        public final List<CourseDatabase.Course> courses = new ArrayList<>();
        public final List<String> warnings = new ArrayList<>();
        public String error = null;   // set when the file itself could not be used
        public int linesSkipped = 0;
    }

    /** Reads and parses the dataset file at the given path. */
    public static LoadResult loadCourses(String path) {
        LoadResult result = new LoadResult();
        File file = new File(path);

        // 1. Missing file / not a regular file / unreadable
        if (!file.exists()) {
            result.error = "Dataset file not found: " + file.getAbsolutePath();
            return result;
        }
        if (!file.isFile() || !file.canRead()) {
            result.error = "Dataset path is not a readable file: " + file.getAbsolutePath();
            return result;
        }

        // 2. Read line by line (try-with-resources closes the reader automatically)
        Set<Integer> seenIds = new HashSet<>();
        int lineNumber = 0;
        try (BufferedReader reader = Files.newBufferedReader(file.toPath(), StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                if (lineNumber == 1 && line.startsWith("\uFEFF")) {
                    line = line.substring(1);              // strip a UTF-8 BOM if present
                }
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;   // blank / comment

                String problem = parseLine(line, seenIds, result);
                if (problem != null) {
                    result.linesSkipped++;
                    result.warnings.add("Line " + lineNumber + " skipped: " + problem);
                }
            }
        } catch (IOException e) {
            // Includes malformed UTF-8 (MalformedInputException is an IOException)
            result.error = "Could not read dataset file (" + e.getClass().getSimpleName()
                    + ": " + e.getMessage() + ")";
            return result;
        }

        // 3. File was readable but contained no usable course
        if (result.courses.isEmpty()) {
            result.error = "Dataset file contains no valid courses: " + file.getAbsolutePath();
        }
        return result;
    }

    /**
     * Parses and validates one record line. On success adds the Course to the
     * result and returns null; otherwise returns the reason it was rejected.
     */
    private static String parseLine(String line, Set<Integer> seenIds, LoadResult result) {
        String[] f = line.split("\\|", -1);   // -1 keeps trailing empty fields
        if (f.length != FIELD_COUNT) {
            return "expected " + FIELD_COUNT + " fields separated by '|' but found " + f.length;
        }

        int id;
        try {
            id = Integer.parseInt(f[0].trim());
        } catch (NumberFormatException e) {
            return "course id '" + f[0].trim() + "' is not a number";
        }
        if (id <= 0) return "course id must be positive (got " + id + ")";
        if (seenIds.contains(id)) return "duplicate course id " + id;

        String name = f[1].trim();
        String category = f[2].trim();
        String description = f[3].trim();
        if (name.isEmpty()) return "course name is empty";
        if (category.isEmpty()) return "category is empty";
        if (description.isEmpty()) return "description is empty";

        List<String> prerequisites = splitList(f[4]);          // may be empty
        List<String> requiredSkills = splitList(f[5]);
        List<String> careerPaths = splitList(f[6]);
        List<String> interestTags = splitList(f[7]);
        if (requiredSkills.isEmpty()) return "required skills are empty";
        if (careerPaths.isEmpty()) return "career paths are empty";
        if (interestTags.isEmpty()) return "interest tags are empty";

        seenIds.add(id);
        result.courses.add(new CourseDatabase.Course(id, name, category, description,
                prerequisites, requiredSkills, careerPaths, interestTags));
        return null;
    }

    /** "A;B;C" -> [A, B, C]; ignores blank items. */
    private static List<String> splitList(String field) {
        List<String> items = new ArrayList<>();
        for (String part : field.split(";")) {
            String trimmed = part.trim();
            if (!trimmed.isEmpty()) items.add(trimmed);
        }
        return items;
    }
}
