import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * WebServer.java
 * ---------------------------------------------------------
 * Responsibility (single, focused):
 *   - Start a small HTTP server (JDK built-in, no external libraries)
 *   - Expose the EXISTING RecommendationEngine / SearchEngine / CourseDatabase
 *     over a tiny JSON API so a browser frontend can use them
 *   - Serve the static frontend (HTML/CSS/JS) from the "public" folder
 *
 * This class is purely a delivery mechanism. It creates the same
 * CourseDatabase / RecommendationEngine / SearchEngine used by the console
 * app (Main.java) and simply calls their existing public methods - none of
 * the DSA logic (KMP, Rabin-Karp, Edit Distance, Merge Sort) is duplicated
 * or reimplemented here.
 *
 * Run with:  java -cp bin WebServer
 * Then open: http://localhost:8080
 */
public class WebServer {

    private static final int PORT = 8080;
    private static final String PUBLIC_DIR = "public";

    private static final CourseDatabase database = new CourseDatabase();
    private static final RecommendationEngine recommendationEngine = new RecommendationEngine(database);
    private static final SearchEngine searchEngine = new SearchEngine(database);
    // Phase 3: prerequisite graph built from the same loaded dataset
    private static final CourseGraph courseGraph = new CourseGraph(database);

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);

        // ---- JSON API endpoints (all GET, query-string based - no request body parsing needed) ----
        server.createContext("/api/status", WebServer::handleStatus);
        server.createContext("/api/courses", WebServer::handleCourses);
        server.createContext("/api/course", WebServer::handleCourse);
        server.createContext("/api/search", WebServer::handleSearch);
        server.createContext("/api/suggest", WebServer::handleSuggest);
        server.createContext("/api/categories", WebServer::handleCategories);
        server.createContext("/api/recommend", WebServer::handleRecommend);
        server.createContext("/api/compare", WebServer::handleCompare);
        server.createContext("/api/graph", WebServer::handleGraph);
        server.createContext("/api/path", WebServer::handlePath);
        server.createContext("/api/unlocks", WebServer::handleUnlocks);

        // ---- Static frontend files ----
        server.createContext("/", WebServer::handleStatic);

        server.setExecutor(null);
        server.start();

        System.out.println("========================================");
        System.out.println(" Course Recommendation System - Web Server");
        System.out.println("========================================");
        System.out.println("Frontend + API running at: http://localhost:" + PORT);
        System.out.println("Press Ctrl+C to stop.");
    }

    // ------------------------------------------------------------
    // GET /api/status -> simple dashboard stats
    // ------------------------------------------------------------
    private static void handleStatus(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equalsIgnoreCase("GET")) { methodNotAllowed(ex); return; }
        String json = "{"
                + "\"totalCourses\":" + database.getAllCourses().size() + ","
                + "\"recommendationEngine\":\"Active\","
                + "\"searchAlgorithms\":\"KMP + Rabin-Karp + Edit Distance + Trie (prefix autocomplete)\","
                + "\"graphNodes\":" + courseGraph.vertexCount() + ","
                + "\"graphEdges\":" + courseGraph.edgeCount()
                + "}";
        sendJson(ex, 200, json);
    }

    // ------------------------------------------------------------
    // GET /api/courses -> all courses (Explore page)
    // ------------------------------------------------------------
    private static void handleCourses(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equalsIgnoreCase("GET")) { methodNotAllowed(ex); return; }
        sendJson(ex, 200, JsonUtil.courseArray(database.getAllCourses()));
    }

    // ------------------------------------------------------------
    // GET /api/course?id=X -> single course details
    // ------------------------------------------------------------
    private static void handleCourse(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equalsIgnoreCase("GET")) { methodNotAllowed(ex); return; }
        Map<String, String> params = queryParams(ex);
        int id = parseIntOrDefault(params.get("id"), -1);
        CourseDatabase.Course course = database.getCourseById(id);
        if (course == null) {
            sendJson(ex, 404, "{\"error\":\"Course not found\"}");
            return;
        }
        sendJson(ex, 200, JsonUtil.course(course));
    }

    // ------------------------------------------------------------
    // GET /api/search?q=... -> uses the existing SearchEngine
    // (KMP + Rabin-Karp + Edit Distance fallback, unchanged)
    // ------------------------------------------------------------
    private static void handleSearch(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equalsIgnoreCase("GET")) { methodNotAllowed(ex); return; }
        Map<String, String> params = queryParams(ex);
        String q = params.getOrDefault("q", "").trim();
        if (q.isEmpty()) {
            sendJson(ex, 200, "[]");
            return;
        }
        List<SearchEngine.SearchResult> results = searchEngine.search(q);
        sendJson(ex, 200, JsonUtil.searchResultArray(results));
    }

    // ------------------------------------------------------------
    // GET /api/suggest?q=Mach -> Trie prefix autocomplete on course names
    // ------------------------------------------------------------
    private static void handleSuggest(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equalsIgnoreCase("GET")) { methodNotAllowed(ex); return; }
        Map<String, String> params = queryParams(ex);
        String q = params.getOrDefault("q", "").trim();
        List<CourseDatabase.Course> matches = searchEngine.suggestCourses(q, 8);
        sendJson(ex, 200, JsonUtil.courseArray(matches));
    }

    // ------------------------------------------------------------
    // GET /api/categories -> distinct list of course categories
    // (used by the frontend to power the search-bar autocomplete)
    // ------------------------------------------------------------
    private static void handleCategories(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equalsIgnoreCase("GET")) { methodNotAllowed(ex); return; }
        sendJson(ex, 200, JsonUtil.arr(database.getAllCategories()));
    }

    // ------------------------------------------------------------
    // GET /api/recommend?interests=&skills=&qualifications=&careerGoals=
    // (comma-separated, same shape as the console app's input)
    // uses the existing RecommendationEngine (fuzzy match + Merge Sort, unchanged)
    // ------------------------------------------------------------
    private static void handleRecommend(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equalsIgnoreCase("GET")) { methodNotAllowed(ex); return; }
        Map<String, String> params = queryParams(ex);

        List<String> interests = splitCsv(params.get("interests"));
        List<String> skills = splitCsv(params.get("skills"));
        List<String> qualifications = splitCsv(params.get("qualifications"));
        List<String> careerGoals = splitCsv(params.get("careerGoals"));

        RecommendationEngine.StudentProfile profile =
                new RecommendationEngine.StudentProfile(interests, skills, qualifications, careerGoals);

        List<RecommendationEngine.ScoredCourse> results = recommendationEngine.recommend(profile);

        // Mirror the console app: only positive-score matches, top 5.
        List<RecommendationEngine.ScoredCourse> topResults = new ArrayList<>();
        for (RecommendationEngine.ScoredCourse sc : results) {
            if (topResults.size() >= 5) break;
            if (sc.score <= 0.0) continue;
            topResults.add(sc);
        }

        sendJson(ex, 200, JsonUtil.scoredCourseArray(topResults));
    }

    // ------------------------------------------------------------
    // GET /api/compare?id1=X&id2=Y
    // ------------------------------------------------------------
    private static void handleCompare(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equalsIgnoreCase("GET")) { methodNotAllowed(ex); return; }
        Map<String, String> params = queryParams(ex);
        int id1 = parseIntOrDefault(params.get("id1"), -1);
        int id2 = parseIntOrDefault(params.get("id2"), -1);

        CourseDatabase.Course c1 = database.getCourseById(id1);
        CourseDatabase.Course c2 = database.getCourseById(id2);

        if (c1 == null || c2 == null) {
            sendJson(ex, 404, "{\"error\":\"One or both course IDs are invalid\"}");
            return;
        }

        String json = "{\"course1\":" + JsonUtil.course(c1) + ",\"course2\":" + JsonUtil.course(c2) + "}";
        sendJson(ex, 200, json);
    }

    // ------------------------------------------------------------
    // GET /api/graph -> prerequisite graph overview (nodes, edges, topological order, cycles)
    // ------------------------------------------------------------
    private static void handleGraph(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equalsIgnoreCase("GET")) { methodNotAllowed(ex); return; }
        sendJson(ex, 200, JsonUtil.graphOverview(courseGraph));
    }

    // ------------------------------------------------------------
    // GET /api/path?target=ID&known=a,b&perSemester=2 -> learning path to a course
    // (reverse BFS + layered topological scheduling on the prerequisite graph)
    // ------------------------------------------------------------
    private static void handlePath(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equalsIgnoreCase("GET")) { methodNotAllowed(ex); return; }
        Map<String, String> params = queryParams(ex);
        int target = parseIntOrDefault(params.get("target"), -1);
        int per = parseIntOrDefault(params.get("perSemester"), CourseGraph.DEFAULT_PER_SEMESTER);
        CourseGraph.PathResult r = courseGraph.learningPath(target, splitCsv(params.get("known")), per);
        sendJson(ex, r.status.equals("NOT_FOUND") ? 404 : 200, JsonUtil.learningPath(r));
    }

    // ------------------------------------------------------------
    // GET /api/unlocks?id=X -> courses that become reachable after course X (forward BFS)
    // ------------------------------------------------------------
    private static void handleUnlocks(HttpExchange ex) throws IOException {
        if (!ex.getRequestMethod().equalsIgnoreCase("GET")) { methodNotAllowed(ex); return; }
        Map<String, String> params = queryParams(ex);
        int id = parseIntOrDefault(params.get("id"), -1);
        CourseDatabase.Course c = database.getCourseById(id);
        if (c == null) { sendJson(ex, 404, "{\"error\":\"Course not found\"}"); return; }
        sendJson(ex, 200, JsonUtil.unlocks(id, c.getName(), courseGraph.unlocks(id)));
    }

    // ------------------------------------------------------------
    // Static file serving for the frontend (public/ folder)
    // ------------------------------------------------------------
    private static void handleStatic(HttpExchange ex) throws IOException {
        String path = ex.getRequestURI().getPath();
        if (path.equals("/")) path = "/index.html";
        // Strip the leading slash so File(parent, child) resolves as a relative child path
        // on every platform (an absolute-looking child string is handled inconsistently).
        String relativePath = path.startsWith("/") ? path.substring(1) : path;

        File file;
        File publicRoot;
        try {
            file = new File(PUBLIC_DIR, relativePath).getCanonicalFile();
            publicRoot = new File(PUBLIC_DIR).getCanonicalFile();
        } catch (IOException e) {
            // illegal path (e.g. a NUL byte from "%00"): answer 404 instead of dropping the connection
            sendText(ex, 404, "404 Not Found");
            return;
        }

        // The file must be INSIDE public/. The separator matters: a bare startsWith("…/public")
        // would also accept a sibling folder such as "…/public_old".
        if (!file.getPath().startsWith(publicRoot.getPath() + File.separator) || !file.isFile()) {
            sendText(ex, 404, "404 Not Found");
            return;
        }

        String contentType = guessContentType(file.getName());
        byte[] bytes = Files.readAllBytes(file.toPath());
        ex.getResponseHeaders().set("Content-Type", contentType);
        ex.sendResponseHeaders(200, bytes.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(bytes);
        }
    }

    private static String guessContentType(String name) {
        if (name.endsWith(".html")) return "text/html; charset=utf-8";
        if (name.endsWith(".css")) return "text/css; charset=utf-8";
        if (name.endsWith(".js")) return "application/javascript; charset=utf-8";
        if (name.endsWith(".json")) return "application/json; charset=utf-8";
        if (name.endsWith(".svg")) return "image/svg+xml";
        if (name.endsWith(".png")) return "image/png";
        return "application/octet-stream";
    }

    // ------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------
    private static void sendJson(HttpExchange ex, int status, String json) throws IOException {
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        ex.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        ex.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(bytes);
        }
    }

    private static void sendText(HttpExchange ex, int status, String text) throws IOException {
        byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        ex.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(bytes);
        }
    }

    private static void methodNotAllowed(HttpExchange ex) throws IOException {
        sendJson(ex, 405, "{\"error\":\"Method not allowed\"}");
    }

    private static Map<String, String> queryParams(HttpExchange ex) {
        Map<String, String> map = new HashMap<>();
        String query = ex.getRequestURI().getRawQuery();
        if (query == null || query.isEmpty()) return map;
        for (String pair : query.split("&")) {
            int eq = pair.indexOf('=');
            try {
                if (eq >= 0) {
                    String key = URLDecoder.decode(pair.substring(0, eq), "UTF-8");
                    String value = URLDecoder.decode(pair.substring(eq + 1), "UTF-8");
                    map.put(key, value);
                } else {
                    map.put(URLDecoder.decode(pair, "UTF-8"), "");
                }
            } catch (Exception ignored) {
                // Skip malformed query parameters.
            }
        }
        return map;
    }

    private static List<String> splitCsv(String value) {
        List<String> result = new ArrayList<>();
        if (value == null || value.trim().isEmpty()) return result;
        for (String part : value.split(",")) {
            String trimmed = part.trim();
            if (!trimmed.isEmpty()) result.add(trimmed);
        }
        return result;
    }

    private static int parseIntOrDefault(String value, int def) {
        if (value == null) return def;
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }
}
