import java.util.ArrayList;
import java.util.List;

/**
 * CourseDatabase.java
 * ---------------------------------------------------------
 * Responsibility (single, focused):
 *   - Define the Course data model
 *   - Hold the in-memory course dataset (loaded from data/courses.txt by FileHandler)
 *   - Provide simple retrieval operations (by id, get all)
 *
 * No DSA search/recommendation logic lives here on purpose -
 * this file is pure data + data access.
 */
public class CourseDatabase {

    /** Course model: one record of the dataset. */
    public static class Course {
        private final int id;
        private final String name;
        private final String category;
        private final String description;
        private final List<String> prerequisites;   // e.g. ["Basic Programming", "Statistics"]
        private final List<String> requiredSkills;   // e.g. ["Python", "Linear Algebra"]
        private final List<String> careerPaths;      // e.g. ["Data Scientist", "ML Engineer"]
        private final List<String> interestTags;     // e.g. ["Machine Learning", "AI", "Data"]

        public Course(int id, String name, String category, String description,
                      List<String> prerequisites, List<String> requiredSkills,
                      List<String> careerPaths, List<String> interestTags) {
            this.id = id;
            this.name = name;
            this.category = category;
            this.description = description;
            this.prerequisites = prerequisites;
            this.requiredSkills = requiredSkills;
            this.careerPaths = careerPaths;
            this.interestTags = interestTags;
        }

        public int getId() { return id; }
        public String getName() { return name; }
        public String getCategory() { return category; }
        public String getDescription() { return description; }
        public List<String> getPrerequisites() { return prerequisites; }
        public List<String> getRequiredSkills() { return requiredSkills; }
        public List<String> getCareerPaths() { return careerPaths; }
        public List<String> getInterestTags() { return interestTags; }

        /** Short one-line summary, used in list views. */
        public String toBriefString() {
            return String.format("[%02d] %-28s | %-20s", id, name, category);
        }

        /** Full detail view. */
        public String toDetailString() {
            StringBuilder sb = new StringBuilder();
            sb.append("Course ID       : ").append(id).append("\n");
            sb.append("Name            : ").append(name).append("\n");
            sb.append("Category        : ").append(category).append("\n");
            sb.append("Description     : ").append(description).append("\n");
            sb.append("Prerequisites   : ").append(prerequisites.isEmpty() ? "None" : String.join(", ", prerequisites)).append("\n");
            sb.append("Required Skills : ").append(String.join(", ", requiredSkills)).append("\n");
            sb.append("Career Paths    : ").append(String.join(", ", careerPaths)).append("\n");
            return sb.toString();
        }
    }

    private final List<Course> courses;

    /** Default dataset location (relative to the folder the program is run from). */
    public static final String DEFAULT_DATA_FILE = "data/courses.txt";

    /** Uses data/courses.txt, or the path in -Dcourses.file=... if given. */
    public CourseDatabase() {
        this(System.getProperty("courses.file", DEFAULT_DATA_FILE));
    }

    public CourseDatabase(String dataFilePath) {
        courses = new ArrayList<>();
        loadFromFile(dataFilePath);
    }

    /** Loads courses via FileHandler. A bad/missing file leaves the database empty (no crash). */
    private void loadFromFile(String path) {
        FileHandler.LoadResult result = FileHandler.loadCourses(path);
        courses.addAll(result.courses);
        for (String w : result.warnings) {
            System.err.println("[CourseDatabase] WARNING: " + w);
        }
        if (result.error != null) {
            System.err.println("[CourseDatabase] ERROR: " + result.error);
        }
        System.out.println("[CourseDatabase] Loaded " + courses.size() + " course(s) from " + path
                + (result.linesSkipped > 0 ? " (" + result.linesSkipped + " invalid line(s) skipped)" : ""));
    }

    public List<Course> getAllCourses() {
        return courses;
    }

    public Course getCourseById(int id) {
        for (Course c : courses) {
            if (c.getId() == id) return c;
        }
        return null;
    }

    /** Distinct list of course categories, alphabetically sorted (used for search suggestions). */
    public List<String> getAllCategories() {
        List<String> categories = new ArrayList<>();
        for (Course c : courses) {
            if (!categories.contains(c.getCategory())) {
                categories.add(c.getCategory());
            }
        }
        categories.sort(String::compareToIgnoreCase);
        return categories;
    }
}
