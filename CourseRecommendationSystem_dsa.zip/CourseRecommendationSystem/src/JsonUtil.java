import java.util.List;
import java.util.Locale;

/**
 * JsonUtil.java
 * ---------------------------------------------------------
 * Responsibility (single, focused):
 *   - Turn existing model objects (Course, ScoredCourse, SearchResult)
 *     into JSON text so the browser frontend can render them.
 *
 * This is presentation plumbing only. It does not touch, duplicate or
 * reimplement any of the DSA logic in SearchEngine / RecommendationEngine -
 * it just reads the already-computed fields off those objects.
 */
public class JsonUtil {

    /** Escapes a string for safe embedding inside a JSON value. */
    public static String esc(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        return sb.toString();
    }

    /** Renders a List<String> as a JSON array of strings. */
    public static String arr(List<String> items) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < items.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append("\"").append(esc(items.get(i))).append("\"");
        }
        sb.append("]");
        return sb.toString();
    }

    /** Renders a single Course as a JSON object. */
    public static String course(CourseDatabase.Course c) {
        return "{"
                + "\"id\":" + c.getId() + ","
                + "\"name\":\"" + esc(c.getName()) + "\","
                + "\"category\":\"" + esc(c.getCategory()) + "\","
                + "\"description\":\"" + esc(c.getDescription()) + "\","
                + "\"prerequisites\":" + arr(c.getPrerequisites()) + ","
                + "\"requiredSkills\":" + arr(c.getRequiredSkills()) + ","
                + "\"careerPaths\":" + arr(c.getCareerPaths()) + ","
                + "\"interestTags\":" + arr(c.getInterestTags())
                + "}";
    }

    /** Renders a list of courses as a JSON array. */
    public static String courseArray(List<CourseDatabase.Course> courses) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < courses.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(course(courses.get(i)));
        }
        sb.append("]");
        return sb.toString();
    }

    /** Renders a ScoredCourse (recommendation engine output) as a JSON object. */
    public static String scoredCourse(RecommendationEngine.ScoredCourse sc) {
        return "{"
                + "\"course\":" + course(sc.course) + ","
                + "\"score\":" + String.format(Locale.US, "%.1f", sc.score) + ","
                + "\"eligible\":" + sc.eligible + ","
                + "\"missingPrerequisites\":" + arr(sc.missingPrerequisites)
                + "}";
    }

    /** Renders a list of ScoredCourse as a JSON array. */
    public static String scoredCourseArray(List<RecommendationEngine.ScoredCourse> list) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(scoredCourse(list.get(i)));
        }
        sb.append("]");
        return sb.toString();
    }

    /** Renders a SearchResult (search engine output) as a JSON object. */
    public static String searchResult(SearchEngine.SearchResult r) {
        return "{"
                + "\"course\":" + course(r.course) + ","
                + "\"confidence\":" + String.format(Locale.US, "%.0f", r.confidence)
                + "}";
    }

    /** Renders a list of SearchResult as a JSON array. */
    public static String searchResultArray(List<SearchEngine.SearchResult> list) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(searchResult(list.get(i)));
        }
        sb.append("]");
        return sb.toString();
    }

    // ------------------------------------------------------------------
    // Phase 3: graph output (CourseGraph results -> JSON)
    // ------------------------------------------------------------------
    public static String graphOverview(CourseGraph g) {
        CourseGraph.TopoResult t = g.topologicalSort();
        int[] comp = g.weakComponents();
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"vertices\":").append(g.vertexCount()).append(",");
        sb.append("\"edges\":").append(g.edgeCount()).append(",");
        sb.append("\"hasCycle\":").append(t.hasCycle).append(",");
        sb.append("\"components\":").append(g.componentCount(comp)).append(",");
        sb.append("\"blocked\":").append(arr(t.blocked)).append(",");
        sb.append("\"cyclicCore\":").append(arr(t.cyclicCore)).append(",");
        sb.append("\"warnings\":").append(arr(g.getWarnings())).append(",");
        int maxLevel = 0;
        for (int l : t.level) if (l > maxLevel) maxLevel = l;
        sb.append("\"longestChain\":").append(maxLevel).append(",");
        sb.append("\"nodes\":[");
        for (int v = 0; v < g.vertexCount(); v++) {
            if (v > 0) sb.append(",");
            sb.append("{\"name\":\"").append(esc(g.nameOf(v))).append("\",")
              .append("\"type\":\"").append(g.isCourse(v) ? "course" : "foundation").append("\",")
              .append("\"courseId\":").append(g.isCourse(v) ? g.courseIdOf(v) : 0).append(",")
              .append("\"level\":").append(t.level[v]).append(",")
              .append("\"component\":").append(comp[v]).append(",")
              .append("\"prerequisites\":").append(arr(g.prerequisitesOf(v))).append(",")
              .append("\"unlocks\":").append(arr(g.unlocksDirect(v))).append("}");
        }
        sb.append("],\"topologicalOrder\":[");
        for (int i = 0; i < t.order.length; i++) {
            if (i > 0) sb.append(",");
            sb.append("\"").append(esc(g.nameOf(t.order[i]))).append("\"");
        }
        sb.append("]}");
        return sb.toString();
    }

    public static String learningPath(CourseGraph.PathResult r) {
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"status\":\"").append(r.status).append("\",");
        sb.append("\"targetCourseId\":").append(r.targetCourseId).append(",");
        sb.append("\"target\":\"").append(esc(r.targetName)).append("\",");
        sb.append("\"perSemester\":").append(r.perSemester).append(",");
        sb.append("\"semesters\":").append(r.semesters).append(",");
        sb.append("\"minSemesters\":").append(r.minSemesters).append(",");
        sb.append("\"alreadyKnown\":").append(arr(r.alreadyKnown)).append(",");
        sb.append("\"blocked\":").append(arr(r.blocked)).append(",");
        sb.append("\"steps\":[");
        for (int i = 0; i < r.steps.size(); i++) {
            CourseGraph.PathStep st = r.steps.get(i);
            if (i > 0) sb.append(",");
            sb.append("{\"name\":\"").append(esc(st.name)).append("\",")
              .append("\"type\":\"").append(st.course ? "course" : "foundation").append("\",")
              .append("\"courseId\":").append(st.courseId).append(",")
              .append("\"semester\":").append(st.semester).append(",")
              .append("\"requires\":").append(arr(st.requires)).append("}");
        }
        sb.append("]}");
        return sb.toString();
    }

    public static String unlocks(int courseId, String name, List<CourseGraph.Reach> list) {
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"courseId\":").append(courseId).append(",\"course\":\"").append(esc(name)).append("\",\"unlocks\":[");
        for (int i = 0; i < list.size(); i++) {
            CourseGraph.Reach r = list.get(i);
            if (i > 0) sb.append(",");
            sb.append("{\"courseId\":").append(r.courseId).append(",\"name\":\"").append(esc(r.name))
              .append("\",\"distance\":").append(r.distance).append("}");
        }
        sb.append("]}");
        return sb.toString();
    }
}
