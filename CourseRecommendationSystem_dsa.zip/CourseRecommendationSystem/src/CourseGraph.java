import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * CourseGraph.java  (Phase 3: Graph)
 * ---------------------------------------------------------
 * Directed prerequisite graph built from the REAL course dataset.
 *   vertex = a course, or a foundation topic named as a prerequisite that is not a course
 *   edge   = P -> C  when P is a prerequisite of course C ("P comes before C")
 *
 * Algorithms (hand-written; only arrays and a tiny int-list are used internally):
 *   - Kahn's topological sort + cycle detection + longest-path levels (DP)
 *   - Reverse peeling to find the cyclic core
 *   - Reverse BFS (needed prerequisites), forward BFS (unlocks)
 *   - Layered Kahn scheduling with a per-semester cap
 *   - BFS on the undirected view (weakly connected components)
 * See GRAPH_DESIGN.md.
 */
public class CourseGraph {

    public static final double KNOWN_MATCH_THRESHOLD = 65.0;   // same as RecommendationEngine fuzzy rule
    public static final int DEFAULT_PER_SEMESTER = 2;

    /** Minimal growable int array (so we don't need ArrayList<Integer> for adjacency). */
    private static class IntList {
        int[] a = new int[4];
        int size = 0;
        void add(int x) {
            if (size == a.length) {
                int[] b = new int[size * 2];
                for (int i = 0; i < size; i++) b[i] = a[i];
                a = b;
            }
            a[size++] = x;
        }
        boolean contains(int x) {
            for (int i = 0; i < size; i++) if (a[i] == x) return true;
            return false;
        }
    }

    // ---------------- graph storage ----------------
    private String[] names;
    private boolean[] isCourse;
    private int[] courseIds;
    private IntList[] out;   // out[u] = vertices that u unlocks
    private IntList[] in;    // in[v]  = direct prerequisites of v
    private int n = 0;
    private int edgeCount = 0;
    private final List<String> warnings = new ArrayList<>();

    // ---------------- result types ----------------
    public static class TopoResult {
        public int[] order;          // vertices in valid learning order (only the processable ones)
        public int[] level;          // longest-path depth; -1 if the vertex is blocked by a cycle
        public boolean hasCycle;
        public List<String> blocked = new ArrayList<>();      // everything Kahn could not process
        public List<String> cyclicCore = new ArrayList<>();   // vertices on / between cycles
    }

    public static class PathStep {
        public final int node;
        public final String name;
        public final boolean course;
        public final int courseId;     // 0 for foundation topics
        public final int semester;     // 0 = foundation to learn first, 1.. = course semesters
        public final List<String> requires = new ArrayList<>();
        PathStep(int node, String name, boolean course, int courseId, int semester) {
            this.node = node; this.name = name; this.course = course;
            this.courseId = courseId; this.semester = semester;
        }
    }

    public static class PathResult {
        public String status;                 // OK | ALREADY_KNOWN | NOT_FOUND | BLOCKED_BY_CYCLE
        public int targetCourseId;
        public String targetName = "";
        public int perSemester;
        public int semesters;                 // semesters used with the cap
        public int minSemesters;              // semesters with no cap (critical path)
        public final List<PathStep> steps = new ArrayList<>();
        public final List<String> alreadyKnown = new ArrayList<>();  // path items skipped because known
        public final List<String> blocked = new ArrayList<>();
    }

    public static class Reach {
        public final int courseId;
        public final String name;
        public final int distance;
        Reach(int courseId, String name, int distance) {
            this.courseId = courseId; this.name = name; this.distance = distance;
        }
    }

    // ---------------- construction ----------------
    public CourseGraph(List<CourseDatabase.Course> courses) {
        names = new String[8];
        isCourse = new boolean[8];
        courseIds = new int[8];
        out = new IntList[8];
        in = new IntList[8];
        build(courses == null ? new ArrayList<>() : courses);
    }

    public CourseGraph(CourseDatabase db) {
        this(db.getAllCourses());
    }

    private int addNode(String name, boolean course, int courseId) {
        if (n == names.length) grow();
        names[n] = name; isCourse[n] = course; courseIds[n] = courseId;
        out[n] = new IntList(); in[n] = new IntList();
        return n++;
    }

    private void grow() {
        int m = n * 2;
        String[] nn = new String[m]; boolean[] ic = new boolean[m]; int[] ci = new int[m];
        IntList[] o = new IntList[m]; IntList[] i2 = new IntList[m];
        for (int i = 0; i < n; i++) { nn[i] = names[i]; ic[i] = isCourse[i]; ci[i] = courseIds[i]; o[i] = out[i]; i2[i] = in[i]; }
        names = nn; isCourse = ic; courseIds = ci; out = o; in = i2;
    }

    /** Linear lookup by name, case-insensitive; -1 if absent. */
    private int findByName(String name) {
        for (int i = 0; i < n; i++) if (names[i].equalsIgnoreCase(name)) return i;
        return -1;
    }

    private int findByCourseId(int id) {
        for (int i = 0; i < n; i++) if (isCourse[i] && courseIds[i] == id) return i;
        return -1;
    }

    private void build(List<CourseDatabase.Course> courses) {
        // 1. every course is a vertex (nodeCourse[i] = the Course stored at vertex i)
        List<CourseDatabase.Course> nodeCourse = new ArrayList<>();
        for (CourseDatabase.Course c : courses) {
            if (c == null || c.getName() == null) continue;
            if (findByName(c.getName().trim()) >= 0) {
                warnings.add("Duplicate course name '" + c.getName() + "' (id " + c.getId()
                        + "): prerequisite references resolve to the first course with that name");
            }
            addNode(c.getName().trim(), true, c.getId());
            nodeCourse.add(c);
        }
        int courseNodes = n;
        // 2. one edge per prerequisite; unknown names become foundation vertices
        for (int ci = 0; ci < courseNodes; ci++) {
            CourseDatabase.Course c = nodeCourse.get(ci);
            if (c == null || c.getPrerequisites() == null) continue;
            for (String raw : c.getPrerequisites()) {
                if (raw == null || raw.trim().isEmpty()) continue;
                String p = raw.trim();
                int pi = findByName(p);
                if (pi < 0) pi = addNode(p, false, 0);   // foundation topic
                if (pi == ci) {
                    warnings.add("Course '" + names[ci] + "' lists itself as a prerequisite; ignored");
                    continue;
                }
                if (out[pi].contains(ci)) {
                    warnings.add("Duplicate prerequisite '" + p + "' for '" + names[ci] + "'; ignored");
                    continue;
                }
                out[pi].add(ci);
                in[ci].add(pi);
                edgeCount++;
            }
        }
    }

    // ---------------- basic accessors ----------------
    public int vertexCount() { return n; }
    public int edgeCount() { return edgeCount; }
    public List<String> getWarnings() { return warnings; }
    public String nameOf(int v) { return names[v]; }
    public boolean isCourse(int v) { return isCourse[v]; }
    public int courseIdOf(int v) { return courseIds[v]; }
    public int outDegree(int v) { return out[v].size; }
    public int inDegree(int v) { return in[v].size; }

    /** Vertex index for a course id, or -1. */
    public int nodeForCourse(int courseId) { return findByCourseId(courseId); }

    public List<String> prerequisitesOf(int v) {
        List<String> r = new ArrayList<>();
        for (int i = 0; i < in[v].size; i++) r.add(names[in[v].a[i]]);
        return r;
    }

    public List<String> unlocksDirect(int v) {
        List<String> r = new ArrayList<>();
        for (int i = 0; i < out[v].size; i++) r.add(names[out[v].a[i]]);
        return r;
    }

    // ---------------- Kahn + levels + cycle detection ----------------
    /** O(V+E). */
    public TopoResult topologicalSort() {
        TopoResult r = new TopoResult();
        int[] indeg = new int[n];
        r.level = new int[n];
        for (int v = 0; v < n; v++) { indeg[v] = in[v].size; r.level[v] = -1; }

        int[] queue = new int[n];
        int head = 0, tail = 0;
        for (int v = 0; v < n; v++) if (indeg[v] == 0) { queue[tail++] = v; r.level[v] = 0; }

        while (head < tail) {
            int u = queue[head++];
            for (int i = 0; i < out[u].size; i++) {
                int v = out[u].a[i];
                if (r.level[u] + 1 > r.level[v]) r.level[v] = r.level[u] + 1;   // longest-path DP
                if (--indeg[v] == 0) queue[tail++] = v;
            }
        }
        r.order = new int[tail];
        for (int i = 0; i < tail; i++) r.order[i] = queue[i];
        r.hasCycle = tail < n;

        if (r.hasCycle) {
            boolean[] done = new boolean[n];
            for (int i = 0; i < tail; i++) done[queue[i]] = true;
            for (int v = 0; v < n; v++) {
                if (done[v]) continue;
                r.blocked.add(names[v]);
                // A vertex on/behind a cycle may still have been given a level by a processed
                // predecessor above; it can never be scheduled, so its level is -1 (as documented).
                r.level[v] = -1;
            }
            // reverse peeling: repeatedly remove unprocessed vertices with no unprocessed successors
            int[] outLeft = new int[n];
            boolean[] removed = new boolean[n];
            int[] q2 = new int[n]; int h2 = 0, t2 = 0;
            for (int v = 0; v < n; v++) {
                if (done[v]) { removed[v] = true; continue; }
                for (int i = 0; i < out[v].size; i++) if (!done[out[v].a[i]]) outLeft[v]++;
                if (outLeft[v] == 0) { q2[t2++] = v; removed[v] = true; }
            }
            while (h2 < t2) {
                int v = q2[h2++];
                for (int i = 0; i < in[v].size; i++) {
                    int u = in[v].a[i];
                    if (removed[u]) continue;
                    if (--outLeft[u] == 0) { removed[u] = true; q2[t2++] = u; }
                }
            }
            for (int v = 0; v < n; v++) if (!removed[v]) r.cyclicCore.add(names[v]);
        }
        return r;
    }

    // ---------------- weakly connected components ----------------
    /** Returns component id per vertex (BFS ignoring edge direction). O(V+E). */
    public int[] weakComponents() {
        int[] comp = new int[n];
        for (int i = 0; i < n; i++) comp[i] = -1;
        int[] queue = new int[Math.max(n, 1)];
        int c = 0;
        for (int s = 0; s < n; s++) {
            if (comp[s] != -1) continue;
            int head = 0, tail = 0;
            queue[tail++] = s; comp[s] = c;
            while (head < tail) {
                int u = queue[head++];
                for (int i = 0; i < out[u].size; i++) { int v = out[u].a[i]; if (comp[v] == -1) { comp[v] = c; queue[tail++] = v; } }
                for (int i = 0; i < in[u].size; i++) { int v = in[u].a[i]; if (comp[v] == -1) { comp[v] = c; queue[tail++] = v; } }
            }
            c++;
        }
        return comp;
    }

    public int componentCount(int[] comp) {
        int max = -1;
        for (int x : comp) if (x > max) max = x;
        return max + 1;
    }

    // ---------------- forward BFS: what does a course unlock ----------------
    public List<Reach> unlocks(int courseId) {
        List<Reach> res = new ArrayList<>();
        int s = findByCourseId(courseId);
        if (s < 0) return res;
        int[] dist = new int[n];
        for (int i = 0; i < n; i++) dist[i] = -1;
        int[] queue = new int[n];
        int head = 0, tail = 0;
        queue[tail++] = s; dist[s] = 0;
        while (head < tail) {
            int u = queue[head++];
            for (int i = 0; i < out[u].size; i++) {
                int v = out[u].a[i];
                if (dist[v] == -1) {
                    dist[v] = dist[u] + 1;
                    queue[tail++] = v;
                    res.add(new Reach(courseIds[v], names[v], dist[v]));
                }
            }
        }
        return res;
    }

    // ---------------- known-skill matching ----------------
    /** Marks vertices the student already has (exact, case-insensitive, or Edit-Distance similarity >= 65%). */
    public boolean[] markKnown(List<String> known) {
        boolean[] k = new boolean[n];
        if (known == null) return k;
        for (String s : known) {
            if (s == null || s.trim().isEmpty()) continue;
            String t = s.trim();
            for (int v = 0; v < n; v++) {
                if (k[v]) continue;
                if (names[v].equalsIgnoreCase(t)
                        || SearchEngine.similarityPercent(t.toLowerCase(Locale.ROOT), names[v].toLowerCase(Locale.ROOT)) >= KNOWN_MATCH_THRESHOLD) {
                    k[v] = true;
                }
            }
        }
        return k;
    }

    // ---------------- learning path ----------------
    public PathResult learningPath(int targetCourseId, List<String> known, int perSemester) {
        PathResult r = new PathResult();
        if (perSemester < 1) perSemester = DEFAULT_PER_SEMESTER;
        if (perSemester > 6) perSemester = 6;
        r.perSemester = perSemester;
        r.targetCourseId = targetCourseId;

        int target = findByCourseId(targetCourseId);
        if (target < 0) { r.status = "NOT_FOUND"; return r; }
        r.targetName = names[target];

        boolean[] knownMark = markKnown(known);
        if (knownMark[target]) { r.status = "ALREADY_KNOWN"; r.alreadyKnown.add(names[target]); return r; }

        // reverse BFS from target; do not expand past known vertices
        boolean[] needed = new boolean[n];
        boolean[] seen = new boolean[n];
        boolean[] skipped = new boolean[n];
        int[] queue = new int[n];
        int head = 0, tail = 0;
        queue[tail++] = target; seen[target] = true; needed[target] = true;
        while (head < tail) {
            int v = queue[head++];
            for (int i = 0; i < in[v].size; i++) {
                int u = in[v].a[i];
                if (seen[u]) continue;
                seen[u] = true;
                if (knownMark[u]) { skipped[u] = true; continue; }
                needed[u] = true;
                queue[tail++] = u;
            }
        }
        for (int v = 0; v < n; v++) if (skipped[v]) r.alreadyKnown.add(names[v]);

        // a needed vertex that sits on/behind a cycle makes the path impossible
        TopoResult topo = topologicalSort();
        for (int v = 0; v < n; v++) if (needed[v] && topo.level[v] == -1) r.blocked.add(names[v]);
        if (!r.blocked.isEmpty()) { r.status = "BLOCKED_BY_CYCLE"; return r; }

        int[] semOf = new int[n];
        r.semesters = schedule(needed, knownMark, perSemester, semOf);
        r.minSemesters = schedule(needed, knownMark, n + 1, new int[n]);

        // output: foundations (semester 0) then courses by semester, ties by vertex index
        for (int sem = 0; sem <= r.semesters; sem++) {
            for (int v = 0; v < n; v++) {
                if (!needed[v] || semOf[v] != sem) continue;
                PathStep st = new PathStep(v, names[v], isCourse[v], courseIds[v], sem);
                for (int i = 0; i < in[v].size; i++) st.requires.add(names[in[v].a[i]]);
                r.steps.add(st);
            }
        }
        r.status = "OK";
        return r;
    }

    /**
     * Layered Kahn on the needed sub-graph. Foundations get semester 0. Each round picks up to
     * 'cap' ready courses (all needed prerequisites finished in earlier rounds). Returns #semesters.
     */
    private int schedule(boolean[] needed, boolean[] known, int cap, int[] semOf) {
        int[] pending = new int[n];
        int remaining = 0;
        for (int v = 0; v < n; v++) {
            if (!needed[v]) continue;
            for (int i = 0; i < in[v].size; i++) if (needed[in[v].a[i]]) pending[v]++;
            if (isCourse[v]) remaining++;
        }
        // foundations first
        for (int v = 0; v < n; v++) {
            if (needed[v] && !isCourse[v]) {
                semOf[v] = 0;
                for (int i = 0; i < out[v].size; i++) { int w = out[v].a[i]; if (needed[w]) pending[w]--; }
            }
        }
        int sem = 0;
        while (remaining > 0) {
            sem++;
            int[] picked = new int[n];
            int pc = 0;
            for (int v = 0; v < n && pc < cap; v++) {
                if (needed[v] && isCourse[v] && semOf[v] == 0 && pending[v] == 0 && !scheduled(semOf, v)) {
                    picked[pc++] = v;
                }
            }
            if (pc == 0) break;   // defensive: cannot happen on a DAG
            for (int i = 0; i < pc; i++) {
                int v = picked[i];
                semOf[v] = sem;
                remaining--;
            }
            for (int i = 0; i < pc; i++) {
                int v = picked[i];
                for (int j = 0; j < out[v].size; j++) { int w = out[v].a[j]; if (needed[w]) pending[w]--; }
            }
        }
        return sem;
    }

    // a course counts as scheduled once its semester is >= 1 (0 means "not yet")
    private boolean scheduled(int[] semOf, int v) { return semOf[v] >= 1; }

    /** Short text report (used by tests / console debugging). */
    public String describe() {
        return n + " vertices, " + edgeCount + " edges";
    }
}
