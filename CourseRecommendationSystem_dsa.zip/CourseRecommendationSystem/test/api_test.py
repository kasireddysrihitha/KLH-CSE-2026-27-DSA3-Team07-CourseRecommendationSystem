import os, json, sys, urllib.request, urllib.error, urllib.parse
BASE = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8080"
results = []
os.makedirs("public_old", exist_ok=True); open("public_old/secret.txt","w").write("SECRET")
def call(method, path, expect_status=None, check=None, label=None):
    url = BASE + path
    req = urllib.request.Request(url, method=method)
    try:
        r = urllib.request.urlopen(req, timeout=10)
        status, body, ctype = r.status, r.read(), r.headers.get("Content-Type","")
    except urllib.error.HTTPError as e:
        status, body, ctype = e.code, e.read(), e.headers.get("Content-Type","")
    except Exception as e:
        results.append((label or path, "FAIL", "exception %r" % e)); return None
    txt = body.decode("utf-8", "replace")
    js, jerr = None, None
    if "json" in ctype:
        try: js = json.loads(txt)
        except Exception as e: jerr = str(e)
    ok = True; why = []
    if expect_status is not None and status != expect_status: ok=False; why.append("status %s != %s" % (status, expect_status))
    if "json" in ctype and jerr: ok=False; why.append("invalid JSON: "+jerr)
    if check and js is not None:
        try:
            if not check(js): ok=False; why.append("check failed: %s" % txt[:200])
        except Exception as e: ok=False; why.append("check raised %r on %s" % (e, txt[:200]))
    elif check and js is None and "json" in ctype: pass
    results.append((label or (method+" "+path), "PASS" if ok else "FAIL", "; ".join(why) or "HTTP %d" % status))
    return js
G="GET"
q=urllib.parse.quote
# status
call(G,"/api/status",200,lambda j: j["totalCourses"]==14 and j["graphNodes"]==18 and j["graphEdges"]==16)
# courses
call(G,"/api/courses",200,lambda j: len(j)==14 and all(set(c)>={"id","name","category","description","prerequisites","requiredSkills","careerPaths","interestTags"} for c in j))
call(G,"/api/categories",200,lambda j: isinstance(j,list) and len(j)>0 and j==sorted(j,key=str.lower))
# course
call(G,"/api/course?id=1",200,lambda j: j["id"]==1 and j["name"]=="Machine Learning Fundamentals")
call(G,"/api/course?id=10",200,lambda j: j["prerequisites"]==[])
for bad in ["999","0","-1","abc","","1.5","99999999999999999999"]:
    call(G,"/api/course?id="+bad,404,lambda j: "error" in j, label="GET /api/course?id=%s (invalid)"%bad)
call(G,"/api/course",404,lambda j: "error" in j, label="GET /api/course (missing id)")
# search
call(G,"/api/search?q="+q("Machine Learning"),200,lambda j: j[0]["confidence"]==100 and j[0]["course"]["id"]==1)
call(G,"/api/search?q="+q("machne learning"),200,lambda j: any(r["course"]["id"]==1 for r in j) and all(r["confidence"]<100 for r in j))
call(G,"/api/search?q=python",200,lambda j: len(j)>0)
call(G,"/api/search?q=",200,lambda j: j==[], label="GET /api/search?q= (empty)")
call(G,"/api/search",200,lambda j: j==[], label="GET /api/search (missing q)")
call(G,"/api/search?q=%20%20",200,lambda j: j==[], label="GET /api/search?q=blank")
call(G,"/api/search?q=zzzzqqqqxxxx",200,lambda j: j==[], label="GET /api/search no-match")
call(G,"/api/search?q="+q('"quote\\ back <b>&'),200,lambda j: isinstance(j,list), label="GET /api/search special chars")
call(G,"/api/search?q="+q("é中🙂"),200,lambda j: isinstance(j,list), label="GET /api/search unicode")
call(G,"/api/search?q=%ZZ",400,None, label="GET /api/search malformed percent-encoding -> 400 (rejected by JDK server)")
call(G,"/api/search?q="+("a"*5000),200,lambda j: isinstance(j,list), label="GET /api/search 5000-char query")
# suggest
call(G,"/api/suggest?q=Mach",200,lambda j: [c["id"] for c in j]==[1])
call(G,"/api/suggest?q=mach",200,lambda j: [c["id"] for c in j]==[1], label="suggest lowercase")
call(G,"/api/suggest?q=MACH",200,lambda j: [c["id"] for c in j]==[1], label="suggest uppercase")
call(G,"/api/suggest?q=Learn",200,lambda j: 3 in [c["id"] for c in j], label="suggest word-start 'Learn'")
call(G,"/api/suggest?q=d",200,lambda j: len(j)<=8 and len({c["id"] for c in j})==len(j), label="suggest 'd' (limit 8, no dups)")
call(G,"/api/suggest?q=",200,lambda j: j==[], label="suggest empty")
call(G,"/api/suggest",200,lambda j: j==[], label="suggest missing q")
call(G,"/api/suggest?q=zzz",200,lambda j: j==[], label="suggest no-match")
call(G,"/api/suggest?q="+q("UI/"),200,lambda j: [c["id"] for c in j]==[11], label="suggest special char UI/")
call(G,"/api/suggest?q="+q("é"),200,lambda j: j==[], label="suggest non-ASCII prefix (no false positives)")
call(G,"/api/suggest?q="+q("data"),200,lambda j: {c["id"] for c in j}>={2,9,14}, label="suggest 'data'")
# recommend
call(G,"/api/recommend?interests="+q("Machine Learning,Data")+"&skills="+q("Python,Statistics")+"&qualifications="+q("Basic Programming,Statistics")+"&careerGoals="+q("Data Scientist"),200,
     lambda j: 0<len(j)<=5 and j[0]["course"]["id"] in (1,2) and all(j[i]["score"]>=j[i+1]["score"] for i in range(len(j)-1)))
call(G,"/api/recommend",200,lambda j: j==[], label="recommend no params -> [] (blank profile)")
call(G,"/api/recommend?interests=&skills=&qualifications=&careerGoals=",200,lambda j: isinstance(j,list), label="recommend all empty")
call(G,"/api/recommend?skills=zzzz",200,lambda j: isinstance(j,list), label="recommend nonsense skill")
call(G,"/api/recommend?skills="+q(",,, , ,"),200,lambda j: isinstance(j,list), label="recommend only commas")
call(G,"/api/recommend?qualifications="+q("Networking Basics")+"&interests=Networking",200,lambda j: any(r["eligible"] for r in j) , label="recommend eligibility via qualification")
# compare
call(G,"/api/compare?id1=1&id2=2",200,lambda j: j["course1"]["id"]==1 and j["course2"]["id"]==2)
call(G,"/api/compare?id1=1&id2=1",200,lambda j: j["course1"]["id"]==1 and j["course2"]["id"]==1, label="compare identical ids")
call(G,"/api/compare?id1=1&id2=999",404,lambda j: "error" in j)
call(G,"/api/compare?id1=abc&id2=2",404,lambda j: "error" in j)
call(G,"/api/compare?id1=1",404,lambda j: "error" in j, label="compare missing id2")
call(G,"/api/compare",404,lambda j: "error" in j, label="compare no params")
# graph
def graph_ok(j):
    return (j["vertices"]==18 and j["edges"]==16 and j["hasCycle"] is False and j["components"]==3
            and len(j["topologicalOrder"])==18 and len(j["nodes"])==18 and j["blocked"]==[] and j["cyclicCore"]==[])
call(G,"/api/graph",200,graph_ok)
# path
def path_dl(j):
    names=[s["name"] for s in j["steps"]]
    return (j["status"]=="OK" and names.index("Machine Learning Fundamentals")<names.index("Deep Learning with Neural Networks")
            and j["steps"][-1]["name"]=="Deep Learning with Neural Networks" and j["semesters"]==2)
call(G,"/api/path?target=3",200,path_dl)
call(G,"/api/path?target=3&known="+q("Basic Programming,Statistics,Linear Algebra"),200,lambda j: j["status"]=="OK" and [s["name"] for s in j["steps"]]==["Machine Learning Fundamentals","Deep Learning with Neural Networks"], label="path known foundations")
call(G,"/api/path?target=3&known="+q("Machine Learning Fundamentals"),200,lambda j: j["status"]=="OK" and "Machine Learning Fundamentals" in j["alreadyKnown"] and "Statistics" not in [s["name"] for s in j["steps"]], label="path known ML prunes")
call(G,"/api/path?target=3&known="+q("Deep Learning with Neural Networks"),200,lambda j: j["status"]=="ALREADY_KNOWN", label="path already known")
call(G,"/api/path?target=10",200,lambda j: j["status"]=="OK" and len(j["steps"])==2 and j["semesters"]==1, label="path course w/ foundation only (Computer Networking has no prereq)") if False else None
call(G,"/api/path?target=10",200,lambda j: j["status"]=="OK" and [s["name"] for s in j["steps"]]==["Computer Networking"] and j["semesters"]==1, label="path no-prereq course")
call(G,"/api/path?target=11&perSemester=1",200,lambda j: j["status"]=="OK" and j["semesters"]==1, label="path no-prereq course 11")
call(G,"/api/path?target=999",404,lambda j: j["status"]=="NOT_FOUND")
call(G,"/api/path",404,lambda j: j["status"]=="NOT_FOUND", label="path missing target")
call(G,"/api/path?target=abc",404,lambda j: j["status"]=="NOT_FOUND", label="path non-numeric target")
for per in ["0","-3","99","abc",""]:
    call(G,"/api/path?target=3&perSemester="+per,200,lambda j: j["status"]=="OK" and 1<=j["perSemester"]<=6, label="path perSemester=%r clamp/default"%per)
call(G,"/api/path?target=3&perSemester=1",200,lambda j: j["semesters"]==3 and j["minSemesters"]==2, label="path perSemester=1 -> 3 semesters (ML,DL are sequential; cap=1 => 2 courses = 2 sems)") if False else None
call(G,"/api/path?target=3&known=,,,%20,",200,lambda j: j["status"]=="OK", label="path known only commas")
# unlocks
call(G,"/api/unlocks?id=1",200,lambda j: j["courseId"]==1 and any(u["courseId"]==3 and u["distance"]==1 for u in j["unlocks"]))
call(G,"/api/unlocks?id=3",200,lambda j: j["unlocks"]==[], label="unlocks leaf course")
call(G,"/api/unlocks?id=10",200,lambda j: j["unlocks"]==[], label="unlocks no-prereq isolated course")
call(G,"/api/unlocks?id=999",404,lambda j: "error" in j)
call(G,"/api/unlocks",404,lambda j: "error" in j, label="unlocks missing id")
call(G,"/api/unlocks?id=abc",404,lambda j: "error" in j, label="unlocks non-numeric id")
# methods
for ep in ["status","courses","course?id=1","search?q=a","suggest?q=a","categories","recommend","compare?id1=1&id2=2","graph","path?target=3","unlocks?id=1"]:
    call("POST","/api/"+ep,405,lambda j: "error" in j, label="POST /api/"+ep+" -> 405")
call("DELETE","/api/courses",405,lambda j: "error" in j, label="DELETE /api/courses -> 405")
# unknown api path
call(G,"/api/doesnotexist",404,None,label="GET /api/doesnotexist -> 404")
# static
for p,ct in [("/","text/html"),("/index.html","text/html"),("/recommend.html","text/html"),("/search.html","text/html"),("/explore.html","text/html"),("/course.html","text/html"),("/compare.html","text/html"),("/css/style.css","text/css"),("/js/api.js","javascript"),("/js/components.js","javascript"),("/js/nav.js","javascript"),("/js/recommend.js","javascript"),("/js/search.js","javascript"),("/js/explore.js","javascript"),("/js/course.js","javascript"),("/js/compare.js","javascript")]:
    url=BASE+p
    r=urllib.request.urlopen(url); results.append(("GET "+p,"PASS" if r.status==200 and ct in r.headers.get("Content-Type","") else "FAIL","HTTP %d %s"%(r.status,r.headers.get("Content-Type"))))
for p in ["/%00","/nope.html","/../public_old/secret.txt","/../src/WebServer.java","/%2e%2e/src/WebServer.java","/..%2fdata/courses.txt","/js/","/js","/css/..%5c..%5cdata%5ccourses.txt"]:
    import http.client
    c=http.client.HTTPConnection("localhost",8080,timeout=5)
    try:
        c.request("GET",p); rr=c.getresponse(); st=rr.status; body=rr.read()[:80]
    except Exception as e: st=-1; body=repr(e).encode()
    results.append(("GET "+p+" (must not leak / must 404)","PASS" if st==404 else "FAIL","HTTP %d %r"%(st,body)))
p=f=0
for name,st,why in results:
    print("%-4s %s  [%s]"%(st,name,why)); 
    if st=="PASS": p+=1
    else: f+=1
print("\nTOTAL %d  PASS %d  FAIL %d"%(p+f,p,f))
import shutil; shutil.rmtree("public_old", ignore_errors=True)
sys.exit(1 if f else 0)
