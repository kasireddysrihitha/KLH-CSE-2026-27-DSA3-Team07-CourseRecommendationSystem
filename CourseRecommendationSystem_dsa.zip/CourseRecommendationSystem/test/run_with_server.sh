#!/bin/sh
# usage: run_with_server.sh <java -D opts...> -- <command to run while server is up>
cd "$(cd "$(dirname "$0")/.." && pwd)"
OPTS=""
while [ "$1" != "--" ] && [ $# -gt 0 ]; do OPTS="$OPTS $1"; shift; done
shift
setsid java $OPTS -cp bin WebServer > /tmp/server_run.log 2>&1 &
SP=$!
i=0; while [ $i -lt 40 ]; do curl -s -o /dev/null localhost:8080/api/status && break; sleep 0.25; i=$((i+1)); done
"$@"; RC=$?
if kill -0 $SP 2>/dev/null; then echo "[server still alive after tests: yes]"; else echo "[server still alive after tests: NO - crashed]"; fi
kill $SP 2>/dev/null; sleep 0.3
echo "---- server log ----"; cat /tmp/server_run.log
exit $RC
