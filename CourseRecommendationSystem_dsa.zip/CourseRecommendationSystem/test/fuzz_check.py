import random, urllib.request, urllib.error, urllib.parse, json, sys
random.seed(7); B="http://localhost:8080"; bad=0; n=0
chars=list('abcXYZ019 ,;|&=?#%"\'\\/<>{}[]-_.+*')+['é','中','తె','🙂','\n','\t']
def rs(): return "".join(random.choice(chars) for _ in range(random.randint(0,25)))
eps=lambda: random.choice(["/api/search?q=%s","/api/suggest?q=%s","/api/course?id=%s","/api/unlocks?id=%s","/api/path?target=%s&known=%s&perSemester=%s","/api/compare?id1=%s&id2=%s","/api/recommend?interests=%s&skills=%s&qualifications=%s&careerGoals=%s"])
for i in range(1500):
    t=eps(); k=t.count("%s"); p=t%tuple(urllib.parse.quote(rs() if random.random()<.7 else str(random.randint(-3,20)),safe="") for _ in range(k))
    n+=1
    try:
        r=urllib.request.urlopen(B+p,timeout=8); st=r.status; body=r.read().decode()
    except urllib.error.HTTPError as e: st=e.code; body=e.read().decode()
    except Exception as e: print("FAIL conn",p,e); bad+=1; continue
    if st>=500: print("FAIL 5xx",st,p); bad+=1; continue
    try: json.loads(body)
    except Exception: print("FAIL non-JSON",st,p,body[:60]); bad+=1
print("FUZZ requests",n,"problems",bad); sys.exit(1 if bad else 0)
