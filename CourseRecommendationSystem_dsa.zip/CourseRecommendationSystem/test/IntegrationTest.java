import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Phase 4 cross-phase regression test (file handling + Trie + string algorithms + Merge Sort + graph).
 *
 * Each algorithm is checked against an independent reference ("oracle") on thousands of random
 * inputs, plus the real shipped dataset, plus hostile/empty/null inputs.
 *
 * Run (from project root):
 *   javac -d bin src/*.java && javac -cp bin -d bin test/IntegrationTest.java && java -cp bin IntegrationTest
 */
public class IntegrationTest {
    static int fail = 0, total = 0;

    static void check(String name, boolean ok) {
        total++;
        System.out.println((ok ? "PASS " : "FAIL ") + name);
        if (!ok) fail++;
    }

    static CourseDatabase.Course course(int id, String name, String... prereqs) {
        return new CourseDatabase.Course(id, name, "Cat", "Desc " + name,
                new ArrayList<>(Arrays.asList(prereqs)), new ArrayList<>(Arrays.asList("Skill")),
                new ArrayList<>(Arrays.asList("Career")), new ArrayList<>(Arrays.asList("Tag")));
    }

    static List<Integer> ids(List<CourseDatabase.Course> l) {
        List<Integer> r = new ArrayList<>();
        for (CourseDatabase.Course c : l) r.add(c.getId());
        return r;
    }

    static String writeTemp(Path dir, String name, String content) throws Exception {
        Path p = dir.resolve(name);
        Files.write(p, content.getBytes(StandardCharsets.UTF_8));
        return p.toString();
    }

    public static void main(String[] args) throws Exception {
        Path dir = Files.createTempDirectory("itest");
        Random rnd = new Random(20260708L);

        dataFlow(dir);
        trieChecks(dir);
        stringAlgorithmOracles(rnd);
        mergeSortOracle(rnd);
        graphOracles(rnd);
        graphFromFiles(dir);
        emptyAndNullHandling(dir);
        localeIndependence();
        wiringChecks();

        System.out.println(fail == 0 ? "ALL PASSED (" + total + " checks)" : fail + " FAILED of " + total);
        System.exit(fail);
    }

    // ------------------------------------------------------------------
    // Phase 1 -> 2 -> 3 data flow: everything derives from the loaded file
    // ------------------------------------------------------------------
    static void dataFlow(Path dir) throws Exception {
        CourseDatabase db = new CourseDatabase();
        FileHandler.LoadResult fromFile = FileHandler.loadCourses("data/courses.txt");
        check("DB course ids == FileHandler course ids", ids(db.getAllCourses()).equals(ids(fromFile.courses)));

        // Graph vertices must be exactly: courses + distinct (case-insensitive) non-course prerequisite names
        CourseGraph g = new CourseGraph(db);
        List<String> expectedFoundations = new ArrayList<>();
        int expectedEdges = 0;
        for (CourseDatabase.Course c : db.getAllCourses()) {
            for (String p : c.getPrerequisites()) {
                expectedEdges++;
                boolean isCourse = false;
                for (CourseDatabase.Course o : db.getAllCourses()) if (o.getName().equalsIgnoreCase(p)) isCourse = true;
                boolean seen = false;
                for (String f : expectedFoundations) if (f.equalsIgnoreCase(p)) seen = true;
                if (!isCourse && !seen) expectedFoundations.add(p);
            }
        }
        check("graph vertices == #courses + #distinct foundation prerequisites (" + g.vertexCount() + ")",
                g.vertexCount() == db.getAllCourses().size() + expectedFoundations.size());
        check("graph edges == total prerequisite entries in the file (" + g.edgeCount() + ")", g.edgeCount() == expectedEdges);
        boolean allNamesFromData = true;
        for (int v = 0; v < g.vertexCount(); v++) {
            String nm = g.nameOf(v);
            boolean found = false;
            for (CourseDatabase.Course c : db.getAllCourses()) {
                if (c.getName().equals(nm)) found = true;
                for (String p : c.getPrerequisites()) if (p.equals(nm)) found = true;
            }
            if (!found) allNamesFromData = false;
        }
        check("every graph vertex name occurs in data/courses.txt (no unrelated sample data)", allNamesFromData);

        // Swap the data file: Trie AND graph must follow (proves neither keeps a private dataset)
        String custom = writeTemp(dir, "swap.txt",
                "101|Zebra Studies|Biology|About zebras|Stripes 101|Observation|Zoologist|Animals\n" +
                "102|Advanced Zebra Studies|Biology|More zebras|Zebra Studies|Observation|Zoologist|Animals\n");
        CourseDatabase cdb = new CourseDatabase(custom);
        SearchEngine cse = new SearchEngine(cdb);
        CourseGraph cg = new CourseGraph(cdb);
        check("trie follows the loaded file: 'zeb' -> the 2 custom courses", ids(cse.suggestCourses("zeb", 8)).equals(Arrays.asList(101)) || ids(cse.suggestCourses("zeb", 8)).containsAll(Arrays.asList(101)));
        check("trie follows the loaded file: shipped course names are gone", cse.suggestCourses("Mach", 8).isEmpty());
        check("word-start 'studies' finds both custom courses", ids(cse.suggestCourses("studies", 8)).containsAll(Arrays.asList(101, 102)));
        check("graph follows the loaded file: 3 vertices (2 courses + 1 foundation), 2 edges", cg.vertexCount() == 3 && cg.edgeCount() == 2);
        check("graph follows the loaded file: path to 102 = Stripes 101, Zebra Studies, Advanced Zebra Studies",
                namesOf(cg.learningPath(102, null, 2)).equals(Arrays.asList("Stripes 101", "Zebra Studies", "Advanced Zebra Studies")));
        check("graph follows the loaded file: shipped course 1 no longer exists", cg.learningPath(1, null, 2).status.equals("NOT_FOUND"));
        RecommendationEngine re = new RecommendationEngine(cdb);
        List<RecommendationEngine.ScoredCourse> rec = re.recommend(new RecommendationEngine.StudentProfile(
                Arrays.asList("Animals"), Arrays.asList("Observation"), Arrays.asList("Stripes 101"), Arrays.asList("Zoologist")));
        check("recommendations come from the loaded file (top is a zebra course)", !rec.isEmpty() && rec.get(0).course.getName().contains("Zebra"));
    }

    static List<String> namesOf(CourseGraph.PathResult r) {
        List<String> n = new ArrayList<>();
        for (CourseGraph.PathStep s : r.steps) n.add(s.name);
        return n;
    }

    // ------------------------------------------------------------------
    // Phase 2: Trie
    // ------------------------------------------------------------------
    static void trieChecks(Path dir) throws Exception {
        CourseDatabase db = new CourseDatabase();
        SearchEngine se = new SearchEngine(db);
        boolean everyNameFindsItself = true;
        for (CourseDatabase.Course c : db.getAllCourses()) {
            if (!ids(se.suggestCourses(c.getName(), 50)).contains(c.getId())) everyNameFindsItself = false;
            if (!ids(se.suggestCourses(c.getName().toUpperCase(), 50)).contains(c.getId())) everyNameFindsItself = false;
            if (!ids(se.suggestCourses(c.getName().toLowerCase(), 50)).contains(c.getId())) everyNameFindsItself = false;
        }
        check("every course is found by its full name (exact / UPPER / lower case)", everyNameFindsItself);

        // oracle: for every prefix of every name, trie result == brute-force startsWith (name-prefix part first)
        boolean prefixOracle = true;
        for (CourseDatabase.Course c : db.getAllCourses()) {
            String n = c.getName().toLowerCase();
            for (int len = 1; len <= n.length(); len++) {
                String p = n.substring(0, len);
                if (p.trim().isEmpty()) continue;
                List<Integer> got = ids(se.suggestCourses(p, 1000));
                List<Integer> expectNamePrefix = new ArrayList<>();
                for (CourseDatabase.Course o : db.getAllCourses()) if (o.getName().toLowerCase().startsWith(p.trim())) expectNamePrefix.add(o.getId());
                // all name-prefix matches must be present, first, and nothing outside (name-prefix U word-start) may appear
                if (got.size() < expectNamePrefix.size() || !new ArrayList<>(got.subList(0, expectNamePrefix.size())).containsAll(expectNamePrefix)) prefixOracle = false;
                for (int id : got) {
                    CourseDatabase.Course o = db.getCourseById(id);
                    String ln = o.getName().toLowerCase();
                    boolean ok = ln.startsWith(p.trim());
                    for (int i = 1; i < ln.length(); i++) if (ln.charAt(i - 1) == ' ' && ln.charAt(i) != ' ' && ln.startsWith(p.trim(), i)) ok = true;
                    if (!ok) prefixOracle = false;
                }
                if (new java.util.HashSet<>(got).size() != got.size()) prefixOracle = false;
            }
        }
        check("every prefix of every course name: trie == brute-force prefix scan (no extras, no dups)", prefixOracle);

        // non-ASCII must be exact: different non-ASCII first characters must not collide
        String uni = writeTemp(dir, "uni.txt",
                "1|\u00c9cole de Design|Cat|Desc|P|S|C|T\n" +
                "2|\u00d1and\u00fa Basics|Cat|Desc|P|S|C|T\n" +
                "3|\u4e2d\u6587 Course|Cat|Desc|P|S|C|T\n" +
                "4|\u0c24\u0c46\u0c32\u0c41\u0c17\u0c41 Literature|Cat|Desc|P|S|C|T\n" +
                "5|Plain Course|Cat|Desc|P|S|C|T\n");
        SearchEngine use = new SearchEngine(new CourseDatabase(uni));
        check("non-ASCII prefix '\u00e9' -> only the \u00c9cole course", ids(use.suggestCourses("\u00e9", 8)).equals(Arrays.asList(1)));
        check("non-ASCII prefix '\u00f1' -> only the \u00d1and\u00fa course", ids(use.suggestCourses("\u00f1", 8)).equals(Arrays.asList(2)));
        check("non-ASCII prefix '\u4e2d' -> only the Chinese course", ids(use.suggestCourses("\u4e2d", 8)).equals(Arrays.asList(3)));
        check("non-ASCII prefix '\u0c24\u0c46' -> only the Telugu course", ids(use.suggestCourses("\u0c24\u0c46", 8)).equals(Arrays.asList(4)));
        check("non-ASCII prefix '\u00e9cole' -> only the \u00c9cole course", ids(use.suggestCourses("\u00e9cole", 8)).equals(Arrays.asList(1)));
        check("ASCII query does not return non-ASCII courses", ids(use.suggestCourses("plain", 8)).equals(Arrays.asList(5)));

        // very long course name must not blow the stack (recursion depth) or the heap
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 60000; i++) sb.append('a');
        String longFile = writeTemp(dir, "longname.txt", "1|" + sb + "|Cat|Desc|P|S|C|T\n2|Normal Course|Cat|Desc|P|S|C|T\n");
        boolean survived = true;
        List<Integer> longRes = null;
        try {
            SearchEngine lse = new SearchEngine(new CourseDatabase(longFile));
            longRes = ids(lse.suggestCourses("aaa", 5));
        } catch (Throwable t) {
            survived = false;
            System.out.println("   !! long name: " + t.getClass().getName());
        }
        check("60,000-character course name: no StackOverflow, still found by prefix", survived && longRes != null && longRes.equals(Arrays.asList(1)));

        // many words in one name must not make construction explode (word-start indexing)
        StringBuilder words = new StringBuilder();
        for (int i = 0; i < 3000; i++) words.append("w").append(i % 10).append(' ');
        String manyWords = writeTemp(dir, "manywords.txt", "1|" + words.toString().trim() + "|Cat|Desc|P|S|C|T\n");
        long t0 = System.currentTimeMillis();
        boolean mwOk = true;
        try {
            SearchEngine mse = new SearchEngine(new CourseDatabase(manyWords));
            mse.suggestCourses("w5", 5);
        } catch (Throwable t) {
            mwOk = false;
            System.out.println("   !! many words: " + t.getClass().getName());
        }
        long mwMs = System.currentTimeMillis() - t0;
        check("3000-word course name builds quickly (" + mwMs + " ms, < 5 s) without OOM", mwOk && mwMs < 5000);

        CourseTrie t = new CourseTrie();
        CourseDatabase.Course c1 = course(1, "A");
        t.insert(null, c1);
        t.insert("x", null);
        t.insert("   ", c1);
        check("insert(null key / null course / blank key) is ignored safely", t.startsWith("x").isEmpty() && t.getKeyCount() == 0);
        check("startsWith(null) / blank is empty, not an exception", t.startsWith(null).isEmpty() && t.startsWith("  ").isEmpty());
    }

    // ------------------------------------------------------------------
    // KMP / Rabin-Karp / Edit Distance against references
    // ------------------------------------------------------------------
    static String randStr(Random r, int maxLen, String alphabet) {
        int len = r.nextInt(maxLen + 1);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) sb.append(alphabet.charAt(r.nextInt(alphabet.length())));
        return sb.toString();
    }

    static int refEditDistance(String a, String b) {
        a = a.toLowerCase();
        b = b.toLowerCase();
        int[] prev = new int[b.length() + 1], cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int sub = prev[j - 1] + (a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1);
                cur[j] = Math.min(sub, Math.min(prev[j] + 1, cur[j - 1] + 1));
            }
            int[] tmp = prev; prev = cur; cur = tmp;
        }
        return prev[b.length()];
    }

    static void stringAlgorithmOracles(Random rnd) {
        String[] alphabets = {"ab", "abc", "abcdefghij", "ab \u00e9\u4e2d", "aA"};
        int kmpBad = 0, rkBad = 0, edBad = 0, n = 0;
        for (int iter = 0; iter < 30000; iter++) {
            String alpha = alphabets[iter % alphabets.length];
            String text = randStr(rnd, 40, alpha);
            String pat = randStr(rnd, 6, alpha);
            boolean expect = text.contains(pat);
            if (SearchEngine.kmpContains(text, pat) != expect) kmpBad++;
            if (SearchEngine.rabinKarpContains(text, pat) != expect) rkBad++;
            n++;
        }
        check("KMP == String.contains on " + n + " random (text, pattern) pairs, 5 alphabets incl. non-ASCII", kmpBad == 0);
        check("Rabin-Karp == String.contains on " + n + " random (text, pattern) pairs, 5 alphabets incl. non-ASCII", rkBad == 0);

        // planted patterns: always found, including at the very start and very end
        int plantedBad = 0;
        for (int iter = 0; iter < 5000; iter++) {
            String text = randStr(rnd, 60, "abcd");
            if (text.isEmpty()) continue;
            int s = rnd.nextInt(text.length());
            int e = s + 1 + rnd.nextInt(text.length() - s);
            String pat = text.substring(s, e);
            if (!SearchEngine.kmpContains(text, pat) || !SearchEngine.rabinKarpContains(text, pat)) plantedBad++;
        }
        check("KMP and Rabin-Karp find every planted substring (5000 cases)", plantedBad == 0);

        // adversarial / boundary cases
        boolean edge = SearchEngine.kmpContains("", "") && SearchEngine.rabinKarpContains("", "")
                && !SearchEngine.kmpContains("", "a") && !SearchEngine.rabinKarpContains("", "a")
                && SearchEngine.kmpContains("abc", "") && SearchEngine.rabinKarpContains("abc", "")
                && !SearchEngine.kmpContains("ab", "abc") && !SearchEngine.rabinKarpContains("ab", "abc")
                && SearchEngine.kmpContains("aaaaaaaaab", "aaab") && SearchEngine.rabinKarpContains("aaaaaaaaab", "aaab")
                && SearchEngine.kmpContains("abababac", "ababac") && SearchEngine.rabinKarpContains("abababac", "ababac")
                && SearchEngine.kmpContains("abc", "abc") && SearchEngine.rabinKarpContains("abc", "abc")
                && !SearchEngine.kmpContains("abc", "abd") && !SearchEngine.rabinKarpContains("abc", "abd");
        check("KMP / Rabin-Karp boundary cases (empty text/pattern, pattern longer than text, repeats, exact)", edge);

        // Rabin-Karp must never report a hash collision as a match
        StringBuilder big = new StringBuilder();
        for (int i = 0; i < 200000; i++) big.append((char) ('a' + (i * 7 % 26)));
        long t0 = System.currentTimeMillis();
        boolean bigOk = SearchEngine.rabinKarpContains(big.toString(), big.substring(150000, 150040))
                && !SearchEngine.rabinKarpContains(big.toString(), "zzzzzzzzzz")
                && SearchEngine.kmpContains(big.toString(), big.substring(150000, 150040))
                && !SearchEngine.kmpContains(big.toString(), "zzzzzzzzzz");
        long ms = System.currentTimeMillis() - t0;
        check("KMP / Rabin-Karp on a 200,000-char text run in linear time (" + ms + " ms)", bigOk && ms < 2000);

        // Edit distance
        for (int iter = 0; iter < 20000; iter++) {
            String a = randStr(rnd, 12, "abcAB"), b = randStr(rnd, 12, "abcAB");
            int d = SearchEngine.editDistance(a, b);
            if (d != refEditDistance(a, b)) edBad++;
            if (d != SearchEngine.editDistance(b, a)) edBad++;                                   // symmetry
            if (SearchEngine.editDistance(a, a) != 0) edBad++;                                   // identity
            if (d > Math.max(a.length(), b.length()) || d < Math.abs(a.length() - b.length())) edBad++;   // bounds
            String c = randStr(rnd, 12, "abcAB");
            if (SearchEngine.editDistance(a, c) > d + SearchEngine.editDistance(b, c)) edBad++;   // triangle inequality
            double sim = SearchEngine.similarityPercent(a, b);
            if (sim < 0 || sim > 100) edBad++;
        }
        check("Edit Distance == reference DP, symmetric, identity, bounded, triangle inequality (20000 random triples)", edBad == 0);
        check("Edit Distance known values (kitten/sitting=3, flaw/lawn=2, ''/abc=3, case-insensitive)",
                SearchEngine.editDistance("kitten", "sitting") == 3 && SearchEngine.editDistance("flaw", "lawn") == 2
                        && SearchEngine.editDistance("", "abc") == 3 && SearchEngine.editDistance("ABC", "abc") == 0
                        && SearchEngine.editDistance("", "") == 0);
        check("similarityPercent: identical=100, both empty=100, null=0, disjoint=0",
                SearchEngine.similarityPercent("abc", "abc") == 100.0 && SearchEngine.similarityPercent("", "") == 100.0
                        && SearchEngine.similarityPercent(null, "a") == 0.0 && SearchEngine.similarityPercent("abc", "xyz") == 0.0);

        // Search workflow on the real dataset
        CourseDatabase db = new CourseDatabase();
        SearchEngine se = new SearchEngine(db);
        List<SearchEngine.SearchResult> r = se.search("Machine Learning");
        check("search 'Machine Learning': first hit is course 1 at 100 (KMP on name)", !r.isEmpty() && r.get(0).course.getId() == 1 && r.get(0).confidence == 100.0);
        r = se.search("MACHINE LEARNING");
        check("search is case-insensitive", !r.isEmpty() && r.get(0).course.getId() == 1 && r.get(0).confidence == 100.0);
        r = se.search("Machne Learning");
        check("search typo 'Machne Learning' falls back to Edit Distance, confidence < 100, includes course 1",
                !r.isEmpty() && r.get(0).confidence < 100.0 && ids(toCourses(r)).contains(1));
        r = se.search("Pytho");
        check("search 'Pytho' finds courses via Rabin-Karp on skills/description at 90", !r.isEmpty() && r.get(0).confidence == 90.0);
        check("search of gibberish returns an empty list", se.search("qzxjvkw").isEmpty());
        boolean sorted = true;
        for (String q : new String[]{"data", "a", "e", "software", "net"}) {
            List<SearchEngine.SearchResult> rr = se.search(q);
            for (int i = 1; i < rr.size(); i++) if (rr.get(i - 1).confidence < rr.get(i).confidence) sorted = false;
            if (new java.util.HashSet<>(ids(toCourses(rr))).size() != rr.size()) sorted = false;
        }
        check("search results sorted by confidence (descending), no duplicate courses", sorted);
        // brute-force oracle for the exact/keyword stage
        boolean exactOracle = true;
        for (String q : new String[]{"data", "web", "sql", "java", "design", "net", "ing", "x"}) {
            List<Integer> expect100 = new ArrayList<>(), expect90 = new ArrayList<>();
            for (CourseDatabase.Course c : db.getAllCourses()) {
                boolean strong = c.getName().toLowerCase().contains(q) || c.getCategory().toLowerCase().contains(q);
                boolean kw = c.getDescription().toLowerCase().contains(q);
                for (String s : c.getRequiredSkills()) if (s.toLowerCase().contains(q)) kw = true;
                if (strong) expect100.add(c.getId()); else if (kw) expect90.add(c.getId());
            }
            if (expect100.isEmpty() && expect90.isEmpty()) continue;   // fuzzy fallback case, tested elsewhere
            List<Integer> got100 = new ArrayList<>(), got90 = new ArrayList<>();
            for (SearchEngine.SearchResult sr : se.search(q)) (sr.confidence == 100.0 ? got100 : got90).add(sr.course.getId());
            Collections.sort(got100); Collections.sort(got90); Collections.sort(expect100); Collections.sort(expect90);
            if (!got100.equals(expect100) || !got90.equals(expect90)) exactOracle = false;
        }
        check("search exact/keyword stage == brute-force contains() oracle for 8 queries on real data", exactOracle);
    }

    static List<CourseDatabase.Course> toCourses(List<SearchEngine.SearchResult> r) {
        List<CourseDatabase.Course> o = new ArrayList<>();
        for (SearchEngine.SearchResult s : r) o.add(s.course);
        return o;
    }

    // ------------------------------------------------------------------
    // Merge Sort
    // ------------------------------------------------------------------
    static void mergeSortOracle(Random rnd) {
        int bad = 0, stableBad = 0;
        for (int iter = 0; iter < 3000; iter++) {
            int n = rnd.nextInt(60);
            List<double[]> items = new ArrayList<>();           // [score, originalIndex]
            for (int i = 0; i < n; i++) items.add(new double[]{rnd.nextInt(8) * 12.5, i});   // many ties
            List<double[]> mine = RecommendationEngine.mergeSortDescending(items, x -> x[0]);
            List<double[]> ref = new ArrayList<>(items);
            ref.sort(Comparator.comparingDouble((double[] x) -> x[0]).reversed());           // stable reference
            if (mine.size() != ref.size()) { bad++; continue; }
            for (int i = 0; i < mine.size(); i++) if (mine.get(i) != ref.get(i)) { stableBad++; break; }
        }
        check("Merge Sort descending == stable reference sort on 3000 random lists with many ties", bad == 0 && stableBad == 0);
        List<Integer> src = new ArrayList<>(Arrays.asList(3, 1, 2));
        List<Integer> out = RecommendationEngine.mergeSortDescending(src, x -> x);
        check("Merge Sort does not mutate its input and returns a new list", src.equals(Arrays.asList(3, 1, 2)) && out.equals(Arrays.asList(3, 2, 1)) && out != src);
        check("Merge Sort: empty and single-element lists", RecommendationEngine.mergeSortDescending(new ArrayList<Integer>(), x -> x).isEmpty()
                && RecommendationEngine.mergeSortDescending(Arrays.asList(5), x -> x).equals(Arrays.asList(5)));
        List<Integer> big = new ArrayList<>();
        for (int i = 0; i < 100000; i++) big.add(rnd.nextInt());
        long t0 = System.currentTimeMillis();
        List<Integer> sortedBig = RecommendationEngine.mergeSortDescending(big, x -> x);
        long ms = System.currentTimeMillis() - t0;
        boolean ok = sortedBig.size() == big.size();
        for (int i = 1; i < sortedBig.size() && ok; i++) if (sortedBig.get(i - 1) < sortedBig.get(i)) ok = false;
        check("Merge Sort 100,000 elements sorted correctly (" + ms + " ms)", ok && ms < 3000);

        // the real ranking pipeline
        CourseDatabase db = new CourseDatabase();
        RecommendationEngine re = new RecommendationEngine(db);
        List<RecommendationEngine.ScoredCourse> sc = re.recommend(new RecommendationEngine.StudentProfile(
                Arrays.asList("Machine Learning", "Data"), Arrays.asList("Python", "Statistics"),
                Arrays.asList("Basic Programming", "Statistics"), Arrays.asList("Data Scientist")));
        boolean desc = sc.size() == db.getAllCourses().size();
        for (int i = 1; i < sc.size(); i++) if (sc.get(i - 1).score < sc.get(i).score) desc = false;
        check("recommend() returns every course exactly once, ranked by descending score", desc);
        check("recommend(): documented example ranks ML Fundamentals / Data Science on top",
                sc.get(0).course.getId() == 1 || sc.get(0).course.getId() == 2);
        RecommendationEngine.ScoredCourse ml = null, dl = null;
        for (RecommendationEngine.ScoredCourse x : sc) { if (x.course.getId() == 1) ml = x; if (x.course.getId() == 3) dl = x; }
        check("eligibility: has Basic Programming+Statistics -> ML eligible; lacks ML+Linear Algebra -> DL not eligible with 2 missing",
                ml.eligible && ml.missingPrerequisites.isEmpty() && !dl.eligible && dl.missingPrerequisites.size() == 2);
        RecommendationEngine.ScoredCourse noPre = null;
        for (RecommendationEngine.ScoredCourse x : sc) if (x.course.getId() == 10) noPre = x;
        check("course with no prerequisites is always eligible", noPre != null && noPre.eligible && noPre.missingPrerequisites.isEmpty());
    }

    // ------------------------------------------------------------------
    // Graph algorithms against independent oracles
    // ------------------------------------------------------------------
    static class RandomGraph {
        int n;
        boolean[][] edge;       // edge[u][v]: u is a prerequisite of v
        List<CourseDatabase.Course> courses = new ArrayList<>();
        String[] name;
    }

    static RandomGraph randomGraph(Random r, int n, double p, boolean allowCycles) {
        RandomGraph g = new RandomGraph();
        g.n = n;
        g.edge = new boolean[n][n];
        g.name = new String[n];
        // distinctive names so fuzzy "known" matching can't collide by accident
        for (int i = 0; i < n; i++) {
            StringBuilder sb = new StringBuilder();
            for (int k = 0; k < 10; k++) sb.append((char) ('a' + r.nextInt(26)));
            g.name[i] = "Topic" + i + "-" + sb;
        }
        int[] perm = new int[n];
        for (int i = 0; i < n; i++) perm[i] = i;
        for (int i = n - 1; i > 0; i--) { int j = r.nextInt(i + 1); int t = perm[i]; perm[i] = perm[j]; perm[j] = t; }
        for (int u = 0; u < n; u++)
            for (int v = 0; v < n; v++) {
                if (u == v) continue;
                if (!allowCycles && perm[u] > perm[v]) continue;      // acyclic: only forward in a hidden order
                if (r.nextDouble() < p) g.edge[u][v] = true;
            }
        return g;
    }

    /** Builds Course objects: every vertex becomes a course (so cycles are expressible). */
    static List<CourseDatabase.Course> toCourseList(RandomGraph g) {
        List<CourseDatabase.Course> list = new ArrayList<>();
        for (int v = 0; v < g.n; v++) {
            List<String> pre = new ArrayList<>();
            for (int u = 0; u < g.n; u++) if (g.edge[u][v]) pre.add(g.name[u]);
            list.add(new CourseDatabase.Course(v + 1, g.name[v], "Cat", "d", pre,
                    new ArrayList<>(Arrays.asList("s")), new ArrayList<>(Arrays.asList("c")), new ArrayList<>(Arrays.asList("t"))));
        }
        return list;
    }

    static void graphOracles(Random rnd) {
        int topoBad = 0, cycleBad = 0, coreBad = 0, unlockBad = 0, compBad = 0, pathBad = 0, minBad = 0, capBad = 0, graphs = 0;
        for (int iter = 0; iter < 600; iter++) {
            int n = 1 + rnd.nextInt(11);
            boolean cyc = iter % 3 == 0;
            RandomGraph rg = randomGraph(rnd, n, 0.1 + rnd.nextDouble() * 0.35, cyc);
            CourseGraph g = new CourseGraph(toCourseList(rg));
            graphs++;
            // vertex index <-> random-graph index (courses are added in order)
            int[] vOf = new int[n];
            for (int i = 0; i < n; i++) vOf[i] = g.nodeForCourse(i + 1);

            // reachability (transitive closure, length >= 1)
            boolean[][] reach = new boolean[n][n];
            for (int u = 0; u < n; u++) for (int v = 0; v < n; v++) reach[u][v] = rg.edge[u][v];
            for (int k = 0; k < n; k++) for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) if (reach[i][k] && reach[k][j]) reach[i][j] = true;
            boolean oracleCycle = false;
            for (int v = 0; v < n; v++) if (reach[v][v]) oracleCycle = true;

            CourseGraph.TopoResult t = g.topologicalSort();
            if (t.hasCycle != oracleCycle) cycleBad++;

            // topological order validity: every processed vertex appears after all its prerequisites
            int[] pos = new int[g.vertexCount()];
            Arrays.fill(pos, -1);
            for (int i = 0; i < t.order.length; i++) pos[t.order[i]] = i;
            for (int v = 0; v < n; v++) {
                if (pos[vOf[v]] == -1) continue;
                for (int u = 0; u < n; u++) if (rg.edge[u][v] && (pos[vOf[u]] == -1 || pos[vOf[u]] > pos[vOf[v]])) topoBad++;
            }
            // acyclic: every vertex processed; cyclic: processed == those that cannot be reached from a cycle
            for (int v = 0; v < n; v++) {
                boolean downstreamOfCycle = false;
                for (int c = 0; c < n; c++) if (reach[c][c] && (c == v || reach[c][v])) downstreamOfCycle = true;
                if ((pos[vOf[v]] == -1) != downstreamOfCycle) topoBad++;
            }
            // levels: longest path from a source (only for processed vertices)
            for (int v = 0; v < n; v++) {
                if (pos[vOf[v]] == -1) { if (t.level[vOf[v]] != -1) topoBad++; continue; }
                int best = 0;
                // longest path via DP over order
                // computed below with memo
                best = longest(rg, v, new int[n]);
                if (t.level[vOf[v]] != best) topoBad++;
            }
            // cyclic core == vertices that can reach a cycle AND are reachable from one (or lie on one)
            if (oracleCycle) {
                List<String> expectCore = new ArrayList<>();
                for (int v = 0; v < n; v++) {
                    boolean fromCycle = false, toCycle = false;
                    for (int c = 0; c < n; c++) {
                        if (!reach[c][c]) continue;
                        if (c == v || reach[c][v]) fromCycle = true;
                        if (c == v || reach[v][c]) toCycle = true;
                    }
                    if (fromCycle && toCycle) expectCore.add(rg.name[v]);
                }
                List<String> gotCore = new ArrayList<>(t.cyclicCore);
                Collections.sort(expectCore); Collections.sort(gotCore);
                if (!expectCore.equals(gotCore)) coreBad++;
            } else if (!t.cyclicCore.isEmpty() || !t.blocked.isEmpty()) coreBad++;

            // unlocks == BFS shortest distance reference
            for (int s = 0; s < n; s++) {
                int[] dist = new int[n];
                Arrays.fill(dist, -1);
                dist[s] = 0;
                List<Integer> q = new ArrayList<>();
                q.add(s);
                for (int h = 0; h < q.size(); h++) {
                    int u = q.get(h);
                    for (int v = 0; v < n; v++) if (rg.edge[u][v] && dist[v] == -1) { dist[v] = dist[u] + 1; q.add(v); }
                }
                List<CourseGraph.Reach> got = g.unlocks(s + 1);
                int expectCount = 0;
                for (int v = 0; v < n; v++) if (v != s && dist[v] > 0) expectCount++;
                if (got.size() != expectCount) unlockBad++;
                for (CourseGraph.Reach rr : got) if (dist[rr.courseId - 1] != rr.distance || rr.courseId - 1 == s) unlockBad++;
            }

            // weak components == union-find reference
            int[] uf = new int[n];
            for (int i = 0; i < n; i++) uf[i] = i;
            for (int u = 0; u < n; u++) for (int v = 0; v < n; v++) if (rg.edge[u][v]) { int a = find(uf, u), b = find(uf, v); if (a != b) uf[a] = b; }
            int expectComps = 0;
            for (int i = 0; i < n; i++) if (find(uf, i) == i) expectComps++;
            int[] comp = g.weakComponents();
            if (g.componentCount(comp) != expectComps) compBad++;
            for (int u = 0; u < n; u++) for (int v = 0; v < n; v++)
                if ((comp[vOf[u]] == comp[vOf[v]]) != (find(uf, u) == find(uf, v))) compBad++;

            // learning path validity for every course as target, random known sets, random caps
            for (int target = 0; target < n; target++) {
                List<String> known = new ArrayList<>();
                for (int v = 0; v < n; v++) if (v != target && rnd.nextInt(5) == 0) known.add(rg.name[v]);
                int cap = 1 + rnd.nextInt(3);
                CourseGraph.PathResult pr = g.learningPath(target + 1, known, cap);
                boolean[] kmark = g.markKnown(known);
                // oracle: needed set via reverse BFS that does not expand through known vertices
                boolean[] need = new boolean[n];
                List<Integer> q = new ArrayList<>();
                need[target] = true;
                q.add(target);
                boolean[] seen = new boolean[n];
                seen[target] = true;
                for (int h = 0; h < q.size(); h++) {
                    int v = q.get(h);
                    for (int u = 0; u < n; u++) if (rg.edge[u][v] && !seen[u]) {
                        seen[u] = true;
                        if (kmark[vOf[u]]) continue;
                        need[u] = true;
                        q.add(u);
                    }
                }
                // independent oracle: a needed vertex is blocked iff it lies on, or downstream of, a cycle
                boolean needsCycle = false;
                for (int v = 0; v < n && !needsCycle; v++) {
                    if (!need[v]) continue;
                    for (int c = 0; c < n; c++) if (reach[c][c] && (c == v || reach[c][v])) needsCycle = true;
                }
                if (kmark[vOf[target]]) { if (!pr.status.equals("ALREADY_KNOWN")) pathBad++; continue; }
                if (needsCycle) { if (!pr.status.equals("BLOCKED_BY_CYCLE")) pathBad++; continue; }
                if (!pr.status.equals("OK")) { pathBad++; continue; }
                int neededCount = 0;
                for (int v = 0; v < n; v++) if (need[v]) neededCount++;
                if (pr.steps.size() != neededCount) pathBad++;
                int[] semOfName = new int[n];
                Arrays.fill(semOfName, -1);
                int[] perSem = new int[n + 3];
                int maxSem = 0;
                for (CourseGraph.PathStep st : pr.steps) {
                    int idx = indexOfName(rg.name, st.name);
                    if (idx < 0 || !need[idx]) { pathBad++; continue; }
                    semOfName[idx] = st.semester;
                    perSem[Math.min(st.semester, n + 2)]++;
                    if (st.semester > maxSem) maxSem = st.semester;
                    if (st.semester < 1) pathBad++;           // all vertices are courses here
                }
                for (int v = 0; v < n; v++) for (int u = 0; u < n; u++)
                    if (need[v] && need[u] && rg.edge[u][v] && !(semOfName[u] < semOfName[v])) pathBad++;   // prerequisite strictly earlier
                for (int s = 1; s < perSem.length; s++) if (perSem[s] > cap) capBad++;
                if (pr.semesters != maxSem) pathBad++;
                // minSemesters == longest chain inside the needed subgraph
                int longestChain = 0;
                for (int v = 0; v < n; v++) if (need[v]) longestChain = Math.max(longestChain, chainInNeeded(rg, need, v));
                if (pr.minSemesters != longestChain) minBad++;
                if (pr.semesters < pr.minSemesters || pr.semesters < (neededCount + cap - 1) / cap) minBad++;   // lower bounds
            }
        }
        check("topological order valid / levels == longest path / processed set exact (" + graphs + " random graphs, 1/3 cyclic)", topoBad == 0);
        check("cycle detection == transitive-closure oracle", cycleBad == 0);
        check("cyclic core / blocked vertices == oracle (on-cycle or between cycles)", coreBad == 0);
        check("unlocks == BFS shortest-distance oracle for every course", unlockBad == 0);
        check("weakly connected components == union-find oracle", compBad == 0);
        check("learning path: exact needed set, prerequisites strictly earlier, status ALREADY_KNOWN / BLOCKED correct", pathBad == 0);
        check("semester plan never exceeds the per-semester cap", capBad == 0);
        check("semester plan: minSemesters == longest needed chain; semesters >= minSemesters and >= ceil(courses/cap)", minBad == 0);
    }

    static int find(int[] uf, int x) { while (uf[x] != x) { uf[x] = uf[uf[x]]; x = uf[x]; } return x; }

    static int indexOfName(String[] names, String n) {
        for (int i = 0; i < names.length; i++) if (names[i].equals(n)) return i;
        return -1;
    }

    /** Longest path ending at v (edges counted), valid for vertices not downstream of a cycle. */
    static int longest(RandomGraph g, int v, int[] memo) {
        if (memo[v] != 0) return memo[v] - 1;
        int best = 0;
        for (int u = 0; u < g.n; u++) if (g.edge[u][v]) best = Math.max(best, longest(g, u, memo) + 1);
        memo[v] = best + 1;
        return best;
    }

    /** Number of vertices on the longest chain ending at v, using only 'need' vertices. */
    static int chainInNeeded(RandomGraph g, boolean[] need, int v) {
        int best = 0;
        for (int u = 0; u < g.n; u++) if (need[u] && g.edge[u][v]) best = Math.max(best, chainInNeeded(g, need, u));
        return best + 1;
    }

    // ------------------------------------------------------------------
    // Graph over odd data coming through FileHandler -> CourseDatabase
    // ------------------------------------------------------------------
    static void graphFromFiles(Path dir) throws Exception {
        String f = writeTemp(dir, "odd.txt",
                "1|Alpha|Cat|d|Alpha;Missing Topic;missing topic;  MISSING TOPIC  |S|C|T\n" +      // self + duplicates differing by case/space
                "2|Beta|Cat|d|ALPHA;alpha|S|C|T\n" +                                                   // case-variant of a course name + duplicate
                "3|Gamma|Cat|d|Beta;Delta|S|C|T\n" +                                                   // forward reference to course 4
                "4|Delta|Cat|d|Gamma|S|C|T\n" +                                                        // cycle Gamma <-> Delta
                "5|Epsilon|Cat|d||S|C|T\n" +                                                           // isolated, no prerequisites
                "6|Beta|Cat|d|Epsilon|S|C|T\n");                                                       // duplicate course NAME with a different id
        CourseDatabase db = new CourseDatabase(f);
        CourseGraph g = new CourseGraph(db);
        check("odd file: all 6 courses load (names may repeat)", db.getAllCourses().size() == 6);
        check("odd file: self-prerequisite ignored with a warning", hasWarning(g, "itself"));
        check("odd file: duplicate prerequisites (case/space variants) ignored with warnings", countWarnings(g, "Duplicate prerequisite") >= 3);
        check("odd file: duplicate course name warned", hasWarning(g, "Duplicate course name"));
        check("odd file: missing prerequisite becomes ONE foundation vertex (case-insensitive)", countFoundations(g) == 1);
        CourseGraph.TopoResult t = g.topologicalSort();
        check("odd file: cycle Gamma<->Delta detected, no crash", t.hasCycle && t.cyclicCore.contains("Gamma") && t.cyclicCore.contains("Delta") && t.cyclicCore.size() == 2);
        check("odd file: path into the cycle is BLOCKED_BY_CYCLE", g.learningPath(3, null, 2).status.equals("BLOCKED_BY_CYCLE") && g.learningPath(4, null, 2).status.equals("BLOCKED_BY_CYCLE"));
        check("odd file: acyclic part still plannable (course 2 needs Alpha + foundation)", g.learningPath(2, null, 2).status.equals("OK"));
        check("odd file: isolated course 5 path is just itself", namesOf(g.learningPath(5, null, 2)).equals(Arrays.asList("Epsilon")));
        check("odd file: Epsilon (5) unlocks exactly course 6 (the second 'Beta')", g.unlocks(5).size() == 1 && g.unlocks(5).get(0).courseId == 6);
        check("odd file: unlocks of unknown/zero/negative ids are empty", g.unlocks(99).isEmpty() && g.unlocks(0).isEmpty() && g.unlocks(-4).isEmpty());
        String json = JsonUtil.graphOverview(g);
        check("odd file: graph JSON builds and reports hasCycle:true", json.contains("\"hasCycle\":true") && json.startsWith("{") && json.endsWith("}"));
    }

    static boolean hasWarning(CourseGraph g, String s) { return countWarnings(g, s) > 0; }
    static int countWarnings(CourseGraph g, String s) { int c = 0; for (String w : g.getWarnings()) if (w.contains(s)) c++; return c; }
    static int countFoundations(CourseGraph g) { int c = 0; for (int v = 0; v < g.vertexCount(); v++) if (!g.isCourse(v)) c++; return c; }

    // ------------------------------------------------------------------
    // Empty dataset / null / blank handling for every engine
    // ------------------------------------------------------------------
    static void emptyAndNullHandling(Path dir) throws Exception {
        CourseDatabase empty = new CourseDatabase(dir.resolve("does-not-exist.txt").toString());
        SearchEngine se = new SearchEngine(empty);
        RecommendationEngine re = new RecommendationEngine(empty);
        CourseGraph g = new CourseGraph(empty);
        check("empty dataset: search / suggest return empty lists", se.search("anything").isEmpty() && se.suggestCourses("a", 5).isEmpty());
        check("empty dataset: recommend returns empty list", re.recommend(new RecommendationEngine.StudentProfile(
                Arrays.asList("x"), Arrays.asList("y"), Arrays.asList("z"), Arrays.asList("w"))).isEmpty());
        check("empty dataset: graph has 0 vertices/edges, no cycle", g.vertexCount() == 0 && g.edgeCount() == 0 && !g.topologicalSort().hasCycle);
        check("empty dataset: path NOT_FOUND, unlocks empty, components 0",
                g.learningPath(1, null, 2).status.equals("NOT_FOUND") && g.unlocks(1).isEmpty() && g.componentCount(g.weakComponents()) == 0);
        String gj = JsonUtil.graphOverview(g);
        check("empty dataset: graph JSON still well-formed (vertices:0, empty arrays)", gj.contains("\"vertices\":0") && gj.contains("\"nodes\":[]") && gj.contains("\"topologicalOrder\":[]"));
        check("empty dataset: JSON arrays for courses/search/scored are '[]'",
                JsonUtil.courseArray(empty.getAllCourses()).equals("[]") && JsonUtil.searchResultArray(new ArrayList<SearchEngine.SearchResult>()).equals("[]")
                        && JsonUtil.scoredCourseArray(new ArrayList<RecommendationEngine.ScoredCourse>()).equals("[]"));
        check("empty dataset: categories empty", empty.getAllCategories().isEmpty());

        CourseDatabase db = new CourseDatabase();
        SearchEngine rse = new SearchEngine(db);
        RecommendationEngine rre = new RecommendationEngine(db);
        boolean noThrow = true;
        try { check("search(null) -> empty list (no NPE)", rse.search(null).isEmpty()); } catch (Throwable t) { noThrow = false; check("search(null) -> empty list (no NPE) [threw " + t + "]", false); }
        try { check("search(\"\") / search(\"   \") -> empty list (blank query matches nothing)", rse.search("").isEmpty() && rse.search("   ").isEmpty()); } catch (Throwable t) { check("search blank [threw " + t + "]", false); }
        try { check("StudentProfile with null lists is accepted; recommend() returns an empty list",
                rre.recommend(new RecommendationEngine.StudentProfile(null, null, null, null)).isEmpty()); } catch (Throwable t) { check("StudentProfile(null...) [threw " + t + "]", false); }
        try { check("recommend(null) returns an empty list (no NPE)", rre.recommend(null).isEmpty()); } catch (Throwable t) { check("recommend(null) [threw " + t + "]", false); }
        try { check("recommend(all four lists empty) returns an empty list (nothing to match on)",
                rre.recommend(new RecommendationEngine.StudentProfile(new ArrayList<String>(), new ArrayList<String>(), new ArrayList<String>(), new ArrayList<String>())).isEmpty()); } catch (Throwable t) { check("recommend(empty profile) [threw " + t + "]", false); }
        check("graph: null / empty / blank-only known lists behave like 'knows nothing'",
                new CourseGraph(db).learningPath(3, null, 2).steps.size() == new CourseGraph(db).learningPath(3, new ArrayList<String>(Arrays.asList("", "  ", null)), 2).steps.size());
        check("graph: null course list / null elements are tolerated", new CourseGraph((List<CourseDatabase.Course>) null).vertexCount() == 0
                && new CourseGraph(new ArrayList<CourseDatabase.Course>(Arrays.asList((CourseDatabase.Course) null, course(1, "Solo")))).vertexCount() == 1);
        // JSON escaping of hostile characters
        String esc = JsonUtil.esc("a\"b\\c\nd\te\u0001f\u2028g");
        check("JsonUtil.esc escapes quote, backslash, newline, tab and control chars", esc.contains("\\\"") && esc.contains("\\\\") && esc.contains("\\n") && esc.contains("\\t") && esc.contains("\\u0001") && esc.indexOf('\n') < 0 && esc.indexOf('\t') < 0 && esc.indexOf('\u0001') < 0);
        check("JsonUtil.esc(null) is empty string", JsonUtil.esc(null).equals(""));
    }

    // ------------------------------------------------------------------
    // Locale independence (Turkish dotless-i was breaking case-insensitive search)
    // ------------------------------------------------------------------
    static void localeIndependence() {
        Locale old = Locale.getDefault();
        try {
            Locale.setDefault(new Locale("tr", "TR"));
            CourseDatabase db = new CourseDatabase();
            SearchEngine se = new SearchEngine(db);
            List<SearchEngine.SearchResult> r = se.search("ui/ux");
            check("Turkish locale: search('ui/ux') still an exact 100% match on 'UI/UX Design Principles'",
                    !r.isEmpty() && r.get(0).course.getId() == 11 && r.get(0).confidence == 100.0);
            check("Turkish locale: suggest('ui') finds 'UI/UX Design Principles'", ids(se.suggestCourses("ui", 8)).contains(11));
            check("Turkish locale: suggest('UI/') (uppercase) finds it too", ids(se.suggestCourses("UI/", 8)).contains(11));
            check("Turkish locale: edit distance 'INFO' vs 'info' == 0", SearchEngine.editDistance("INFO", "info") == 0);
            CourseGraph g = new CourseGraph(db);
            boolean[] k = g.markKnown(new ArrayList<String>(Arrays.asList("BASIC PROGRAMMING")));
            boolean any = false;
            for (boolean b : k) any |= b;
            check("Turkish locale: known-skill matching is case-insensitive ('BASIC PROGRAMMING')", any);
        } finally {
            Locale.setDefault(old);
        }
        check("JSON decimals use '.' regardless of locale", jsonDecimalLocaleSafe());
    }

    static boolean jsonDecimalLocaleSafe() {
        Locale old = Locale.getDefault();
        try {
            Locale.setDefault(new Locale("de", "DE"));
            CourseDatabase.Course c = course(1, "X");
            String j = JsonUtil.scoredCourse(new RecommendationEngine.ScoredCourse(c, 40.5, true, new ArrayList<String>()));
            String s = JsonUtil.searchResult(new SearchEngine.SearchResult(c, 87.0));
            return j.contains("\"score\":40.5") && s.contains("\"confidence\":87");
        } finally {
            Locale.setDefault(old);
        }
    }

    // ------------------------------------------------------------------
    // Wiring: Trie and Graph are reachable from the application (not dead code)
    // ------------------------------------------------------------------
    static void wiringChecks() throws Exception {
        String web = new String(Files.readAllBytes(new File("src/WebServer.java").toPath()), StandardCharsets.UTF_8);
        String main = new String(Files.readAllBytes(new File("src/Main.java").toPath()), StandardCharsets.UTF_8);
        String se = new String(Files.readAllBytes(new File("src/SearchEngine.java").toPath()), StandardCharsets.UTF_8);
        check("WebServer wires /api/suggest to SearchEngine.suggestCourses (Trie)", web.contains("/api/suggest") && web.contains("searchEngine.suggestCourses"));
        check("console Main uses SearchEngine.suggestCourses (Trie)", main.contains("searchEngine.suggestCourses"));
        check("SearchEngine builds its tries from db.getAllCourses()", se.contains("db.getAllCourses()") && se.contains("new CourseTrie()"));
        check("WebServer wires graph endpoints to CourseGraph", web.contains("courseGraph.learningPath") && web.contains("courseGraph.unlocks") && web.contains("JsonUtil.graphOverview(courseGraph)"));
        check("WebServer builds the graph from the same CourseDatabase", web.contains("new CourseGraph(database)"));
    }
}
