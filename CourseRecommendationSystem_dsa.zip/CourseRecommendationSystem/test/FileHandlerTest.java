import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * Phase 1 regression test: FileHandler + CourseDatabase.
 * Every case writes a REAL file to a temp folder and loads it - nothing is mocked.
 *
 * Run (from project root):
 *   javac -d bin src/*.java && javac -cp bin -d bin test/FileHandlerTest.java && java -cp bin FileHandlerTest
 */
public class FileHandlerTest {
    static int fail = 0, total = 0;
    static Path dir;

    static void check(String name, boolean ok) {
        total++;
        System.out.println((ok ? "PASS " : "FAIL ") + name);
        if (!ok) fail++;
    }

    static final String GOOD1 = "1|Alpha|Cat|Desc one|Basic;Other|S1;S2|C1|T1";
    static final String GOOD2 = "2|Beta|Cat|Desc two||S1|C1;C2|T1;T2";

    static String write(String name, byte[] bytes) throws IOException {
        Path p = dir.resolve(name);
        Files.write(p, bytes);
        return p.toString();
    }

    static String write(String name, String content) throws IOException {
        return write(name, content.getBytes(StandardCharsets.UTF_8));
    }

    /** Loads a file; a throw counts as failure of the "never throws" contract. */
    static FileHandler.LoadResult load(String path) {
        try {
            return FileHandler.loadCourses(path);
        } catch (Throwable t) {
            System.out.println("   !! FileHandler threw " + t);
            return null;
        }
    }

    public static void main(String[] args) throws Exception {
        dir = Files.createTempDirectory("fhtest");

        // ---- the shipped dataset ----
        FileHandler.LoadResult real = load("data/courses.txt");
        check("shipped data/courses.txt loads: 14 courses, no error, no skipped lines",
                real != null && real.courses.size() == 14 && real.error == null && real.linesSkipped == 0);
        CourseDatabase db = new CourseDatabase();
        check("CourseDatabase() default == FileHandler result (same 14 ids, same order)", sameIds(db.getAllCourses(), real.courses));
        check("CourseDatabase.getCourseById(14) is 'Data Structures and Algorithms'",
                db.getCourseById(14) != null && db.getCourseById(14).getName().equals("Data Structures and Algorithms"));
        check("CourseDatabase.getCourseById(0/999/-1) is null",
                db.getCourseById(0) == null && db.getCourseById(999) == null && db.getCourseById(-1) == null);
        check("course 10 and 11 have empty prerequisite lists (not null)",
                db.getCourseById(10).getPrerequisites().isEmpty() && db.getCourseById(11).getPrerequisites().isEmpty());
        check("course 1 prerequisites parsed as [Basic Programming, Statistics]",
                db.getCourseById(1).getPrerequisites().equals(java.util.Arrays.asList("Basic Programming", "Statistics")));
        check("categories are distinct and sorted",
                isSortedDistinct(db.getAllCategories()));

        // ---- missing / unusable paths ----
        FileHandler.LoadResult r = load(dir.resolve("nope.txt").toString());
        check("missing file: no throw, error set, 0 courses", r != null && r.error != null && r.courses.isEmpty());
        r = load(dir.toString());
        check("directory instead of file: no throw, error set, 0 courses", r != null && r.error != null && r.courses.isEmpty());
        r = load("");
        check("empty path string: no throw, error set", r != null && r.error != null && r.courses.isEmpty());
        CourseDatabase missingDb = new CourseDatabase(dir.resolve("nope.txt").toString());
        check("CourseDatabase over missing file: empty list, still usable", missingDb.getAllCourses().isEmpty()
                && missingDb.getCourseById(1) == null && missingDb.getAllCategories().isEmpty());

        // ---- empty / comment-only / whitespace-only ----
        r = load(write("empty.txt", ""));
        check("empty file (0 bytes): no throw, error set, 0 courses", r != null && r.error != null && r.courses.isEmpty());
        r = load(write("comments.txt", "# only comments\n# another\n"));
        check("comment-only file: no throw, error set, 0 courses, 0 warnings", r != null && r.error != null && r.courses.isEmpty() && r.warnings.isEmpty());
        r = load(write("blank.txt", "\n   \n\t\n\n"));
        check("whitespace-only file: no throw, error set, 0 courses", r != null && r.error != null && r.courses.isEmpty());
        r = load(write("allbad.txt", "garbage\nmore garbage\n"));
        check("file with only malformed lines: error set, 0 courses, 2 skipped", r != null && r.error != null && r.courses.isEmpty() && r.linesSkipped == 2);

        // ---- malformed lines mixed with good ones: good ones survive ----
        r = load(write("mixed.txt", GOOD1 + "\nthis is not a course\n" + GOOD2 + "\n"));
        check("malformed line skipped, valid lines kept (2 courses, 1 skipped, no fatal error)",
                r != null && r.courses.size() == 2 && r.linesSkipped == 1 && r.error == null);
        check("warning names the offending line number (line 2)", r != null && r.warnings.size() == 1 && r.warnings.get(0).startsWith("Line 2"));
        r = load(write("seven.txt", "3|A|B|C|D|E|F\n" + GOOD1));
        check("7 fields -> skipped; 9 fields -> skipped", r != null && r.courses.size() == 1);
        r = load(write("nine.txt", "3|A|B|C|D|E|F|G|H\n" + GOOD1));
        check("9 fields -> skipped, rest kept", r != null && r.courses.size() == 1 && r.linesSkipped == 1);
        r = load(write("pipeinside.txt", "3|Name|Cat|desc with | pipe|P|S|C|T\n" + GOOD1));
        check("'|' inside a field (9 fields) is rejected, not mis-parsed", r != null && r.courses.size() == 1 && r.linesSkipped == 1);

        // ---- invalid ids ----
        String[] badIds = {"abc", "", "0", "-5", "1.5", "99999999999999999999", " ", "1e3", "0x10"};
        for (String bad : badIds) {
            r = load(write("badid.txt", bad + "|N|C|D|P|S|C|T\n" + GOOD2));
            check("invalid id '" + bad + "' skipped, valid line kept",
                    r != null && r.courses.size() == 1 && r.courses.get(0).getId() == 2 && r.linesSkipped == 1);
        }
        r = load(write("idspace.txt", "  7  |Seven|Cat|Desc|P|S|C|T\n"));
        check("id with surrounding spaces ' 7 ' accepted as 7", r != null && r.courses.size() == 1 && r.courses.get(0).getId() == 7);

        // ---- duplicate ids ----
        r = load(write("dupid.txt", GOOD1 + "\n1|Another|Cat|Dup desc|P|S|C|T\n" + GOOD2));
        check("duplicate id: first kept, later duplicate skipped, 2 courses",
                r != null && r.courses.size() == 2 && r.linesSkipped == 1 && r.courses.get(0).getName().equals("Alpha"));
        check("duplicate id warning mentions 'duplicate'", r != null && r.warnings.get(0).toLowerCase().contains("duplicate"));
        // a skipped line must NOT burn an id (invalid line with id 5 followed by a valid line with id 5)
        r = load(write("burn.txt", "5||Cat|Desc|P|S|C|T\n5|Five|Cat|Desc|P|S|C|T\n"));
        check("rejected line does not reserve its id (later valid id 5 accepted)", r != null && r.courses.size() == 1 && r.courses.get(0).getName().equals("Five"));

        // ---- required fields ----
        String[] badLines = {
                "4||Cat|Desc|P|S|C|T",          // empty name
                "4|N||Desc|P|S|C|T",            // empty category
                "4|N|Cat||P|S|C|T",             // empty description
                "4|N|Cat|Desc|P||C|T",          // empty skills
                "4|N|Cat|Desc|P|S||T",          // empty careers
                "4|N|Cat|Desc|P|S|C|",          // empty interests
                "4|N|Cat|Desc|P|;;|C|T",        // skills = only separators
        };
        for (String bl : badLines) {
            r = load(write("req.txt", bl + "\n" + GOOD1));
            check("required-field violation skipped: " + bl, r != null && r.courses.size() == 1 && r.linesSkipped == 1);
        }
        r = load(write("noprereq.txt", "4|N|Cat|Desc||S|C|T\n"));
        check("empty prerequisites field is allowed -> empty list", r != null && r.courses.size() == 1 && r.courses.get(0).getPrerequisites().isEmpty());
        r = load(write("listblanks.txt", "4|N|Cat|Desc| A ;; B ; |S|C|T\n"));
        check("list items trimmed, blank items dropped -> [A, B]",
                r != null && r.courses.get(0).getPrerequisites().equals(java.util.Arrays.asList("A", "B")));

        // ---- encodings / line endings / trailing whitespace ----
        r = load(write("bom.txt", "\uFEFF" + GOOD1 + "\n" + GOOD2 + "\n"));
        check("UTF-8 BOM on first line is stripped (2 courses)", r != null && r.courses.size() == 2 && r.error == null);
        r = load(write("crlf.txt", GOOD1 + "\r\n" + GOOD2 + "\r\n"));
        check("Windows CRLF line endings (2 courses, fields clean)", r != null && r.courses.size() == 2
                && r.courses.get(1).getInterestTags().equals(java.util.Arrays.asList("T1", "T2")));
        r = load(write("nonl.txt", GOOD1 + "\n" + GOOD2));
        check("no trailing newline (2 courses)", r != null && r.courses.size() == 2);
        r = load(write("unicode.txt", "8|Caf\u00e9 \u4e2d\u6587 \u0c24\u0c46\u0c32\u0c41\u0c17\u0c41|Cat|D\u00e9sc \ud83d\ude42|P|S|C|T\n"));
        check("non-ASCII (accents, CJK, Telugu, emoji) loads intact", r != null && r.courses.size() == 1
                && r.courses.get(0).getName().equals("Caf\u00e9 \u4e2d\u6587 \u0c24\u0c46\u0c32\u0c41\u0c17\u0c41"));
        byte[] bad = new byte[]{'1', '|', 'N', (byte) 0xC3, (byte) 0x28, '|', 'C', '|', 'D', '|', 'P', '|', 'S', '|', 'C', '|', 'T', '\n'};
        r = load(write("badutf8.txt", bad));
        check("malformed UTF-8 bytes: no throw (error reported, empty list or partial)", r != null);
        r = load(write("indented.txt", "   " + GOOD1 + "   \n\t" + GOOD2 + "\n"));
        check("leading/trailing whitespace on a record line tolerated", r != null && r.courses.size() == 2);
        r = load(write("hashname.txt", "9|C# Programming|Cat|Uses # inside|P|S|C|T\n"));
        check("'#' inside a field is NOT treated as a comment", r != null && r.courses.size() == 1);
        r = load(write("indentcomment.txt", "   # indented comment\n" + GOOD1 + "\n"));
        check("indented comment line ignored", r != null && r.courses.size() == 1 && r.warnings.isEmpty());

        // ---- scale / robustness ----
        StringBuilder big = new StringBuilder();
        for (int i = 1; i <= 5000; i++) big.append(i).append("|Course ").append(i).append("|Cat").append(i % 7).append("|Desc ").append(i).append("|P").append(i % 5).append("|S|C|T\n");
        long t0 = System.currentTimeMillis();
        r = load(write("big.txt", big.toString()));
        long ms = System.currentTimeMillis() - t0;
        check("5000-line file loads fully (" + ms + " ms)", r != null && r.courses.size() == 5000 && r.linesSkipped == 0);
        StringBuilder longLine = new StringBuilder("6|");
        for (int i = 0; i < 200000; i++) longLine.append('x');
        longLine.append("|Cat|Desc|P|S|C|T\n");
        r = load(write("long.txt", longLine.toString()));
        check("200,000-character line loads without throwing", r != null && r.courses.size() == 1);

        // ---- CourseDatabase over a custom file via the 1-arg constructor and the system property ----
        CourseDatabase custom = new CourseDatabase(write("custom.txt", GOOD1 + "\n" + GOOD2 + "\n"));
        check("CourseDatabase(path) serves exactly the file's courses", custom.getAllCourses().size() == 2 && custom.getCourseById(2).getName().equals("Beta"));
        System.setProperty("courses.file", dir.resolve("custom.txt").toString());
        CourseDatabase viaProp = new CourseDatabase();
        check("-Dcourses.file is honoured by CourseDatabase()", viaProp.getAllCourses().size() == 2);
        System.clearProperty("courses.file");

        // ---- production code must not carry the old hardcoded dataset ----
        boolean hardcoded = false;
        for (File f : new File("src").listFiles()) {
            if (!f.getName().endsWith(".java")) continue;
            // Look at CODE lines only (doc comments legitimately mention example course names).
            StringBuilder code = new StringBuilder();
            for (String line : Files.readAllLines(f.toPath(), StandardCharsets.UTF_8)) {
                String t = line.trim();
                if (t.startsWith("//") || t.startsWith("*") || t.startsWith("/*")) continue;
                code.append(line).append('\n');
            }
            String src = code.toString();
            // The old dataset was built from literal 'new Course(...)' records.
            // FileHandler is the only class allowed to construct a Course (from file contents).
            if (!f.getName().equals("FileHandler.java")
                    && (src.contains("new CourseDatabase.Course(") || src.contains("new Course("))) hardcoded = true;
            // ... and a dataset course name must not appear as a string literal in any code line.
            if (src.contains("\"Machine Learning Fundamentals\"") || src.contains("\"Data Science Essentials\"")
                    || src.contains("\"Deep Learning with Neural Networks\"")) hardcoded = true;
        }
        check("no production source contains hardcoded course records", !hardcoded);

        System.out.println(fail == 0 ? "ALL PASSED (" + total + " checks)" : fail + " FAILED of " + total);
        System.exit(fail);
    }

    static boolean sameIds(List<CourseDatabase.Course> a, List<CourseDatabase.Course> b) {
        if (a.size() != b.size()) return false;
        for (int i = 0; i < a.size(); i++) if (a.get(i).getId() != b.get(i).getId()) return false;
        return true;
    }

    static boolean isSortedDistinct(List<String> l) {
        for (int i = 1; i < l.size(); i++) if (l.get(i - 1).compareToIgnoreCase(l.get(i)) >= 0) return false;
        return !l.isEmpty();
    }
}
