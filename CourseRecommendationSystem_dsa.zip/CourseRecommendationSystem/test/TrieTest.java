import java.util.List;

/** Run: javac -cp bin -d bin test/TrieTest.java && java -cp bin TrieTest  (from project root) */
public class TrieTest {
    static int fail = 0;
    static void check(String name, boolean ok) {
        System.out.println((ok ? "PASS " : "FAIL ") + name);
        if (!ok) fail++;
    }
    static boolean has(List<CourseDatabase.Course> l, String n) {
        for (CourseDatabase.Course c : l) if (c.getName().equals(n)) return true;
        return false;
    }
    public static void main(String[] a) {
        CourseDatabase db = new CourseDatabase();
        check("loaded 14+ courses from data/courses.txt", db.getAllCourses().size() >= 14);
        SearchEngine se = new SearchEngine(db);
        check("trie has nodes", se.getTrieNodeCount() > 100);
        check("'Mach' -> Machine Learning", has(se.suggestCourses("Mach", 8), "Machine Learning Fundamentals"));
        check("'mach' lowercase same", se.suggestCourses("mach", 8).size() == se.suggestCourses("Mach", 8).size());
        check("'MACH' uppercase same", has(se.suggestCourses("MACH", 8), "Machine Learning Fundamentals"));
        check("'Data' partial -> several", se.suggestCourses("Data", 8).size() >= 2);
        check("full name exact", se.suggestCourses("Computer Networking", 8).size() >= 1);
        check("word start 'Learn' -> Deep Learning", has(se.suggestCourses("Learn", 8), "Deep Learning with Neural Networks"));
        check("no match 'zzz' empty", se.suggestCourses("zzz", 8).isEmpty());
        check("empty input empty", se.suggestCourses("", 8).isEmpty());
        check("blank input empty", se.suggestCourses("   ", 8).isEmpty());
        check("null input empty", se.suggestCourses(null, 8).isEmpty());
        check("limit respected", se.suggestCourses("d", 2).size() <= 2);
        List<CourseDatabase.Course> l = se.suggestCourses("d", 50);
        boolean dup = false;
        for (int i = 0; i < l.size(); i++) for (int j = i + 1; j < l.size(); j++) if (l.get(i).getId() == l.get(j).getId()) dup = true;
        check("no duplicate courses", !dup);
        // duplicate names: two different courses same name both returned once each
        CourseTrie t = new CourseTrie();
        CourseDatabase.Course c1 = db.getCourseById(1), c2 = db.getCourseById(2);
        t.insert("Same Name", c1); t.insert("Same Name", c2); t.insert("same name", c1);
        check("duplicate names: 2 distinct courses, re-insert ignored", t.startsWith("same").size() == 2);
        check("trailing-space prefix 'Mach ' ok", has(se.suggestCourses("Mach ", 8), "Machine Learning Fundamentals"));
        check("special char 'UI/' ok", has(se.suggestCourses("UI/", 8), "UI/UX Design Principles"));
        // existing algorithms
        check("KMP", SearchEngine.kmpContains("machine learning", "chine"));
        check("Rabin-Karp", SearchEngine.rabinKarpContains("machine learning", "learn"));
        check("Edit distance", SearchEngine.editDistance("kitten", "sitting") == 3);
        check("search exact", se.search("Machine Learning").get(0).confidence == 100.0);
        check("search fuzzy typo", has(toCourses(se.search("Machne Learning")), "Machine Learning Fundamentals"));
        System.out.println(fail == 0 ? "ALL PASSED" : fail + " FAILED");
        System.exit(fail);
    }
    static List<CourseDatabase.Course> toCourses(List<SearchEngine.SearchResult> r) {
        List<CourseDatabase.Course> o = new java.util.ArrayList<>();
        for (SearchEngine.SearchResult s : r) o.add(s.course);
        return o;
    }
}
