import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Run (project root): javac -cp bin -d bin test/GraphTest.java && java -cp bin GraphTest */
public class GraphTest {
    static int fail = 0;
    static void check(String n, boolean ok) { System.out.println((ok ? "PASS " : "FAIL ") + n); if (!ok) fail++; }

    static CourseDatabase.Course mk(int id, String name, String... pre) {
        return new CourseDatabase.Course(id, name, "Cat", "desc", new ArrayList<>(Arrays.asList(pre)),
                new ArrayList<>(Arrays.asList("s")), new ArrayList<>(Arrays.asList("c")), new ArrayList<>(Arrays.asList("t")));
    }
    static List<String> names(CourseGraph.PathResult r) { List<String> o = new ArrayList<>(); for (CourseGraph.PathStep s : r.steps) o.add(s.name); return o; }
    static int sem(CourseGraph.PathResult r, String n) { for (CourseGraph.PathStep s : r.steps) if (s.name.equals(n)) return s.semester; return -99; }

    public static void main(String[] a) {
        // ---------- real dataset ----------
        CourseDatabase db = new CourseDatabase();
        CourseGraph g = new CourseGraph(db);
        check("real graph: 14 courses + 4 foundations = 18 vertices", g.vertexCount() == 18);
        check("real graph: 16 edges", g.edgeCount() == 16);
        CourseGraph.TopoResult t = g.topologicalSort();
        check("real graph is acyclic", !t.hasCycle && t.order.length == 18);
        boolean orderOk = true; int[] pos = new int[g.vertexCount()];
        for (int i = 0; i < t.order.length; i++) pos[t.order[i]] = i;
        for (int v = 0; v < g.vertexCount(); v++) for (String p : g.prerequisitesOf(v)) {
            for (int u = 0; u < g.vertexCount(); u++) if (g.nameOf(u).equalsIgnoreCase(p) && pos[u] > pos[v]) orderOk = false; }
        check("topological order respects every edge", orderOk);
        int dl = g.nodeForCourse(3), ml = g.nodeForCourse(1);
        check("level: foundation 0, ML 1, DL 2", t.level[ml] == 1 && t.level[dl] == 2);
        int[] comp = g.weakComponents();
        check("isolated courses (10, 11) are own components", comp[g.nodeForCourse(10)] != comp[g.nodeForCourse(11)]
                && comp[g.nodeForCourse(10)] != comp[g.nodeForCourse(1)]);
        check("course with no prereqs: path is just itself, semester 1", g.learningPath(10, null, 2).steps.size() == 1
                && g.learningPath(10, null, 2).semesters == 1);

        CourseGraph.PathResult p3 = g.learningPath(3, null, 2);
        check("DL path OK", p3.status.equals("OK"));
        check("DL path has ML before DL", sem(p3, "Machine Learning Fundamentals") < sem(p3, "Deep Learning with Neural Networks"));
        check("DL path includes Basic Programming, Statistics, Linear Algebra as foundations",
                names(p3).containsAll(Arrays.asList("Basic Programming", "Statistics", "Linear Algebra")) && sem(p3, "Statistics") == 0);
        check("DL path: 2 semesters", p3.semesters == 2 && p3.minSemesters == 2);
        CourseGraph.PathResult pk = g.learningPath(3, Arrays.asList("basic programming", "Statistics", "Linear Algebra"), 2);
        check("known (case-insens.) foundations skipped", pk.alreadyKnown.size() == 3 && pk.steps.size() == 2);
        CourseGraph.PathResult pk2 = g.learningPath(3, Arrays.asList("Machine Learning Fundamentals"), 2);
        check("knowing ML prunes its prerequisites too", pk2.steps.size() == 2 && names(pk2).contains("Linear Algebra")
                && !names(pk2).contains("Statistics") && pk2.semesters == 1);
        check("already-known target", g.learningPath(3, Arrays.asList("Deep Learning with Neural Networks"), 2).status.equals("ALREADY_KNOWN"));
        check("unknown course id -> NOT_FOUND", g.learningPath(999, null, 2).status.equals("NOT_FOUND"));
        check("null/garbage known list safe", g.learningPath(3, Arrays.asList(null, "", "  "), 2).status.equals("OK"));
        check("perSemester 0/-5/99 clamped", g.learningPath(3, null, 0).perSemester == 2 && g.learningPath(3, null, 99).perSemester == 6);
        check("unlocks of ML includes DL at distance 1", g.unlocks(1).size() == 1 && g.unlocks(1).get(0).courseId == 3);
        check("unlocks of leaf is empty; unknown id empty", g.unlocks(3).isEmpty() && g.unlocks(999).isEmpty());
        check("JSON overview builds", JsonUtil.graphOverview(g).contains("\"vertices\":18"));

        // ---------- synthetic edge cases ----------
        // multiple dependencies + cap: D needs B and C, both need A ; E independent of A
        CourseGraph d = new CourseGraph(Arrays.asList(mk(1, "A"), mk(2, "B", "A"), mk(3, "C", "A"), mk(4, "D", "B", "C"), mk(5, "E")));
        CourseGraph.PathResult pd = d.learningPath(4, null, 1);
        check("diamond cap=1: A,B,C,D in 4 semesters", pd.semesters == 4 && pd.minSemesters == 3);
        CourseGraph.PathResult pd2 = d.learningPath(4, null, 2);
        check("diamond cap=2: B and C share a semester (3 total)", pd2.semesters == 3 && sem(pd2, "B") == sem(pd2, "C"));
        check("diamond: independent E not in path", !names(pd2).contains("E"));
        check("diamond: D has 2 direct prerequisites", d.prerequisitesOf(d.nodeForCourse(4)).size() == 2);

        // missing prerequisite reference -> foundation vertex, no crash
        CourseGraph m = new CourseGraph(Arrays.asList(mk(1, "X", "Ghost Topic")));
        check("missing prereq becomes foundation vertex", m.vertexCount() == 2 && !m.isCourse(1) && m.learningPath(1, null, 2).semesters == 1);

        // messy prerequisites: whitespace, case, blank, duplicate, self
        CourseGraph w = new CourseGraph(Arrays.asList(mk(1, "Base"), mk(2, "Top", "  base ", "BASE", "", "Top")));
        check("messy prereqs: 1 edge, 2 warnings, acyclic", w.edgeCount() == 1 && w.getWarnings().size() == 2 && !w.topologicalSort().hasCycle);

        // cycle: A<->B, C depends on B, F independent
        CourseGraph c = new CourseGraph(Arrays.asList(mk(1, "A", "B"), mk(2, "B", "A"), mk(3, "C", "B"), mk(4, "F")));
        CourseGraph.TopoResult ct = c.topologicalSort();
        check("cycle detected", ct.hasCycle && ct.blocked.size() == 3);
        check("cyclic core = A and B only (C is downstream)", ct.cyclicCore.size() == 2 && ct.cyclicCore.contains("A") && ct.cyclicCore.contains("B"));
        check("path into cycle blocked", c.learningPath(3, null, 2).status.equals("BLOCKED_BY_CYCLE"));
        check("independent course still plannable despite cycle", c.learningPath(4, null, 2).status.equals("OK"));
        check("cycle: knowing A cuts the cycle for B? (still blocked, level -1)", c.learningPath(2, Arrays.asList("A"), 2).status.equals("BLOCKED_BY_CYCLE"));
        check("cycle JSON hasCycle", JsonUtil.graphOverview(c).contains("\"hasCycle\":true"));

        // empty / null / duplicate names
        check("empty course list ok", new CourseGraph(new ArrayList<CourseDatabase.Course>()).vertexCount() == 0);
        check("null course list ok", new CourseGraph((List<CourseDatabase.Course>) null).topologicalSort().order.length == 0);
        CourseGraph dup = new CourseGraph(Arrays.asList(mk(1, "Same"), mk(2, "same", "Same")));
        check("duplicate course names: warning, no crash", dup.getWarnings().size() >= 1 && dup.vertexCount() == 2);

        // larger chain
        List<CourseDatabase.Course> chain = new ArrayList<>();
        for (int i = 1; i <= 500; i++) chain.add(i == 1 ? mk(i, "C1") : mk(i, "C" + i, "C" + (i - 1)));
        CourseGraph big = new CourseGraph(chain);
        check("500-course chain: levels + path", big.topologicalSort().level[big.nodeForCourse(500)] == 499
                && big.learningPath(500, null, 3).semesters == 500);

        System.out.println(fail == 0 ? "ALL PASSED" : fail + " FAILED");
        System.exit(fail);
    }
}
