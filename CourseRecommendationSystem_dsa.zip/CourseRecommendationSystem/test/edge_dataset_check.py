import json, sys, urllib.request, urllib.error, urllib.parse
B="http://localhost:8080"; bad=0; n=0
def get(p):
    global bad,n; n+=1
    try:
        r=urllib.request.urlopen(B+p,timeout=8); st=r.status; t=r.read().decode()
    except urllib.error.HTTPError as e: st=e.code; t=e.read().decode()
    except Exception as e: print("FAIL conn",p,e); bad+=1; return None,None
    try: j=json.loads(t)
    except Exception as e: print("FAIL invalid JSON",p,st,t[:100]); bad+=1; return st,None
    if st>=500: print("FAIL 5xx",p,st); bad+=1
    return st,j
mode=sys.argv[1]
for p in ["/api/status","/api/courses","/api/categories","/api/search?q=a","/api/suggest?q=a","/api/recommend?skills=x","/api/graph","/api/path?target=1","/api/unlocks?id=1","/api/course?id=1","/api/compare?id1=1&id2=2"]:
    st,j=get(p); print(" ",st,p, (json.dumps(j)[:90] if j is not None else ""))
if mode=="empty":
    st,j=get("/api/status"); assert j["totalCourses"]==0 and j["graphNodes"]==0, j
    st,j=get("/api/graph"); assert j["vertices"]==0 and j["nodes"]==[] and j["hasCycle"] is False
    assert get("/api/courses")[1]==[] and get("/api/search?q=a")[1]==[] and get("/api/suggest?q=a")[1]==[]
    assert get("/api/path?target=1")[0]==404 and get("/api/unlocks?id=1")[0]==404
if mode=="nasty":
    st,j=get("/api/courses"); assert len(j)==5, len(j)
    names=[c["name"] for c in j]; print("  names:",names)
    assert any('"' in x for x in names) and any("\\" in x for x in names) and any("\u00c9" in x for x in names)
    st,j=get("/api/graph"); assert j["hasCycle"] is True and "Course A" in j["cyclicCore"]
    st,j=get("/api/path?target=1"); assert j["status"]=="BLOCKED_BY_CYCLE", j["status"]   # the fixed bug, end to end
    st,j=get("/api/path?target=3"); assert j["status"]=="OK"
    for q in ['Quote%22','back%5Cslash','%C3%A9cole','%E0%B0%A4%E0%B1%86']:
        get("/api/suggest?q="+q); get("/api/search?q="+q)
    st,j=get("/api/suggest?q=%C3%A9"); assert [c["id"] for c in j]==[4], j   # non-ASCII exactness over HTTP
print("RESULT",mode,"requests",n,"problems",bad); sys.exit(1 if bad else 0)
