// Frontend<->backend integration check using jsdom (simulated DOM; NOT a real browser).
// Usage: NODE_PATH=<dir with node_modules/jsdom> node test/frontend_jsdom_check.js   (server must be running on :8080)
const { JSDOM, VirtualConsole } = require("jsdom");
const BASE = "http://localhost:8080";
let pass = 0, fail = 0;
const ok = (name, cond, extra) => { cond ? pass++ : fail++; console.log((cond ? "PASS " : "FAIL ") + name + (cond ? "" : "  -> " + (extra || ""))); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function load(path) {
  const errors = [];
  const vc = new VirtualConsole();
  vc.on("jsdomError", (e) => errors.push(String(e.message || e)));
  vc.on("error", (e) => errors.push(String(e)));
  const dom = await JSDOM.fromURL(BASE + path, {
    runScripts: "dangerously", resources: "usable", pretendToBeVisual: true, virtualConsole: vc,
    beforeParse(w) { w.fetch = (u, o) => fetch(new URL(u, BASE + path), o); },
  });
  await new Promise((r) => dom.window.addEventListener("load", r));
  return { dom, w: dom.window, d: dom.window.document, errors };
}
async function until(fn, ms = 4000) { const t = Date.now(); while (Date.now() - t < ms) { try { if (fn()) return true; } catch (e) {} await sleep(50); } return false; }
const txt = (d, sel) => (d.querySelector(sel) ? d.querySelector(sel).textContent : "");
function type(w, input, v) { input.value = v; input.dispatchEvent(new w.Event("input", { bubbles: true })); }

(async () => {
  // ---------- every page loads and its scripts run without errors ----------
  for (const p of ["/index.html", "/recommend.html", "/search.html", "/explore.html", "/course.html?id=1", "/compare.html"]) {
    const { errors, dom } = await load(p); await sleep(300);
    // the Google Fonts <link> cannot load in an offline sandbox; that is the only message ignored
    const real = errors.filter((e) => !e.includes("fonts.googleapis.com"));
    ok("page " + p + " loads, no script errors", real.length === 0, real.join(" | ")); dom.window.close();
  }

  // ---------- Explore: /api/courses ----------
  let { w, d, dom } = await load("/explore.html");
  ok("explore: 14 course cards rendered from /api/courses", await until(() => d.querySelectorAll(".course-card").length === 14), d.querySelectorAll(".course-card").length);
  ok("explore: category dropdown populated", d.querySelectorAll("#filter-category option").length > 5);
  const ft = d.getElementById("filter-text"); type(w, ft, "cloud");
  ok("explore: text filter 'cloud' -> 1 card", d.querySelectorAll(".course-card").length === 1);
  type(w, ft, "zzzz"); ok("explore: no match -> empty state", /No courses match/.test(txt(d, "#results")));
  dom.window.close();

  // ---------- Course details + graph endpoints ----------
  ({ w, d, dom } = await load("/course.html?id=3"));
  ok("course 3: title from /api/course", await until(() => /Deep Learning/.test(txt(d, "h1"))));
  ok("course 3: learning path rendered (foundations + semesters)", await until(() => /Learn first/.test(txt(d, "#path-box")) && /Semester 2/.test(txt(d, "#path-box"))), txt(d, "#path-box"));
  ok("course 3: path lists Machine Learning Fundamentals before DL", /Semester 1[\s\S]*Machine Learning Fundamentals[\s\S]*Semester 2[\s\S]*Deep Learning/.test(txt(d, "#path-box")));
  ok("course 3: unlocks box shows empty-state text", /Nothing in the catalog/.test(txt(d, "#unlocks-box")));
  d.getElementById("path-known").value = "Basic Programming, Statistics, Linear Algebra, Machine Learning Fundamentals";
  d.getElementById("path-btn").click();
  ok("course 3: 'known' skips prerequisites -> single semester", await until(() => /1 semester\(s\)/.test(txt(d, "#path-box")) && /Skipped \(already known\)/.test(txt(d, "#path-box"))), txt(d, "#path-box"));
  d.getElementById("path-known").value = "Deep Learning with Neural Networks"; d.getElementById("path-btn").click();
  ok("course 3: already-known target message", await until(() => /already know this course/.test(txt(d, "#path-box"))));
  dom.window.close();
  ({ w, d, dom } = await load("/course.html?id=1"));
  ok("course 1: unlocks box lists Deep Learning", await until(() => /Deep Learning with Neural Networks/.test(txt(d, "#unlocks-box"))), txt(d, "#unlocks-box"));
  dom.window.close();
  ({ w, d, dom } = await load("/course.html?id=10"));
  ok("course 10 (no prerequisites): prerequisites block says None, path = 1 semester", await until(() => /None/.test(txt(d, "#detail-container")) && /1 semester\(s\)/.test(txt(d, "#path-box"))), txt(d, "#path-box"));
  dom.window.close();
  ({ w, d, dom } = await load("/course.html?id=999")); ok("course 999: 'Course not found' state", await until(() => /Course not found/.test(txt(d, "#detail-container")))); dom.window.close();
  ({ w, d, dom } = await load("/course.html?id=abc")); ok("course abc: 'Course not found' state", await until(() => /Course not found/.test(txt(d, "#detail-container")))); dom.window.close();
  ({ w, d, dom } = await load("/course.html")); ok("course (no id): 'No course selected' state", await until(() => /No course selected/.test(txt(d, "#detail-container")))); dom.window.close();

  // ---------- Search: /api/suggest (Trie) and /api/search ----------
  ({ w, d, dom } = await load("/search.html"));
  const si = d.getElementById("search-input"), sg = d.getElementById("category-suggestions");
  type(w, si, "Mach");
  ok("search: Trie suggestion 'Mach' -> Machine Learning Fundamentals", await until(() => sg.style.display === "block" && /Machine Learning Fundamentals/.test(sg.textContent)), sg.textContent);
  ok("search: 'Mach' dropdown has exactly 1 item", sg.querySelectorAll(".suggestion-item").length === 1);
  type(w, si, "learn");
  ok("search: word-start 'learn' -> Deep Learning (Trie word index)", await until(() => /Deep Learning with Neural Networks/.test(sg.textContent)), sg.textContent);
  type(w, si, "python");
  ok("search: non-name text 'python' falls back to keyword dropdown (no Trie match)", await until(() => sg.querySelectorAll(".suggestion-item").length > 0), sg.textContent);
  type(w, si, "qqqqzzzz");
  ok("search: gibberish -> 'No courses found' in dropdown", await until(() => /No courses found/.test(sg.textContent)));
  type(w, si, "");
  ok("search: clearing input hides dropdown", await until(() => sg.style.display === "none"));
  sg.innerHTML = '<div class="suggestion-item" data-course-id="3">x</div>'; sg.style.display = "block";
  si.value = "Machne Learning"; d.getElementById("search-form").dispatchEvent(new w.Event("submit", { cancelable: true, bubbles: true }));
  ok("search: typo submit -> results with Machine Learning Fundamentals (fuzzy path)", await until(() => /Machine Learning Fundamentals/.test(txt(d, "#results")) && /% match/.test(txt(d, "#results"))), txt(d, "#results").slice(0, 120));
  si.value = "   "; d.getElementById("search-form").dispatchEvent(new w.Event("submit", { cancelable: true, bubbles: true }));
  ok("search: blank submit -> 'Enter a search term' state", /Enter a search term/.test(txt(d, "#results")));
  si.value = "qqqqzzzz"; d.getElementById("search-form").dispatchEvent(new w.Event("submit", { cancelable: true, bubbles: true }));
  ok("search: no-result submit -> empty state", await until(() => /No matching or similar courses found/.test(txt(d, "#results"))));
  dom.window.close();
  ({ w, d, dom } = await load("/search.html?q=" + encodeURIComponent("Web & <b>Dev</b>")));
  ok("search: ?q= with HTML special characters is shown escaped (no injected <b>)", await until(() => d.getElementById("results-label").textContent.includes("<b>Dev</b>")) && d.querySelectorAll("#results-label b").length === 0);
  dom.window.close();

  // ---------- Recommend ----------
  ({ w, d, dom } = await load("/recommend.html"));
  const submit = () => d.getElementById("recommend-form").dispatchEvent(new w.Event("submit", { cancelable: true, bubbles: true }));
  submit(); await sleep(150);
  ok("recommend: blank form -> validation message, no request needed", /Tell us a bit about yourself/.test(txt(d, "#results")));
  d.getElementById("interests").value = "Machine Learning, Data"; d.getElementById("skills").value = "Python, Statistics";
  d.getElementById("qualifications").value = "Basic Programming, Statistics"; d.getElementById("careerGoals").value = "Data Scientist"; submit();
  ok("recommend: ranked cards rendered (<=5) with scores", await until(() => { const n = d.querySelectorAll(".course-card").length; return n >= 1 && n <= 5 && /\/100/.test(txt(d, "#results")); }), txt(d, "#results").slice(0, 120));
  ok("recommend: top card is ML or Data Science", /^1\. (Machine Learning Fundamentals|Data Science Essentials)/.test(txt(d, ".course-card h3").trim()), txt(d, ".course-card h3"));
  ok("recommend: eligible/missing-prerequisite badges present", d.querySelectorAll(".badge-good,.badge-warn").length >= 1);
  d.getElementById("interests").value = ""; d.getElementById("skills").value = "   "; d.getElementById("qualifications").value = ""; d.getElementById("careerGoals").value = ""; submit(); await sleep(150);
  ok("recommend: whitespace-only form -> validation message", /Tell us a bit about yourself/.test(txt(d, "#results")));
  dom.window.close();

  // ---------- Compare ----------
  ({ w, d, dom } = await load("/compare.html?id1=1"));
  const s1 = d.getElementById("course-1"), s2 = d.getElementById("course-2");
  ok("compare: dropdowns populated (14 + placeholder)", await until(() => s1.options.length === 15 && s2.options.length === 15));
  ok("compare: ?id1=1 preselects course 1", s1.value === "1");
  s2.value = "2"; d.getElementById("compare-btn").click();
  ok("compare: table with both course names", await until(() => /Machine Learning Fundamentals/.test(txt(d, "#results")) && /Data Science Essentials/.test(txt(d, "#results")) && d.querySelectorAll(".compare-table tr").length === 6), txt(d, "#results").slice(0, 100));
  s2.value = "1"; d.getElementById("compare-btn").click(); ok("compare: same course twice -> 'Pick two different courses'", /Pick two different/.test(txt(d, "#results")));
  s2.value = ""; d.getElementById("compare-btn").click(); ok("compare: missing selection -> 'Pick two courses'", /Pick two courses/.test(txt(d, "#results")));
  s2.innerHTML += '<option value="999">ghost</option>'; s2.value = "999"; d.getElementById("compare-btn").click();
  ok("compare: invalid id (404) -> 'Comparison unavailable'", await until(() => /Comparison unavailable/.test(txt(d, "#results"))), txt(d, "#results"));
  dom.window.close();

  console.log(`\nFRONTEND CHECKS: ${pass} passed, ${fail} failed (jsdom, not a real browser)`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error("HARNESS ERROR", e); process.exit(2); });
