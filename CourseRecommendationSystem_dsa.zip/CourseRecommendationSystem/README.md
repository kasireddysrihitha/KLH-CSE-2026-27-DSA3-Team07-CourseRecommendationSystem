# Course Recommendation System (DSA-3 Project)

A course recommendation and search system built to demonstrate core DSA
concepts, now with a browser-based frontend on top of the original console
application.

## Overview

Students enter their interests, skills, qualifications and career goals and
get ranked course recommendations. They can also search the course catalog,
browse all courses, view course details, and compare two courses side by
side. All matching, searching and ranking is done by hand-written DSA
algorithms in the Java backend — the frontend only displays their results.

## Features

- Get course recommendations from a student profile
- Search courses by keyword (with typo-tolerant fuzzy fallback)
- Browse / filter all courses
- View full course details
- Compare two courses side by side
- Original console (terminal) app, unchanged and still runnable

## Technology Stack

- **Backend / DSA logic:** Plain Java (no frameworks). `WebServer.java`
  uses the JDK's built-in `com.sun.net.httpserver` HTTP server — there is
  **no Spring Boot, Maven, or Gradle**, and nothing to download. This was
  chosen because it is the simplest architecture that can reliably expose
  the existing Java classes to a browser: one `javac` command, one `java`
  command, zero dependencies.
- **Frontend:** Static HTML, CSS and vanilla JavaScript (no build step, no
  npm, no framework). Pages call the backend's JSON API with `fetch()`.

## Project Structure

```text
CourseRecommendationSystem/
  src/
    Main.java                  - console app entry point (unchanged)
    CourseDatabase.java        - Course model + in-memory dataset (now loaded from data/courses.txt)
    FileHandler.java           - NEW: reads/parses/validates data/courses.txt
    RecommendationEngine.java  - scoring, eligibility, Merge Sort ranking (unchanged)
    SearchEngine.java          - KMP, Rabin-Karp, Edit Distance (unchanged) + Trie autocomplete hook
    CourseTrie.java            - NEW (Phase 2): Trie for course-name prefix search
    WebServer.java              - NEW: HTTP server + JSON API, wraps the above
    JsonUtil.java                - NEW: turns model objects into JSON text
  data/
    courses.txt                 - NEW: external course dataset (one course per line)
  public/                       - NEW: static frontend, served by WebServer
    index.html                  - Home
    recommend.html              - Get Recommendations
    search.html                 - Search Courses
    explore.html                - Explore / All Courses
    course.html                 - Course Details (?id=)
    compare.html                - Compare Courses
    css/style.css
    js/
      api.js                    - fetch() wrappers for the JSON API
      components.js             - shared HTML-rendering helpers
      nav.js                     - active nav link + mobile menu
      recommend.js / search.js / explore.js / course.js / compare.js
        (one small script per page; the home page needs none)
  test/                         - TrieTest, GraphTest, FileHandlerTest, IntegrationTest (Java); api_test.py, fuzz_check.py,
                                  edge_dataset_check.py, run_with_server.sh, frontend_jsdom_check.js (Phase 4)
  README.md
```

## Course Data File

Courses are stored in `data/courses.txt`, not in the Java code. One course
per line, 8 fields separated by `|`:

```text
id|name|category|description|prerequisites|requiredSkills|careerPaths|interestTags
```

List fields use `;` between items (e.g. `Python;SQL`). Only prerequisites may
be empty. Blank lines and lines starting with `#` are ignored. `FileHandler`
skips invalid lines (wrong field count, non-numeric/duplicate id, empty
required field) and prints a warning with the line number; a missing,
unreadable or empty file gives an empty course list and an error message
instead of a crash. The file path is relative to the folder you run `java`
from; use `java -Dcourses.file=path/to/file.txt -cp bin WebServer` to load a
different file.

## DSA Algorithms & Purpose

| Algorithm | Where | Purpose | Time Complexity |
|---|---|---|---|
| KMP | SearchEngine | Exact substring search in course name/category | O(n+m) |
| Rabin-Karp | SearchEngine | Hash-based keyword search in description/skills | O(n+m) avg |
| Edit Distance (DP) | SearchEngine + RecommendationEngine | Fuzzy matching for typos/partial terms and fuzzy skill/interest overlap | O(n·m) |
| Trie (prefix tree) | CourseTrie, used by SearchEngine.suggestCourses -> `/api/suggest` -> search-box dropdown | Case-insensitive course-name prefix autocomplete ("Mach" -> Machine Learning Fundamentals) | insert O(m); prefix lookup O(m + matches); space O(total chars) |
| Merge Sort | RecommendationEngine (shared) | Ranks recommendations by score and search hits by similarity | O(n log n) |

The algorithms were not modified or simplified. The one exception to "nothing duplicated in
JavaScript": `public/js/search.js` keeps a small Edit-Distance copy used only for the
search-box dropdown's typo fallback (when no course name starts with the typed text); the real
search results always come from `/api/search`. The frontend otherwise only renders the JSON that `WebServer.java` builds directly from
`RecommendationEngine` and `SearchEngine`'s existing return values.

## How Frontend Communicates with Backend

`WebServer.java` starts a single HTTP server on port 8080 that does two
things:

1. Serves the static files in `public/` (so opening `http://localhost:8080`
   loads the frontend).
2. Exposes a small JSON API that calls the existing engines directly:

| Endpoint | Method | Description |
|---|---|---|
| `/api/status` | GET | Total course count + engine status, for the home page |
| `/api/courses` | GET | All courses (`CourseDatabase.getAllCourses()`) |
| `/api/course?id=` | GET | One course by id |
| `/api/search?q=` | GET | Calls `SearchEngine.search(query)` |
| `/api/categories` | GET | Distinct course categories (currently not used by the pages) |
| `/api/suggest?q=` | GET | Trie prefix autocomplete on course names (max 8, `[]` for empty/no match) |
| `/api/recommend?interests=&skills=&qualifications=&careerGoals=` | GET | Comma-separated lists, calls `RecommendationEngine.recommend(...)` |
| `/api/compare?id1=&id2=` | GET | Two courses side by side |

All parameters are plain query-string values (comma-separated for lists),
so no JSON request-body parsing was needed on the backend — this kept the
server small and dependency-free.

## How to Install / Run

### Option A: Web app (recommended for the demo)

```bash
cd CourseRecommendationSystem
javac -d bin src/*.java
java -cp bin WebServer
```

Then open **http://localhost:8080** in a browser. Stop the server with
Ctrl+C. The `public/` and `data/` folders must stay alongside wherever you run
`java` from (both are read as relative paths).

### Option B: Original console app (unchanged)

```bash
cd CourseRecommendationSystem
javac -d bin src/*.java
java -cp bin Main
```

## Example Usage

- **Recommend:** interests="Machine Learning, Data", skills="Python,
  Statistics", qualifications="Basic Programming, Statistics",
  careerGoals="Data Scientist" → ranks "Machine Learning Fundamentals" and
  "Data Science Essentials" at the top, same as the console app.
- **Search:** query "Machne Learning" (typo) → no exact match, falls back
  to Edit Distance fuzzy matching, returns "Machine Learning Fundamentals".

## Known Limitations

- The web server is single-purpose and not production-hardened (no HTTPS,
  no auth, no rate limiting) — this matches the brief, which explicitly
  asked to avoid login systems, complex infrastructure, etc.
- The Explore page's category/keyword filter is a simple client-side
  filter over the already-fetched course list, separate from the
  KMP/Rabin-Karp/Edit-Distance-backed search on the Search page.

## Testing Performed

This version was compiled with `javac` (OpenJDK 21) and run end-to-end
with `java -cp bin WebServer`. The following were verified against the
live server, not just read in source:

- `javac -d bin src/*.java` compiles with zero errors/warnings.
- `/api/status`, `/api/courses`, `/api/course?id=`, `/api/search?q=`,
  `/api/recommend?...` and `/api/compare?id1=&id2=` all return correct,
  well-formed JSON.
- Search for "Machine Learning" returns an exact 100% match via KMP;
  search for the typo "Machne Learning" falls through to the Edit
  Distance fuzzy path and still returns "Machine Learning Fundamentals"
  (~52% similarity).
- `/api/recommend` returns eligible/ineligible courses with correct
  missing-prerequisite lists, ranked by score via the hand-written
  Merge Sort.
- Every static asset (`index.html`, `recommend.html`, `search.html`,
  `explore.html`, `course.html`, `compare.html`, `css/style.css`, all
  `js/*.js`) is served with a 200 and the correct `Content-Type`; an
  unknown path correctly returns 404.
- Edge cases: missing/blank query params, an invalid course id, and two
  identical/invalid compare ids all return sensible JSON errors instead
  of crashing the server.
- Fixed one real bug found during testing: `JsonUtil` formatted decimal
  numbers (`score`, `confidence`) with the JVM's default locale, which on
  a non-US locale can print `40,0` instead of `40.0` and produce invalid
  JSON. Both call sites now explicitly use `Locale.US`.

## Status

All planned functionality (recommendation, search, view all, view details,
compare, all 4 DSA algorithms, and the browser frontend for each) is
implemented, and the application has been compiled and exercised
end-to-end as described above.

## Phase 2: Trie

`SearchEngine` builds two `CourseTrie`s from `CourseDatabase.getAllCourses()` (i.e. the
courses loaded from `data/courses.txt`): one keyed by the full lower-cased course name, one by
the start of each later word. `suggestCourses(prefix, limit)` returns name-prefix matches first,
then word-start matches, without duplicates. Empty input or no match returns an empty list. The
search page calls `/api/suggest` per keystroke for its dropdown, and falls back to the older
keyword/fuzzy dropdown logic when no course name matches. The console Search option also prints
Trie suggestions. KMP / Rabin-Karp / Edit Distance / Merge Sort are untouched.

Run the tests from the project root:
```bash
javac -d bin src/*.java && javac -cp bin -d bin test/TrieTest.java && java -cp bin TrieTest
```

## Phase 3: Graph (course prerequisite graph)

`CourseGraph.java` builds a directed graph from the loaded dataset: vertices are courses plus
foundation topics named as prerequisites that are not courses (Basic Programming, Statistics,
Networking Basics, Linear Algebra); edge `P -> C` means P is a prerequisite of C. Algorithms, all
hand-written: Kahn topological sort + cycle detection + longest-path levels, reverse BFS (needed
prerequisites, stopping at what the student knows), layered scheduling with a per-semester cap,
forward BFS (unlocks) and weakly connected components. Full reasoning in `GRAPH_DESIGN.md`.

| Endpoint | Description |
|---|---|
| `/api/graph` | Vertices, edges, topological order, levels, components, cycle info, warnings |
| `/api/path?target=ID&known=a,b&perSemester=2` | Ordered learning path / semester plan to a course |
| `/api/unlocks?id=ID` | Courses reachable after a course (with BFS distance) |

The Course Details page shows "What this course unlocks" and "Learning path to this course".
Tests: `javac -cp bin -d bin test/GraphTest.java && java -cp bin GraphTest`.

## Phase 4: Integration, regression testing and cleanup

No new features. Full results and every test that was (and was not) run are in
`FINAL_TEST_REPORT.md`. Bugs fixed: graph levels / paths into cycles, Trie false positives for
non-ASCII text and crashes on huge names, Turkish-locale case folding, null/blank handling in the
engines, and the static-file handler (sibling-folder path traversal, `%00`).

Run everything from the project root:
```bash
javac -d bin src/*.java && javac -cp bin -d bin test/*.java
for t in TrieTest GraphTest FileHandlerTest IntegrationTest; do java -cp bin $t; done
sh test/run_with_server.sh -- python3 test/api_test.py        # live-server API suite (starts/stops the server)
sh test/run_with_server.sh -- python3 test/fuzz_check.py      # 1500 randomised requests
# optional frontend check (needs: npm install jsdom somewhere; simulated DOM, not a real browser)
NODE_PATH=/path/to/node_modules sh test/run_with_server.sh -- node test/frontend_jsdom_check.js
```
