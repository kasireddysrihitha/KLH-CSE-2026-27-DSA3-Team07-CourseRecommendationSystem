# FINAL_TEST_REPORT.md — Phase 4: Integration, Regression Testing, Debugging and Cleanup

Legend: **PASSED** = performed and succeeded · **FIXED** = a defect was found, fixed, and the test now passes · **NOT APPLICABLE** · **NOT TESTED** = not performed.
Nothing below is claimed unless it was actually executed in this session.

## 1. Environment
| Item | Value |
|---|---|
| OS / sandbox | Ubuntu 24 container, Linux, running as root |
| Java runtime | OpenJDK 21.0.10 JRE (preinstalled) |
| Compiler | javac 21.0.12.1 — **installed during this phase** (the sandbox shipped a JRE only; `openjdk-21-jdk-headless` from the Ubuntu archive) |
| Node.js | v22.22.2 (syntax checks + jsdom harness) |
| jsdom | 30.1.2 (installed in /tmp, **not** part of the project) |
| Python | Python 3.12.3 (API / fuzz scripts, standard library only) |
| Browser | **None available.** No real browser test was performed (see §11). |

## 2. Compilation
* `javac -Xlint:all -d bin src/*.java` → exit 0, **0 warnings** (clean rebuild from an empty `bin/`). **PASSED**
* `javac -Xlint:all -cp bin -d bin test/*.java` → exit 0; 3 deprecation notes for `new Locale(..)` in test code only (used deliberately to switch default locale in the tests). **PASSED**
* No Maven/Gradle/external libraries are needed to build or run the project. **PASSED**

## 3. Test inventory (all executed, final clean run)
| Suite | Where | Result |
|---|---|---|
| TrieTest (existing, Phase 2) | test/TrieTest.java | 22 / 22 **PASSED** |
| GraphTest (existing, Phase 3) | test/GraphTest.java | 36 / 36 **PASSED** |
| FileHandlerTest (**new**, Phase 1 coverage) | test/FileHandlerTest.java | 55 / 55 **PASSED** |
| IntegrationTest (**new**, cross-phase + oracles) | test/IntegrationTest.java | 93 / 93 **PASSED** (16 of its checks failed on the pre-fix code, see §13) |
| Live-server API suite | test/api_test.py | 107 / 107 **PASSED** (also 107 / 107 with the server started under a Turkish default locale) |
| Randomised API fuzz | test/fuzz_check.py | 1500 requests, 0 dropped connections, 0 HTTP 5xx, 0 non-JSON bodies **PASSED** |
| Hostile-dataset server runs | test/edge_dataset_check.py | missing file, comment-only file, quotes/backslash/tab/unicode/cycle file: 18 + 18 + 24 requests, 0 problems **PASSED** |
| Frontend DOM checks (jsdom) | test/frontend_jsdom_check.js | 42 / 42 **PASSED** — simulated DOM, **not a real browser** |
| Differential regression (original Phase 3 vs fixed build) | ad-hoc, not shipped | 217 output lines (25 search + 25 suggest queries, 6 recommendation profiles, graph JSON, 144 path cases, 16 unlock cases): **byte-identical** **PASSED** |
| Console app smoke test (Main, piped stdin) | ad-hoc | recommend / search+Trie / view all / details / compare / invalid id / exit **PASSED** |

## 4. File handling (Phase 1)
All via real temp files (FileHandlerTest) unless noted.
* data/courses.txt loads: 14 courses, no error, no skipped lines; CourseDatabase ids/order equal FileHandler output — **PASSED**
* CourseDatabase gets its data only from FileHandler; `-Dcourses.file` honoured — **PASSED**
* No production code carries the old hardcoded dataset (scan of code lines; only FileHandler constructs a Course) — **PASSED**
* Missing file, directory instead of file, empty path → error message, empty list, no exception — **PASSED**
* Empty (0-byte), comment-only, whitespace-only, all-malformed files → empty list + error, no exception — **PASSED**
* Malformed lines (7 or 9 fields, '|' inside a field) skipped with line-numbered warning; valid lines kept — **PASSED**
* Invalid ids (abc, empty, 0, -5, 1.5, 20-digit overflow, blank, 1e3, 0x10) skipped; ' 7 ' accepted — **PASSED**
* Duplicate ids: first kept, later skipped; a rejected line does not reserve its id — **PASSED**
* Required-field violations (name/category/description/skills/careers/tags empty) skipped; empty prerequisites allowed — **PASSED**
* UTF-8 BOM, CRLF, no trailing newline, non-ASCII/emoji, indented lines/comments, '#' inside a field — **PASSED**
* Malformed UTF-8 bytes: no exception — **PASSED**; 5000-line file loads fully; 200,000-char line loads — **PASSED**
* Application starts and every endpoint answers with an **empty dataset** (missing file and comment-only file, live server) — **PASSED**
* Dataset file modified? **No.** data/courses.txt is byte-identical to the original.

## 5. Trie (Phase 2)
* Built from the loaded courses only: swapping the data file swaps the suggestions; shipped names disappear — **PASSED**
* Wired into the app: `SearchEngine.suggestCourses` ← `/api/suggest` (WebServer) and console Search; search.html calls it per keystroke (jsdom check) — **PASSED** (not dead code)
* Prefix search, case-insensitive (Mach / mach / MACH), word-start index ("learn" → Deep Learning), trailing space, special characters ("UI/") — **PASSED**
* Every prefix of every course name equals a brute-force scan; no extras, no duplicates, limit respected — **PASSED**
* Empty / blank / null input and no-match input → `[]` — **PASSED**
* Duplicate names → two distinct courses returned once each; same course re-inserted ignored — **PASSED**
* Non-ASCII prefixes (É, Ñ, 中, Telugu) returned unrelated courses — **FIXED** (§13, bug 3)
* 60,000-char course name → StackOverflowError; 3,000-word name → StackOverflowError — **FIXED** (§13, bug 4)
* Existing algorithms still work independently of the Trie — **PASSED**

## 6. KMP / Rabin-Karp / Edit Distance / Merge Sort (regression)
* KMP and Rabin-Karp equal `String.contains` on 30,000 random (text, pattern) pairs over 5 alphabets incl. non-ASCII; 5,000 planted substrings all found; boundary cases; 200,000-char text in linear time — **PASSED**
* Edit Distance equals an independent reference DP on 20,000 random pairs; symmetric, identity, bounds, triangle inequality; known values (kitten/sitting = 3 …); similarity bounds — **PASSED**
* Merge Sort equals a stable reference sort on 3,000 random lists with many ties; input not mutated; empty/single lists; 100,000 elements — **PASSED**
* Search workflow on real data: exact (100), keyword/Rabin-Karp (90), typo → Edit-Distance fallback (< 100), gibberish → empty, results sorted, no duplicates; exact/keyword stage equals a brute-force oracle for 8 queries — **PASSED**
* Recommendation ranking on real data: every course once, descending; documented example ranks ML/Data Science first; eligibility and missing-prerequisite lists correct — **PASSED**

## 7. Graph (Phase 3)
* Built from real data: 18 vertices (14 courses + 4 foundations), 16 edges, 3 components, acyclic; every vertex name occurs in data/courses.txt (no unrelated sample data); follows a swapped data file — **PASSED**
* Against independent oracles on 600 random graphs (1/3 cyclic): topological-order validity, longest-path levels, cycle detection, cyclic core / blocked set, unlocks (BFS distances for every course), weak components (union-find), learning paths (exact needed set, prerequisites strictly earlier, per-semester cap, `minSemesters` = longest chain, ALREADY_KNOWN / BLOCKED statuses) — **PASSED after fix** (levels and paths into cycles were wrong, §13 bug 1)
* Known prerequisites (case-insensitive, fuzzy, pruning through known courses), null / blank known lists, perSemester 0 / -5 / 99 / abc → clamped or defaulted — **PASSED**
* Invalid course ids (0, -1, 999, abc, missing) → NOT_FOUND / empty unlocks, never an exception — **PASSED**
* File-driven odd data: self-prerequisite, duplicate prerequisites differing by case/space, forward references, duplicate course names, missing prerequisite references, cycle — warnings produced, no crash — **PASSED**
* Empty dataset: 0 vertices, valid JSON — **PASSED**; 500-course chain (existing GraphTest) and a 5,000-course dataset (server: /api/graph 46 ms, /api/path 10 ms) — **PASSED**
* Courses without prerequisites: path = itself in semester 1; unlocks empty; eligible — **PASSED**

## 8. API tests (live server, test/api_test.py, 107 checks)
Every endpoint was exercised: `/api/status`, `/api/courses`, `/api/course`, `/api/search`, `/api/suggest`, `/api/categories`, `/api/recommend`, `/api/compare`, `/api/graph`, `/api/path`, `/api/unlocks`, plus the static files. For each: HTTP status, JSON validity, response structure, valid input, invalid input, missing parameters, empty results.
* Statuses: 200 for valid/empty results; 404 + `{"error":…}` (or `status:NOT_FOUND` for /api/path) for unknown/non-numeric/missing ids; 405 + JSON for POST/DELETE on every API route; unknown /api/* → 404 — **PASSED**
* Special characters, unicode, 5,000-char queries, empty/blank/missing parameters — **PASSED**
* Malformed percent-encoding (`%ZZ`) → **400 Bad Request with an HTML body generated by the JDK server before the handler runs.** Accepted as correct; the frontend always uses encodeURIComponent — **PASSED** (documented)
* Recommend with no parameters → `[]` — **FIXED** (§13 bug 5)
* Static-file safety: `/../src/..`, encoded dot-dot, `/js/`, `/js` → 404 — **PASSED**; `/../public_old/secret.txt` served a file outside public/ — **FIXED** (bug 6); `/%00` dropped the connection — **FIXED** (bug 7)
* JSON with quotes, backslashes, tabs, unicode in data (live server, hostile dataset) valid — **PASSED**
* Decimal formatting independent of locale (de_DE test, tr_TR server) — **PASSED**

## 9. Frontend / backend integration (jsdom — see §11 for limits)
The real page scripts were loaded from the live server and driven programmatically:
* All 6 pages load and run without script errors (the only message ignored is the unreachable Google Fonts stylesheet in the offline sandbox) — **PASSED**
* API URLs, parameter names and JSON field names match between api.js/pages and WebServer/JsonUtil for every endpoint the pages use — **PASSED**
* Explore (14 cards, category filter, text filter, empty state), Course details (detail data, unlocks, learning path with foundations + semesters, "known" input, already-known message, no-prerequisite course, id=999 / abc / missing → friendly states), Search (Trie dropdown for "Mach" and word-start "learn", keyword fallback for "python", no-match, clear, typo submit via fuzzy path, blank submit, no-result submit, `?q=` with HTML characters escaped), Recommend (blank + whitespace validation, ranked cards, eligibility badges), Compare (preselect via ?id1, table of both courses, same-course, missing selection, invalid id 404) — **PASSED**
* JavaScript syntax of all 8 scripts (`node --check`) — **PASSED**
* **/api/graph, /api/status and /api/categories have no consumer in the current pages** (api.js defines wrappers but no page calls them; the home page shows no status). Not a defect for this phase; the endpoints were verified directly. Left untouched for the UI phase.

## 10. Edge cases (summary)
Missing / empty / comment-only / malformed datasets (**PASSED**) · invalid or duplicate ids (**PASSED**) · courses with no prerequisites (**PASSED**) · self / duplicate / missing / cyclic prerequisites (**PASSED**, cycle paths **FIXED**) · null and blank engine inputs (**FIXED**) · non-ASCII text (**FIXED**) · Turkish default locale (**FIXED**) · very long names (**FIXED**) · 5,000-course dataset — server start, /api/suggest 18–35 ms, /api/search 60–157 ms, /api/recommend 110 ms (**PASSED**; informational timings from one run) · 1,500 random requests (**PASSED**).

## 11. Not tested / limits (stated so nothing is overclaimed)
* **NOT TESTED — real browser.** No browser was available. No screenshots exist. CSS/layout, real `fetch`/CORS behaviour, keyboard focus, mobile menu and visual appearance were not verified. jsdom is a simulated DOM only.
* **NOT TESTED** — Windows/macOS (path separators were reasoned about, not run); Java versions other than 21; HTTPS; sustained load or many concurrent clients (the server uses the JDK default single-thread executor; only sequential requests were sent).
* **NOT APPLICABLE** — console menu has no graph options (Phase 3 added none; graph is API/web only).
* Observed, **not changed** (see §14): HEAD requests; blank-vs-nonsense recommendation behaviour; duplicated Edit Distance in search.js.

## 12. Dead code / duplication audit
* No duplicate classes. No hardcoded course data in production code. No debug/test code left in src/. No unused imports reported by `-Xlint:all`.
* `CourseGraph.describe()` and `CourseTrie.getKeyCount()` are unused by production code (tiny, harmless; kept — `getTrieNodeCount` is used by TrieTest).
* `KNOWN_MATCH_THRESHOLD` (graph) and `FUZZY_MATCH_THRESHOLD` (recommender) are both 65.0 and commented as intentionally the same rule; left as is.
* Frontend: `Api.getStatus / getCategories / getGraph` unused (see §9). `search.js` carries a small JS copy of Edit Distance for the dropdown typo fallback (different threshold, 60 vs 50/65 on the server). The README previously claimed nothing was duplicated in JS; **README corrected**, code left alone (changing it would alter the existing dropdown behaviour).
* README referenced a non-existent `home.js` — **README corrected**; `/api/categories` was missing from the endpoint table — **added**.

## 13. Bugs discovered and fixes made
| # | Bug (all reproduced before fixing) | Fix | Files |
|---|---|---|---|
| 1 | **Graph (Phase 3):** a vertex on a cycle that also had a normal outside prerequisite kept a non-negative `level`. `learningPath` uses `level == -1` to detect cycles, so a path to such a course returned **status OK** with the cycle courses listed under "semester 0 / foundations" (e.g. two courses that require each other and also "Basic Programming"). `/api/graph` reported wrong levels / `longestChain`. | Unprocessed vertices now get level -1 | CourseGraph.java |
| 2 | **Locale:** with a Turkish default locale, `toLowerCase()` turned "I" into dotless "ı": `search('ui/ux')` lost its exact match (100 → fuzzy 60) and `suggest('ui')` returned nothing. | `toLowerCase(Locale.ROOT)` at all 11 case-folding sites | SearchEngine.java, CourseTrie.java, CourseGraph.java |
| 3 | **Trie (Phase 2):** all non-ASCII characters shared one child slot, so `suggest('é')` returned the French, Spanish, Chinese and Telugu courses; `suggest('తె')` returned the Chinese one. | End entries store their full key; results are verified against it | CourseTrie.java |
| 4 | **Trie:** recursion depth = key length → `StackOverflowError` for a 60,000-char name or a 3,000-word name (word-start index). | Trie path capped at 64 chars (exactness preserved by the key check in bug 3) | CourseTrie.java |
| 5 | **Engine contracts:** `search(null)` / `recommend(null)` / null lists threw NPE; `search("")` matched every course at 100; a blank profile "recommended" the two no-prerequisite courses at 10.0 (free eligibility points) although the UI treats blank as invalid and the console says "No matching courses found". | Null-safe `StudentProfile`, `isEmpty()`, guards in `search` / `recommend`. Scoring untouched. | SearchEngine.java, RecommendationEngine.java |
| 6 | **Security/robustness:** static handler used `startsWith(publicRoot)` without a separator → `GET /../public_old/secret.txt` served a file outside public/ when a sibling folder starts with "public". | Require `publicRoot + File.separator` | WebServer.java |
| 7 | `GET /%00` threw inside the handler → connection dropped, no response. | Illegal path → 404 | WebServer.java |

Also corrected: README (home.js, JS-duplication claim, /api/categories, test instructions, Phase 4 section) and GRAPH_DESIGN.md (level −1 rule; the semester plan is a valid greedy plan, `minSemesters` is a lower bound — not guaranteed minimum under a cap).

Errors in **my own test scaffolding** found along the way and fixed (not product bugs): a hardcoded-data scan that matched a doc comment; a test oracle that recursed on cycles (which is how bug 1 surfaced); a shell `printf` that wrote literal "\xc3" text; a lowercase-é assertion against "École"; the JSON checker being pointed at an HTML page.

## 14. Observed but intentionally NOT changed
* **Recommend with nonsense input** (e.g. skills=zzzz): the two no-prerequisite courses still appear at 10.0, because the scoring gives 10 eligibility points independent of any match. That is the original scoring design; only the fully blank profile is guarded. Decide in a later phase whether to require some content match.
* **HEAD requests** work but make the JDK log a harmless "content length for a HEAD request" warning; the frontend never sends HEAD.
* Semester planning is greedy (valid, not guaranteed minimal under a cap) — documented rather than replaced.
* `/api/graph` returns about 1.1 MB for 5,000 courses (all nodes with adjacency); fine for the catalogue size, noted for the UI phase.

## 15. Final regression result
* Compiles cleanly; all 206 Java checks (22 + 36 + 55 + 93), 107 API checks, 1,500 fuzz requests, 3 hostile-dataset runs, 42 jsdom checks pass.
* Phase 1 (file handling), Phase 2 (Trie, KMP, Rabin-Karp, Edit Distance, Merge Sort) and Phase 3 (graph, topological sort, cycle detection, learning path, semester planning, unlocks) are intact: outputs for normal data are byte-identical to the original Phase 3 build; behaviour differs only where a defect was fixed.
* Frontend files, data/courses.txt, FileHandler, CourseDatabase, JsonUtil and Main are unchanged.
* **Not done:** real-browser testing (§11).
